#!/bin/bash
# Проверка образа в виртуальной машине QEMU (до записи на флешку).
#   ./tools/test-in-qemu.sh out/vyacheslav-os.iso            — как флешка
#   ./tools/test-in-qemu.sh out/vyacheslav-os.iso --disk     — плюс пустой «жёсткий диск» 20 ГБ,
#                                                             чтобы проверить установку
# Нужно: apt install qemu-system-x86 qemu-utils
set -euo pipefail
ISO="${1:?укажите путь к ISO}"
ARGS=(-m 3072 -smp 2 -vga std -display gtk -boot menu=on
      -audiodev pa,id=snd0 -device intel-hda -device hda-duplex,audiodev=snd0
      -nic user,model=e1000
      -drive file="$ISO",format=raw,if=none,id=usb -device usb-ehci,id=ehci -device usb-storage,bus=ehci.0,drive=usb,bootindex=0)
[ -e /dev/kvm ] && ARGS+=(-enable-kvm -cpu host)
if [ "${2:-}" = "--disk" ]; then
  [ -f test-disk.qcow2 ] || qemu-img create -f qcow2 test-disk.qcow2 20G
  ARGS+=(-drive file=test-disk.qcow2,format=qcow2,if=ide,bootindex=1)
fi
exec qemu-system-x86_64 "${ARGS[@]}"
