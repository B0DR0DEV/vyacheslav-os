#!/bin/bash
# =====================================================================
#  write-usb.sh — запись ВячеславOS на флешку (Linux).
#
#   sudo ./tools/write-usb.sh out/vyacheslav-os.iso /dev/sdX
#   sudo ./tools/write-usb.sh out/vyacheslav-os.iso /dev/sdX --persistence
#
#  --persistence  — в свободном месте флешки создаётся раздел «persistence»:
#                   тогда в режиме «Попробовать» настройки, заметки и
#                   пароли Wi-Fi сохраняются НА ФЛЕШКЕ между включениями.
#                   Без него пробный режим ничего не помнит после выключения.
#                   В обоих случаях жёсткий диск ноутбука не трогается.
#
#  ВНИМАНИЕ: всё, что было на флешке, будет стёрто.
#  Узнать имя флешки:  lsblk -o NAME,SIZE,MODEL,TRAN
# =====================================================================
set -euo pipefail
ISO="${1:-}"; DEV="${2:-}"; OPT="${3:-}"
die() { echo "Ошибка: $*" >&2; exit 1; }

[ "$(id -u)" = 0 ] || die "запустите через sudo"
[ -f "$ISO" ] || die "не найден образ '$ISO'"
[ -b "$DEV" ] || die "не найдено устройство '$DEV'. Список: lsblk -o NAME,SIZE,MODEL,TRAN"
[ "$(lsblk -dno TYPE "$DEV")" = disk ] || die "укажите всю флешку (например /dev/sdb), а не раздел (/dev/sdb1)"

TRAN=$(lsblk -dno TRAN "$DEV" | xargs); RM=$(lsblk -dno RM "$DEV" | xargs)
MODEL=$(lsblk -dno MODEL "$DEV" | xargs); SIZE=$(lsblk -dno SIZE "$DEV" | xargs)
if [ "$TRAN" != usb ] && [ "$RM" != 1 ]; then
  die "$DEV ($MODEL, $SIZE) не похож на флешку. Чтобы случайно не стереть жёсткий диск, запись отменена."
fi
grep -q "^$DEV" /proc/mounts && { echo "Отключаю разделы $DEV…"; for p in $(lsblk -lnpo NAME "$DEV" | tail -n +2); do umount "$p" 2>/dev/null || true; done; }

ISO_BYTES=$(stat -c %s "$ISO")
DEV_BYTES=$(lsblk -bdno SIZE "$DEV")
[ "$DEV_BYTES" -gt "$ISO_BYTES" ] || die "флешка меньше образа"

echo
echo "  Флешка:  $DEV — $MODEL, $SIZE"
echo "  Образ:   $ISO ($(du -h "$ISO" | cut -f1))"
echo "  ВСЕ ДАННЫЕ НА ФЛЕШКЕ БУДУТ УДАЛЕНЫ."
read -r -p "  Напишите ДА (большими буквами), чтобы продолжить: " ans
[ "$ans" = "ДА" ] || [ "$ans" = "YES" ] || die "отменено"

echo "Записываю… (5–15 минут)"
wipefs -a -f "$DEV" >/dev/null
dd if="$ISO" of="$DEV" bs=4M status=progress conv=fsync oflag=direct
sync

if [ "$OPT" = "--persistence" ]; then
  echo "Создаю раздел для сохранения данных…"
  partprobe "$DEV" 2>/dev/null || true; sleep 2
  # новый раздел — во всём свободном месте после образа
  echo ',,L' | sfdisk --append --quiet "$DEV"
  partprobe "$DEV" 2>/dev/null || true; udevadm settle; sleep 2
  PART=$(lsblk -lnpo NAME,TYPE "$DEV" | awk '$2=="part"{p=$1} END{print p}')
  [ -b "$PART" ] || die "раздел не создался"
  mkfs.ext4 -q -F -L persistence "$PART"
  MP=$(mktemp -d)
  mount "$PART" "$MP"
  # сохраняем только домашнюю папку (настройки, заметки) и пароли Wi-Fi
  printf '/home union\n/etc/NetworkManager/system-connections union\n' > "$MP/persistence.conf"
  umount "$MP"; rmdir "$MP"
  echo "Раздел $PART (persistence) создан."
fi
sync
echo
echo "Готово! Флешку можно вынимать."
echo "На ASUS K50ID: выключите ноутбук, держите Esc и нажмите кнопку питания → выберите флешку."
