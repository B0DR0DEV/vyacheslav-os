'use strict';
/*
 * main.js — главный процесс оболочки ВячеславOS.
 *
 * Открывает одно окно на весь экран (это и есть «рабочий стол»), а все
 * «окна» приложений рисуются внутри него нашим собственным оконным
 * менеджером (ui/js/wm.js). Отдельный оконный менеджер X11 не нужен.
 *
 * Связь интерфейса с системой идёт через один IPC-канал 'vos' и
 * белый список методов ниже — интерфейс не может запустить произвольную
 * программу.
 */
const { app, BrowserWindow, ipcMain, session, screen } = require('electron');
const path = require('path');
const os = require('os');
const sys = require('./system');

const MODE = sys.detectMode();
const pre = sys.readSettingsSync();

// Видеокарта GT 320M + драйвер nouveau иногда даёт артефакты в Chromium.
// По умолчанию рисуем процессором (Core 2 Duo справляется с 1366×768);
// включить ускорение можно в Настройках → О системе.
if (!pre.hwAccel || MODE.safeGraphics) app.disableHardwareAcceleration();
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
app.commandLine.appendSwitch('lang', 'ru');
app.commandLine.appendSwitch('password-store', 'basic');
app.commandLine.appendSwitch('disable-features', 'HardwareMediaKeyHandling,MediaSessionService');
app.setPath('userData', path.join(os.homedir(), '.cache', 'vos-shell'));
// Сайты видят обычный Chrome, а не Electron: так Телемост, RUTUBE и другие не ругаются на «неподдерживаемый браузер»
app.userAgentFallback = app.userAgentFallback.replace(/\s+Electron\/\S+/, '').replace(/\s+vyacheslav-os-shell\/\S+/, '');

let win = null;
let quitting = false;

const WINDOWED = !!process.env.VOS_WINDOWED;   // для отладки на обычном компьютере

function createWindow() {
  const { width, height } = screen.getPrimaryDisplay().bounds;
  win = new BrowserWindow({
    x: 0, y: 0, width: WINDOWED ? 1366 : width, height: WINDOWED ? 768 : height,
    frame: WINDOWED, kiosk: !WINDOWED, fullscreen: !WINDOWED, show: false,
    backgroundColor: '#0f2340', autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: false,
      webviewTag: true, spellcheck: false, backgroundThrottling: false
    }
  });
  win.loadFile(path.join(__dirname, 'ui', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.on('close', e => { if (!quitting) e.preventDefault(); });   // Alt+F4 не закроет рабочий стол
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file://')) e.preventDefault(); });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('render-process-gone', () => { setTimeout(() => win && win.reload(), 1000); });
}

/* Сайты открываются во встроенных <webview> внутри наших окон. */
app.on('web-contents-created', (_e, contents) => {
  contents.on('will-attach-webview', (ev, webPreferences, params) => {
    delete webPreferences.preload;
    webPreferences.nodeIntegration = false;
    webPreferences.contextIsolation = true;
    if (!/^https?:\/\//.test(params.src || '')) ev.preventDefault();
  });
  if (contents.getType() === 'webview') {
    // всплывающие окна сайта открываем в том же окне — так проще пожилому человеку
    contents.setWindowOpenHandler(({ url }) => {
      if (/^https?:\/\//.test(url)) contents.loadURL(url);
      return { action: 'deny' };
    });
    contents.on('will-navigate', (e, url) => { if (!/^https?:\/\//.test(url)) e.preventDefault(); });
  }
});

function setupPermissions() {
  // Интерфейсу (file://) разрешаем микрофон: голосовой помощник и заметки.
  session.defaultSession.setPermissionRequestHandler((_wc, perm, cb, details) => {
    const own = (details.requestingUrl || '').startsWith('file://');
    cb(own ? ['media', 'fullscreen', 'clipboard-sanitized-write', 'notifications'].includes(perm) : perm === 'fullscreen');
  });
  session.defaultSession.setPermissionCheckHandler((_wc, perm, origin) => (origin || '').startsWith('file://') || perm === 'fullscreen');
  // Окно видеозвонка — камера и микрофон разрешены
  const call = session.fromPartition('persist:call');
  call.setPermissionRequestHandler((_wc, perm, cb) => cb(['media', 'fullscreen', 'speaker-selection'].includes(perm)));
  call.setPermissionCheckHandler((_wc, perm) => ['media', 'fullscreen', 'speaker-selection'].includes(perm));
  // Остальным сайтам — только полноэкранный режим для видео. Никаких камер, геолокации, уведомлений.
  const web = session.fromPartition('persist:web');
  web.setPermissionRequestHandler((_wc, perm, cb) => cb(perm === 'fullscreen'));
  web.setPermissionCheckHandler((_wc, perm) => perm === 'fullscreen');
}

/* ---------- методы, доступные интерфейсу ---------- */
const api = {
  mode: () => MODE,
  storeGet: (n, d) => sys.storeGet(n, d),
  storeSet: (n, v) => sys.storeSet(n, v),
  hashPassword: pw => sys.hashPassword(pw),
  verifyPassword: (pw, rec) => sys.verifyPassword(pw, rec),
  wifiStatus: () => sys.wifiStatus(),
  wifiScan: () => sys.wifiScan(),
  wifiConnect: (s, p) => sys.wifiConnect(s, p),
  wifiDisconnect: () => sys.wifiDisconnect(),
  wifiSetEnabled: on => sys.wifiSetEnabled(on),
  getVolume: () => sys.getVolume(),
  setVolume: v => sys.setVolume(v),
  setMute: m => sys.setMute(m),
  power: a => { if (a === 'poweroff' || a === 'reboot') quitting = true; return sys.power(a); },
  setTimezone: tz => sys.setTimezone(tz),
  screenWake: () => sys.screenWake(),
  listVoices: () => sys.listVoices(),
  tts: (t, v, r) => sys.tts(t, v, r),
  httpGetJson: url => sys.httpGetJson(url),
  httpGetText: url => sys.httpGetText(url),
  tgSend: (t, c, m) => sys.tgSend(t, c, m),
  tgChats: t => sys.tgChats(t),
  tgMe: t => sys.telegram(t, 'getMe'),
  rustdesk: (a, v) => sys.rustdesk(a, v),
  voiceCtl: m => sys.voiceCtl(m),
  getHostname: () => sys.getHostname(),
  setHostname: n => sys.setHostname(n),
  backupCreate: (d, p) => sys.backupCreate(d, p),
  backupList: d => sys.backupList(d),
  backupRestore: f => sys.backupRestore(f),
  voiceCleanup: f => sys.voiceCleanup(f),
  aiChat: opts => sys.aiChat(opts),
  aiTranscribe: opts => sys.aiTranscribe(opts),
  aiStatus: () => sys.aiStatus(),
  aiCheck: opts => sys.aiCheck(opts),
  voiceSave: d => sys.voiceSave(d),
  voiceList: () => sys.voiceList(),
  voiceDelete: p => sys.voiceDelete(p),
  usbList: () => sys.usbList(),
  usbMount: d => sys.usbMount(d),
  usbUnmount: d => sys.usbUnmount(d),
  photosList: d => sys.photosList(d),
  photosImport: f => sys.photosImport(f),
  photoDir: () => sys.PHOTO_DIR,
  installerDisks: () => sys.installerDisks(),
  diskHealth: dev => sys.diskHealth(dev),
  internalDisks: () => sys.internalDisks(),
  installerStart: dev => sys.installerStart(dev, ev => win && win.webContents.send('install-progress', ev)),
  reloadShell: () => { app.relaunch(); quitting = true; app.exit(0); }
};

ipcMain.handle('vos', async (_e, method, ...args) => {
  if (!Object.prototype.hasOwnProperty.call(api, method)) throw new Error('Неизвестный метод: ' + method);
  try { return await api[method](...args); }
  catch (err) {
    // передаём в интерфейс понятный текст ошибки
    const e = new Error(err && err.message ? err.message : String(err));
    throw e;
  }
});

app.whenReady().then(() => {
  setupPermissions(); createWindow();
  sys.voiceStart(ev => { if (win && !win.isDestroyed()) win.webContents.send('voice', ev); });
});
app.on('before-quit', () => { quitting = true; sys.voiceCtl({ cmd: 'stop' }); });
app.on('window-all-closed', () => { if (quitting) app.quit(); });
