'use strict';
/*
 * system.js — всё, что оболочка ВячеславOS делает с самой системой.
 *
 * Здесь нет графики: только Wi-Fi (через NetworkManager/nmcli), громкость
 * (ALSA/amixer), выключение, хранение данных в JSON-файлах, синтез речи
 * (RHVoice, запасной вариант — espeak-ng), запросы к Groq (ответы и
 * распознавание речи), флешки с фото и установщик.
 *
 * Все внешние программы запускаются через execFile с массивом аргументов —
 * без оболочки, поэтому имя сети или текст с кавычками ничего не сломают.
 */
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { execFile, spawn } = require('child_process');

const HOME = os.homedir();
const CONF_DIR = path.join(HOME, '.config', 'vyacheslav-os');
const DATA_DIR = path.join(CONF_DIR, 'data');
const VOICE_DIR = path.join(HOME, 'Голосовые заметки');
const PHOTO_DIR = path.join(HOME, 'Фото');
const TMP_DIR = path.join(os.tmpdir(), 'vos-' + (process.getuid ? process.getuid() : 'u'));
const IMAGE_EXT = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']);

for (const d of [CONF_DIR, DATA_DIR, VOICE_DIR, PHOTO_DIR, TMP_DIR]) {
  try { fs.mkdirSync(d, { recursive: true }); } catch (_) { /* нет прав — переживём */ }
}

/* ---------- запуск программ ---------- */
function run(cmd, args = [], { input, timeout = 30000 } = {}) {
  return new Promise((resolve, reject) => {
    const child = execFile(cmd, args, { timeout, maxBuffer: 16 * 1024 * 1024, env: { ...process.env, LC_ALL: 'C.UTF-8', LANG: 'C.UTF-8' } },
      (err, stdout, stderr) => {
        if (err) { err.stdout = stdout; err.stderr = stderr; return reject(err); }
        resolve(String(stdout));
      });
    if (input !== undefined) { child.stdin.end(input); }
  });
}
async function has(cmd) {
  try { await run('sh', ['-c', 'command -v "$1"', 'sh', cmd], { timeout: 3000 }); return true; } catch (_) { return false; }
}

/* ---------- режим работы: пробный / установка / установлена ---------- */
function readCmdline() {
  try { return fs.readFileSync('/proc/cmdline', 'utf8'); } catch (_) { return ''; }
}
// Что за компьютер: по этому оболочка решает, включать ли облегчённый режим
function hardwareInfo() {
  let flags = '', model = '';
  try {
    const ci = fs.readFileSync('/proc/cpuinfo', 'utf8');
    flags = ((ci.match(/^flags\s*:\s*(.*)$/m) || [])[1]) || '';
    model = ((ci.match(/^model name\s*:\s*(.*)$/m) || [])[1]) || '';
  } catch (_) { /* не Linux */ }
  const f = new Set(flags.split(/\s+/));
  return {
    cpu: model.replace(/\s+/g, ' ').trim() || (os.cpus()[0] || {}).model || '',
    cores: os.cpus().length,
    memGB: Math.round(os.totalmem() / 1073741824 * 10) / 10,
    sse42: f.has('sse4_2'), avx: f.has('avx')
  };
}
function detectMode() {
  const cl = readCmdline();
  const forced = process.env.VOS_MODE;
  let mode;
  if (forced) mode = forced;
  else if (/\bvos\.mode=install\b/.test(cl)) mode = 'install';
  else if (/\bboot=live\b/.test(cl)) mode = 'live';
  else mode = 'installed';
  let persistent = false;
  try { persistent = fs.readdirSync('/run/live/persistence').length > 0; } catch (_) { /* нет постоянного раздела */ }
  return { mode, live: mode !== 'installed', persistent, safeGraphics: /\bnomodeset\b/.test(cl), toram: /\btoram\b/.test(cl), hw: hardwareInfo() };
}

/* ---------- хранилище: по JSON-файлу на тему ---------- */
function safeName(name) {
  if (!/^[a-z0-9_-]{1,40}$/i.test(name)) throw new Error('Неверное имя хранилища');
  return path.join(DATA_DIR, name + '.json');
}
function storeGetSync(name, def = null) {
  try { return JSON.parse(fs.readFileSync(safeName(name), 'utf8')); } catch (_) { return def; }
}
async function storeGet(name, def = null) { return storeGetSync(name, def); }
async function storeSet(name, value) {
  const file = safeName(name);
  const tmp = file + '.tmp';
  await fsp.writeFile(tmp, JSON.stringify(value, null, 1));
  await fsp.rename(tmp, file);           // атомарно: при выключении питания файл не обрежется
  return true;
}
function readSettingsSync() { return storeGetSync('settings', {}) || {}; }

/* ---------- пароль экрана блокировки ---------- */
function hashPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(pw), salt, 32).toString('hex');
  return { salt, hash };
}
function verifyPassword(pw, rec) {
  if (!rec || !rec.salt || !rec.hash) return String(pw) === '1234';   // пароль по умолчанию
  const h = crypto.scryptSync(String(pw), rec.salt, 32);
  const want = Buffer.from(rec.hash, 'hex');
  return want.length === h.length && crypto.timingSafeEqual(h, want);
}

/* ---------- Wi-Fi через NetworkManager ---------- */
// nmcli -t экранирует двоеточия как "\:" — разбираем аккуратно
function splitTerse(line) {
  const out = []; let cur = '';
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '\\' && i + 1 < line.length) cur += line[++i];
    else if (c === ':') { out.push(cur); cur = ''; }
    else cur += c;
  }
  out.push(cur);
  return out;
}
function parseWifiList(text) {
  const best = new Map();
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    const [inUse, ssid, signal, security] = splitTerse(line);
    if (!ssid) continue;                     // скрытые сети не показываем
    const net = { ssid, signal: parseInt(signal, 10) || 0, secure: !!(security && security !== '--'), security: security || '', connected: inUse === '*' };
    const prev = best.get(ssid);
    if (!prev || net.connected || (!prev.connected && net.signal > prev.signal)) best.set(ssid, net);
  }
  return [...best.values()].sort((a, b) => (b.connected - a.connected) || (b.signal - a.signal));
}
async function wifiStatus() {
  if (!(await has('nmcli'))) return { available: false };
  try {
    const radio = (await run('nmcli', ['radio', 'wifi'])).trim();
    const devs = await run('nmcli', ['-t', '-f', 'TYPE,STATE,CONNECTION', 'device']);
    let wired = false, wifi = null;
    for (const l of devs.split('\n')) {
      const [type, state, conn] = splitTerse(l);
      if (type === 'ethernet' && state === 'connected') wired = true;
      if (type === 'wifi' && state === 'connected') wifi = conn;
    }
    let signal = 0;
    if (wifi) {
      try {
        const list = parseWifiList(await run('nmcli', ['-t', '-f', 'IN-USE,SSID,SIGNAL,SECURITY', 'device', 'wifi', 'list', '--rescan', 'no']));
        const cur = list.find(n => n.connected); if (cur) signal = cur.signal;
      } catch (_) { /* не важно */ }
    }
    return { available: true, enabled: radio === 'enabled', wired, ssid: wifi, signal, online: wired || !!wifi };
  } catch (e) { return { available: true, error: String(e.message || e) }; }
}
async function wifiScan() {
  if (!(await has('nmcli'))) return [];
  let out;
  try { out = await run('nmcli', ['-t', '-f', 'IN-USE,SSID,SIGNAL,SECURITY', 'device', 'wifi', 'list', '--rescan', 'yes'], { timeout: 25000 }); }
  catch (_) { out = await run('nmcli', ['-t', '-f', 'IN-USE,SSID,SIGNAL,SECURITY', 'device', 'wifi', 'list']); }
  return parseWifiList(out);
}
async function wifiConnect(ssid, password) {
  const args = ['device', 'wifi', 'connect', String(ssid)];
  if (password) args.push('password', String(password));
  try {
    await run('nmcli', ['connection', 'delete', 'id', String(ssid)], { timeout: 8000 }).catch(() => {});
    await run('nmcli', args, { timeout: 60000 });
    return { ok: true };
  } catch (e) {
    const msg = String(e.stderr || e.message || '');
    let text = 'Не удалось подключиться к сети.';
    if (/secrets were required|password|802-11-wireless-security|psk/i.test(msg)) text = 'Неверный пароль от Wi-Fi. Проверьте пароль и попробуйте ещё раз.';
    else if (/No network with SSID/i.test(msg)) text = 'Сеть не найдена. Подойдите ближе к роутеру.';
    return { ok: false, error: text, detail: msg.slice(0, 300) };
  }
}
async function wifiDisconnect() {
  try {
    const devs = await run('nmcli', ['-t', '-f', 'DEVICE,TYPE,STATE', 'device']);
    for (const l of devs.split('\n')) {
      const [dev, type, state] = splitTerse(l);
      if (type === 'wifi' && state === 'connected') await run('nmcli', ['device', 'disconnect', dev]);
    }
    return true;
  } catch (_) { return false; }
}
async function wifiSetEnabled(on) {
  try { await run('nmcli', ['radio', 'wifi', on ? 'on' : 'off']); return true; } catch (_) { return false; }
}

/* ---------- звук (ALSA) ---------- */
async function getVolume() {
  try {
    const out = await run('amixer', ['-M', 'get', 'Master']);
    const m = out.match(/\[(\d+)%\]/); const off = /\[off\]/.test(out);
    return { volume: m ? parseInt(m[1], 10) : 70, muted: off };
  } catch (_) { return { volume: 70, muted: false, unavailable: true }; }
}
async function setVolume(v) {
  v = Math.max(0, Math.min(100, Math.round(Number(v) || 0)));
  try {
    await run('amixer', ['-q', '-M', 'sset', 'Master', v + '%', v > 0 ? 'unmute' : 'mute']);
    // на некоторых ноутбуках ASUS отдельно заглушены динамики и PCM
    await run('amixer', ['-q', 'sset', 'Speaker', 'unmute']).catch(() => {});
    await run('amixer', ['-q', 'sset', 'PCM', '100%', 'unmute']).catch(() => {});
    return true;
  } catch (_) { return false; }
}
async function setMute(m) {
  try { await run('amixer', ['-q', 'sset', 'Master', m ? 'mute' : 'unmute']); return true; } catch (_) { return false; }
}

/* ---------- питание ---------- */
async function power(action) {
  if (!['poweroff', 'reboot'].includes(action)) throw new Error('bad action');
  try { await run('systemctl', [action], { timeout: 10000 }); return true; }
  catch (_) {
    try { await run('sudo', ['-n', '/usr/lib/vos/vos-sys', action], { timeout: 10000 }); return true; }
    catch (e) { return false; }
  }
}
async function setTimezone(tz) {
  if (!/^[A-Za-z_]+\/[A-Za-z_\-]+$/.test(tz)) return false;
  try { await run('sudo', ['-n', '/usr/lib/vos/vos-sys', 'timezone', tz]); process.env.TZ = tz; return true; } catch (_) { return false; }
}
async function screenWake() {
  await run('xset', ['dpms', 'force', 'on']).catch(() => {});
  await run('xset', ['s', 'reset']).catch(() => {});
  return true;
}

/* ---------- синтез речи ---------- */
const VOICE_NAMES = {
  aleksandr: 'Александр (мужской)', 'aleksandr-hq': 'Александр HQ (мужской)', anna: 'Анна (женский)',
  arina: 'Арина (женский)', artemiy: 'Артемий (мужской)', elena: 'Елена (женский)', irina: 'Ирина (женский)',
  mikhail: 'Михаил (мужской)', pavel: 'Павел (мужской)', tatiana: 'Татьяна (женский)', victoria: 'Виктория (женский)',
  vitaliy: 'Виталий (мужской)', 'vitaliy-ng': 'Виталий NG (мужской)', yuriy: 'Юрий (мужской)', timofey: 'Тимофей (мужской)'
};
async function listVoices() {
  const dirs = ['/usr/share/RHVoice/voices', '/usr/local/share/RHVoice/voices'];
  const found = [];
  for (const d of dirs) {
    try { for (const n of await fsp.readdir(d)) if (VOICE_NAMES[n.toLowerCase()]) found.push(n.toLowerCase()); } catch (_) { /* нет каталога */ }
  }
  const voices = [...new Set(found)].map(id => ({ id, name: VOICE_NAMES[id] }));
  if (!voices.length) voices.push({ id: 'espeak', name: 'Стандартный (espeak)' });
  return voices;
}
function cleanTmp() {
  fsp.readdir(TMP_DIR).then(list => {
    const now = Date.now();
    for (const f of list) {
      const p = path.join(TMP_DIR, f);
      fsp.stat(p).then(st => { if (now - st.mtimeMs > 10 * 60 * 1000) fsp.unlink(p).catch(() => {}); }).catch(() => {});
    }
  }).catch(() => {});
}
async function tts(text, voice = 'aleksandr', rate = 100) {
  text = String(text || '').replace(/[*_#`>]/g, ' ').slice(0, 2500);
  if (!text.trim()) return null;
  cleanTmp();
  const out = path.join(TMP_DIR, `tts-${Date.now()}-${Math.random().toString(36).slice(2, 7)}.wav`);
  if (voice !== 'espeak' && await has('RHVoice-test')) {
    const installed = (await listVoices()).map(v => v.id).filter(id => id !== 'espeak');
    if (installed.length && !installed.includes(voice)) voice = installed[0];
    const attempts = [];
    if (Number(rate) !== 100) attempts.push(['-p', voice, '-r', String(rate), '-o', out]);
    attempts.push(['-p', voice, '-o', out]);
    for (const args of attempts) {
      try { await run('RHVoice-test', args, { input: text, timeout: 60000 }); if (fs.existsSync(out)) return out; } catch (_) { /* пробуем дальше */ }
    }
  }
  if (await has('espeak-ng')) {
    try { await run('espeak-ng', ['-v', 'ru', '-s', String(Math.round(150 * rate / 100)), '-w', out, text], { timeout: 60000 }); return out; } catch (_) { /* нет */ }
  }
  return null;     // оболочка тогда воспользуется встроенным голосом браузера
}

/* ---------- сеть: простые GET-запросы (погода, радио, курсы валют) ---------- */
async function httpGetJson(url) {
  if (!/^https:\/\//.test(url)) throw new Error('Только https');
  const r = await fetch(url, { headers: { 'User-Agent': 'VyacheslavOS/1.0' }, signal: AbortSignal.timeout(20000) });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const text = await r.text();
  return JSON.parse(text);
}

async function httpGetText(url) {
  if (!/^https:\/\//.test(url)) throw new Error('Только https');
  const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 VyacheslavOS/1.0' }, signal: AbortSignal.timeout(20000) });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  return (await r.text()).slice(0, 2 * 1024 * 1024);
}

/* ---------- Telegram: уведомления родным ---------- */
async function telegram(token, method, body) {
  if (!/^\d+:[A-Za-z0-9_-]{20,}$/.test(String(token || ''))) throw new Error('Неверный токен Telegram-бота');
  if (!/^(sendMessage|getUpdates|getMe)$/.test(method)) throw new Error('bad method');
  let r;
  try {
    r = await fetch('https://api.telegram.org/bot' + token + '/' + method, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}), signal: AbortSignal.timeout(20000)
    });
  } catch (_) { throw new Error('Нет связи с Telegram'); }
  const j = await r.json().catch(() => ({}));
  if (!j.ok) throw new Error(j.description || ('Telegram: ошибка ' + r.status));
  return j.result;
}
const tgSend = (token, chatId, text) => telegram(token, 'sendMessage', { chat_id: chatId, text: String(text).slice(0, 3500), disable_web_page_preview: true });
async function tgChats(token) {
  const ups = await telegram(token, 'getUpdates', { limit: 100, timeout: 0 });
  const seen = new Map();
  for (const u of ups) {
    const m = u.message || u.edited_message || u.my_chat_member;
    const c = m && m.chat; if (!c) continue;
    seen.set(c.id, { id: c.id, name: [c.first_name, c.last_name].filter(Boolean).join(' ') || c.title || c.username || String(c.id), username: c.username || '' });
  }
  return [...seen.values()];
}

/* ---------- удалённая помощь (RustDesk) ---------- */
async function rustdesk(action, arg) {
  if (!['id', 'password', 'status'].includes(action)) throw new Error('bad action');
  if (action === 'password' && !/^[A-Za-z0-9!@#%^*_+=.,-]{6,32}$/.test(String(arg || ''))) throw new Error('Пароль: от 6 до 32 латинских букв и цифр');
  if (!(await has('rustdesk'))) return { available: false };
  try {
    const out = await run('sudo', ['-n', '/usr/lib/vos/vos-sys', 'rustdesk-' + action].concat(action === 'password' ? [String(arg)] : []), { timeout: 20000 });
    if (action === 'id') { const m = out.match(/\d{6,12}/); return { available: true, id: m ? m[0] : null }; }
    return { available: true, ok: true, out: out.trim().slice(0, 200) };
  } catch (e) { return { available: true, error: String(e.stderr || e.message).slice(0, 200) }; }
}

/* ---------- служба голосовой активации ---------- */
const VOICE_SCRIPT = process.env.VOS_VOICE_SCRIPT || path.join(__dirname, 'voice', 'vos-voiced.py');
const VOICE_MODEL = process.env.VOS_VOICE_MODEL || '/opt/vos/voice/model';
let voiceProc = null, voiceCb = () => {}, voiceState = { state: 'off' }, voiceConfig = null, voiceRestarts = 0;
function voiceSendRaw(obj) { if (voiceProc && voiceProc.stdin.writable) voiceProc.stdin.write(JSON.stringify(obj) + '\n'); }
function voiceStart(onEvent) {
  if (onEvent) voiceCb = onEvent;
  if (voiceProc) return voiceState;
  if (!fs.existsSync(VOICE_SCRIPT) || !fs.existsSync(VOICE_MODEL)) {
    voiceState = { state: 'unavailable', reason: 'Модель распознавания речи не установлена' };
    voiceCb({ type: 'state', ...voiceState });
    return voiceState;
  }
  voiceState = { state: 'starting' };
  const p = spawn('python3', [VOICE_SCRIPT, VOICE_MODEL], { env: { ...process.env, VOS_TMP: TMP_DIR, PYTHONUNBUFFERED: '1' }, stdio: ['pipe', 'pipe', 'pipe'] });
  voiceProc = p;
  let buf = '';
  p.stdout.on('data', d => {
    buf += d.toString();
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i); buf = buf.slice(i + 1);
      let ev; try { ev = JSON.parse(line); } catch (_) { continue; }
      if (ev.type === 'ready') { voiceState = { state: 'on' }; voiceRestarts = 0; if (voiceConfig) voiceSendRaw(voiceConfig); }
      if (ev.type === 'error' && ev.fatal) voiceState = { state: 'unavailable', reason: ev.text };
      voiceCb(ev);
    }
  });
  p.stderr.on('data', () => {});
  p.on('exit', (code, sig) => {
    voiceProc = null;
    if (sig === 'SIGILL') voiceState = { state: 'unavailable', reason: 'Процессор не поддерживает распознавание речи на устройстве' };
    else if (voiceState.state !== 'unavailable' && voiceState.state !== 'off' && voiceRestarts < 5) {
      voiceRestarts++; voiceState = { state: 'restarting' };
      setTimeout(() => voiceStart(), 3000);
    } else if (voiceState.state !== 'off') voiceState = { state: 'unavailable', reason: voiceState.reason || 'Служба голоса остановилась' };
    voiceCb({ type: 'state', ...voiceState });
  });
  return voiceState;
}
function voiceCtl(msg) {
  if (!msg || typeof msg.cmd !== 'string') return voiceState;
  if (msg.cmd === 'status') return voiceState;
  if (msg.cmd === 'config') voiceConfig = msg;
  if (msg.cmd === 'stop') { voiceState = { state: 'off' }; voiceSendRaw({ cmd: 'quit' }); return voiceState; }
  if (msg.cmd === 'start') return voiceStart();
  voiceSendRaw(msg);
  return voiceState;
}
function voiceCleanup(file) {
  const abs = path.resolve(String(file || ''));
  if (abs.startsWith(TMP_DIR + path.sep) && abs.endsWith('.wav')) fsp.unlink(abs).catch(() => {});
}

/* ---------- Groq: разговор и распознавание речи ---------- */
const GROQ = 'https://api.groq.com/openai/v1';
// Порядок предпочтения. Список моделей Groq меняется, поэтому при первом
// запросе мы спрашиваем у Groq, какие модели доступны, и берём первую из списка.
const PREFERRED_MODELS = ['openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'llama-3.3-70b-versatile', 'llama-3.1-8b-instant'];
const STT_MODELS = ['whisper-large-v3', 'whisper-large-v3-turbo'];
let chosenModel = null;

function groqError(status, body) {
  let msg = 'Помощник сейчас недоступен.';
  if (status === 401) msg = 'Ключ Groq не подходит. Проверьте его в Настройках → Помощник.';
  else if (status === 429) msg = 'Слишком много вопросов подряд. Подождите минуту.';
  else if (status >= 500) msg = 'Сервер помощника не отвечает. Попробуйте позже.';
  const e = new Error(msg); e.status = status; e.body = String(body || '').slice(0, 500); return e;
}
async function groqFetch(p, init, key) {
  if (!key) { const e = new Error('Нужен ключ Groq: откройте Настройки → Помощник.'); e.status = 0; throw e; }
  let r;
  try {
    r = await fetch(GROQ + p, { ...init, headers: { ...(init.headers || {}), Authorization: 'Bearer ' + key }, signal: AbortSignal.timeout(45000) });
  } catch (_) { const e = new Error('Нет связи с интернетом.'); e.status = -1; throw e; }
  const text = await r.text();
  if (!r.ok) throw groqError(r.status, text);
  return JSON.parse(text);
}
async function pickModel(key, preferred) {
  if (preferred) return preferred;
  if (chosenModel) return chosenModel;
  try {
    const list = await groqFetch('/models', { method: 'GET' }, key);
    const ids = (list.data || []).filter(m => m.active !== false).map(m => m.id);
    for (const want of PREFERRED_MODELS) if (ids.includes(want)) return (chosenModel = want);
    const any = ids.find(id => !/whisper|guard|tts|orpheus|playai|safeguard|distil|prompt-guard|compound/i.test(id));
    if (any) return (chosenModel = any);
  } catch (e) { if (e.status === 401 || e.status === -1) throw e; }
  return PREFERRED_MODELS[0];
}
async function aiChat({ key, model, messages, json }) {
  const m = await pickModel(key, model);
  const body = { model: m, messages, temperature: 0.6, max_completion_tokens: 900 };
  if (/gpt-oss/.test(m)) { body.reasoning_effort = 'low'; body.include_reasoning = false; }
  if (json) body.response_format = { type: 'json_object' };
  let r;
  try {
    r = await groqFetch('/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, key);
  } catch (e) {
    if (e.status !== 400) throw e;
    // модель не поддерживает какой-то параметр — повторяем самый простой запрос
    delete body.reasoning_effort; delete body.include_reasoning; delete body.response_format;
    r = await groqFetch('/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }, key);
  }
  const msg = (r.choices && r.choices[0] && r.choices[0].message) || {};
  return { text: String(msg.content || '').trim(), model: m };
}
async function aiTranscribe({ key, data, mime, filePath, prompt }) {
  let buf, type = mime || 'audio/webm';
  if (filePath) {
    const abs = path.resolve(filePath);
    if (!abs.startsWith(VOICE_DIR + path.sep) && !abs.startsWith(TMP_DIR + path.sep)) throw new Error('Неверный файл');
    buf = await fsp.readFile(abs);
    if (abs.endsWith('.wav')) type = 'audio/wav';
  } else buf = Buffer.from(data);
  if (buf.length < 2000) return { text: '' };
  let lastErr;
  for (const model of STT_MODELS) {
    const fd = new FormData();
    fd.append('file', new Blob([buf], { type }), type === 'audio/wav' ? 'speech.wav' : 'speech.webm');
    if (prompt) fd.append('prompt', String(prompt).slice(0, 400));
    fd.append('model', model);
    fd.append('language', 'ru');
    fd.append('response_format', 'json');
    try {
      const r = await groqFetch('/audio/transcriptions', { method: 'POST', body: fd }, key);
      return { text: String(r.text || '').trim() };
    } catch (e) { lastErr = e; if (e.status !== 400 && e.status !== 404) throw e; }
  }
  throw lastErr;
}

/* ---------- голосовые заметки ---------- */
function stamp() {
  const d = new Date(); const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
}
async function voiceSave(data) {
  const file = path.join(VOICE_DIR, `Заметка ${stamp()}.webm`);
  await fsp.writeFile(file, Buffer.from(data));
  return file;
}
async function voiceList() {
  try {
    const names = (await fsp.readdir(VOICE_DIR)).filter(n => /\.(webm|ogg|wav|mp3|m4a)$/i.test(n));
    const out = [];
    for (const n of names) {
      const p = path.join(VOICE_DIR, n);
      const st = await fsp.stat(p);
      out.push({ name: n.replace(/\.[^.]+$/, ''), path: p, mtime: st.mtimeMs, size: st.size });
    }
    return out.sort((a, b) => b.mtime - a.mtime);
  } catch (_) { return []; }
}
async function voiceDelete(p) {
  const abs = path.resolve(p);
  if (!abs.startsWith(VOICE_DIR + path.sep)) throw new Error('Неверный файл');
  await fsp.unlink(abs); return true;
}

/* ---------- фото и флешки ---------- */
async function lsblk(args) {
  try { return JSON.parse(await run('lsblk', ['-J', '-b', ...args])).blockdevices || []; } catch (_) { return []; }
}
function flatten(list, parent = null, out = []) {
  for (const d of list) { d.parent = parent; out.push(d); if (d.children) flatten(d.children, d, out); }
  return out;
}
async function liveMediumDisk() {
  let src = '';
  try { src = (await run('findmnt', ['-no', 'SOURCE', '/run/live/medium'])).trim(); } catch (_) { src = ''; }
  // при загрузке «в память» (toram) там копия в памяти — ищем флешку по метке образа
  if (!src.startsWith('/dev/')) {
    const all = flatten(await lsblk(['-o', 'NAME,PATH,FSTYPE,LABEL,TYPE']));
    const hit = all.find(d => d.fstype === 'iso9660' && d.label === 'VYACHESLAVOS');
    src = hit ? hit.path : '';
  }
  if (!src) return null;
  try {
    const pk = (await run('lsblk', ['-no', 'PKNAME', src]).catch(() => '')).trim().split('\n')[0];
    return '/dev/' + (pk || path.basename(src));
  } catch (_) { return null; }
}
async function usbList() {
  const live = await liveMediumDisk();
  const all = flatten(await lsblk(['-o', 'NAME,PATH,RM,HOTPLUG,TYPE,FSTYPE,LABEL,MOUNTPOINT,SIZE,TRAN']));
  const out = [];
  for (const d of all) {
    if (d.type !== 'part' && !(d.type === 'disk' && d.fstype)) continue;
    const disk = d.type === 'disk' ? d : d.parent;
    if (!disk || !(disk.rm || disk.hotplug || disk.tran === 'usb')) continue;
    if (live && (disk.path === live)) continue;          // флешку с системой не трогаем
    if (!d.fstype || /swap|LVM|crypto/i.test(d.fstype)) continue;
    out.push({ path: d.path, label: d.label || '', size: d.size, mountpoint: d.mountpoint || null });
  }
  return out;
}
async function usbMount(dev) {
  if (!/^\/dev\/[a-z0-9]+$/.test(dev)) throw new Error('bad device');
  try {
    const out = await run('udisksctl', ['mount', '--no-user-interaction', '-b', dev], { timeout: 20000 });
    const m = out.match(/ at (.+?)\.?\s*$/m); return m ? m[1] : null;
  } catch (e) {
    const m = String(e.stderr || '').match(/already mounted at [`'"]?(.+?)[`'"]?\.?\s*$/m);
    return m ? m[1] : null;
  }
}
async function usbUnmount(dev) {
  try { await run('udisksctl', ['unmount', '--no-user-interaction', '-b', dev]); await run('udisksctl', ['power-off', '--no-user-interaction', '-b', dev]).catch(() => {}); return true; } catch (_) { return false; }
}
async function photosList(dir) {
  const root = dir ? path.resolve(dir) : PHOTO_DIR;
  const allowed = [PHOTO_DIR, '/media', '/run/media'].some(a => root === a || root.startsWith(a + path.sep));
  if (!allowed) throw new Error('Папка недоступна');
  const out = [];
  async function walk(d, depth) {
    if (depth > 4 || out.length >= 3000) return;
    let ents; try { ents = await fsp.readdir(d, { withFileTypes: true }); } catch (_) { return; }
    for (const e of ents) {
      if (e.name.startsWith('.')) continue;
      const p = path.join(d, e.name);
      if (e.isDirectory()) await walk(p, depth + 1);
      else if (IMAGE_EXT.has(path.extname(e.name).toLowerCase())) {
        try { const st = await fsp.stat(p); out.push({ path: p, name: e.name, mtime: st.mtimeMs }); } catch (_) { /* пропуск */ }
      }
    }
  }
  await walk(root, 0);
  return out.sort((a, b) => b.mtime - a.mtime);
}
async function photosImport(files) {
  let n = 0;
  for (const f of files || []) {
    const src = path.resolve(f);
    if (!['/media', '/run/media'].some(a => src.startsWith(a + path.sep))) continue;
    const dst = path.join(PHOTO_DIR, path.basename(src));
    try { await fsp.copyFile(src, dst, fs.constants.COPYFILE_EXCL); n++; } catch (_) { /* уже есть */ }
  }
  return n;
}

/* ---------- имя компьютера ---------- */
const TRANSLIT = { а: 'a', б: 'b', в: 'v', г: 'g', д: 'd', е: 'e', ё: 'e', ж: 'zh', з: 'z', и: 'i', й: 'y', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p', р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'h', ц: 'ts', ч: 'ch', ш: 'sh', щ: 'sch', ъ: '', ы: 'y', ь: '', э: 'e', ю: 'yu', я: 'ya' };
function hostnameFrom(pretty) {
  const h = String(pretty || '').toLowerCase().split('').map(c => TRANSLIT[c] !== undefined ? TRANSLIT[c] : c).join('')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40).replace(/-+$/, '');
  return h || 'vyacheslav-pc';
}
async function getHostname() {
  let pretty = '';
  try { pretty = ((await fsp.readFile('/etc/machine-info', 'utf8')).match(/PRETTY_HOSTNAME="?([^"\n]*)/) || [])[1] || ''; } catch (_) { /* нет файла */ }
  return { hostname: os.hostname(), pretty };
}
async function setHostname(pretty) {
  pretty = String(pretty || '').replace(/[\u0000-\u001f"]/g, '').trim().slice(0, 60);
  if (!pretty) throw new Error('Пустое имя');
  const h = hostnameFrom(pretty);
  try { await run('sudo', ['-n', '/usr/lib/vos/vos-sys', 'hostname', h, pretty], { timeout: 15000 }); return { ok: true, hostname: h, pretty }; }
  catch (e) { return { ok: false, hostname: h, pretty, error: String(e.stderr || e.message).slice(0, 200) }; }
}

/* ---------- резервная копия на флешку ---------- */
const BACKUP_ITEMS = ['.config/vyacheslav-os', 'Фото', 'Голосовые заметки'];
const onUsb = p => ['/media', '/run/media'].some(a => path.resolve(p).startsWith(a + path.sep));
async function backupCreate(dir, withPhotos = true) {
  if (!onUsb(dir)) throw new Error('Копию можно сохранить только на флешку');
  const d = new Date(), pad = n => String(n).padStart(2, '0');
  const file = path.join(dir, 'ВячеславOS-копия-' + d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + '.tar.gz');
  const items = [];
  for (const it of withPhotos ? BACKUP_ITEMS : BACKUP_ITEMS.slice(0, 1)) if (fs.existsSync(path.join(HOME, it))) items.push(it);
  await run('tar', ['-czf', file, '-C', HOME, '--exclude=*.tmp', ...items], { timeout: 15 * 60000 });
  await run('sync', []).catch(() => {});
  const st = await fsp.stat(file);
  return { file, size: st.size };
}
async function backupList(dir) {
  if (!onUsb(dir)) return [];
  try {
    const names = (await fsp.readdir(dir)).filter(n => /^ВячеславOS-копия-.*\.tar\.gz$/.test(n.normalize('NFC')));
    const out = [];
    for (const n of names) { const st = await fsp.stat(path.join(dir, n)); out.push({ file: path.join(dir, n), name: n, size: st.size, mtime: st.mtimeMs }); }
    return out.sort((a, b) => b.mtime - a.mtime);
  } catch (_) { return []; }
}
async function backupRestore(file) {
  if (!onUsb(file) || !/\.tar\.gz$/.test(file)) throw new Error('Неверный файл копии');
  // проверяем, что внутри только наши папки — никаких путей наружу
  const list = (await run('tar', ['-tzf', file], { timeout: 120000 })).split('\n').filter(Boolean);
  if (!list.every(p => !p.startsWith('/') && !p.split('/').includes('..') && BACKUP_ITEMS.some(it => p === it || p === it + '/' || p.startsWith(it + '/')))) throw new Error('Файл не похож на копию ВячеславOS');
  await run('tar', ['-xzf', file, '-C', HOME], { timeout: 15 * 60000 });
  return true;
}

/* ---------- здоровье диска (SMART) ---------- */
// Разбирает ответ «smartctl -j -i -H -A». Возвращает простой вердикт:
// good — всё хорошо, warn — диск начал изнашиваться, bad — может скоро
// сломаться, unknown — диск не отдаёт данные (часто у флешек).
function parseSmart(j) {
  const res = { status: 'unknown', details: {} };
  if (!j || typeof j !== 'object' || j.vos_error) return res;
  const d = res.details;
  d.model = String(j.model_name || j.model_family || '').trim();
  d.hdd = typeof j.rotation_rate === 'number' ? j.rotation_rate > 0 : null;
  if (j.power_on_time && Number.isFinite(j.power_on_time.hours)) d.hours = j.power_on_time.hours;
  if (j.temperature && Number.isFinite(j.temperature.current)) d.temp = j.temperature.current;
  const table = (j.ata_smart_attributes && j.ata_smart_attributes.table) || [];
  const raw = id => { const a = table.find(x => x.id === id); if (!a || !a.raw) return null; const v = Number(a.raw.value); return Number.isFinite(v) ? v : null; };
  const nv = j.nvme_smart_health_information_log;
  const passed = j.smart_status ? j.smart_status.passed : null;
  if (passed === null && !table.length && !nv) return res;
  d.realloc = raw(5); d.pending = raw(197); d.uncorrectable = raw(198); d.reported = raw(187); d.spinRetry = raw(10);
  if (nv) { d.mediaErrors = nv.media_errors; d.wear = nv.percentage_used; if (d.hours == null) d.hours = nv.power_on_hours; }
  // старые диски иногда пишут в «сырое» значение мусор в старших байтах — берём младшие 16 бит
  for (const k of ['realloc', 'pending', 'uncorrectable', 'reported', 'spinRetry']) if (d[k] != null && d[k] > 0xffff) d[k] = d[k] & 0xffff;
  const failingNow = table.some(a => a.when_failed === 'now');
  const failedPast = table.some(a => a.when_failed === 'past');
  const n = v => v || 0;
  const reasons = [];
  if (n(d.realloc)) reasons.push('переназначенных секторов: ' + d.realloc);
  if (n(d.pending)) reasons.push('нестабильных секторов: ' + d.pending);
  if (n(d.uncorrectable)) reasons.push('нечитаемых секторов: ' + d.uncorrectable);
  if (n(d.reported)) reasons.push('ошибок чтения: ' + d.reported);
  if (n(d.spinRetry)) reasons.push('повторных раскруток: ' + d.spinRetry);
  if (nv && n(nv.critical_warning)) reasons.push('предупреждение NVMe: ' + nv.critical_warning);
  if (nv && n(nv.media_errors)) reasons.push('ошибок носителя: ' + nv.media_errors);
  if (passed === false) reasons.push('диск сам сообщает о неисправности');
  if (failingNow) reasons.push('показатель ниже допустимого');
  if (d.temp != null && d.temp >= 55) reasons.push('температура ' + d.temp + ' °C');
  if (passed === false || failingNow || n(d.pending) >= 10 || n(d.realloc) >= 100 || n(d.uncorrectable) >= 10 || (nv && n(nv.critical_warning))) res.status = 'bad';
  else if (reasons.length || failedPast || (nv && n(nv.wear) >= 90)) res.status = 'warn';
  else res.status = 'good';
  if (failedPast && !reasons.length) reasons.push('раньше был сбой');
  d.reasons = reasons;
  return res;
}
async function diskHealth(dev) {
  if (!/^\/dev\/(sd[a-z]|hd[a-z]|vd[a-z]|nvme\d+n\d+)$/.test(String(dev || ''))) throw new Error('bad device');
  let out = '';
  try { out = await run('sudo', ['-n', '/usr/lib/vos/vos-sys', 'smart', dev], { timeout: 30000 }); } catch (e) { out = e.stdout || ''; }
  let j = null;
  try { j = JSON.parse(out); } catch (_) { j = null; }
  return { dev, checked: Date.now(), ...parseSmart(j) };
}
async function internalDisks() {
  return (await installerDisks()).filter(d => !d.usb && !d.isLiveMedium);
}

/* ---------- установщик ---------- */
async function installerDisks() {
  const live = await liveMediumDisk();
  const disks = await lsblk(['-d', '-o', 'NAME,PATH,SIZE,MODEL,TRAN,RM,HOTPLUG,TYPE,RO']);
  return disks
    .filter(d => d.type === 'disk' && !/^(loop|sr|zram|ram|fd)/.test(d.name) && !d.ro)
    .map(d => ({
      path: d.path, size: d.size, model: (d.model || '').trim() || 'Диск',
      usb: d.tran === 'usb' || !!d.rm || !!d.hotplug, isLiveMedium: live === d.path
    }));
}
let installProc = null;
function installerStart(dev, onEvent) {
  if (installProc) throw new Error('Установка уже идёт');
  if (!/^\/dev\/[a-z0-9]+$/.test(dev)) throw new Error('bad device');
  installProc = spawn('sudo', ['-n', '/usr/lib/vos/vos-install', dev], { env: { ...process.env, LC_ALL: 'C.UTF-8' } });
  let buf = '';
  const onData = chunk => {
    buf += chunk.toString();
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      let m;
      if ((m = line.match(/^PROGRESS\s+(\d+)\s*(.*)$/))) onEvent({ type: 'progress', percent: +m[1], text: m[2] });
      else if ((m = line.match(/^ERROR\s+(.*)$/))) onEvent({ type: 'error', text: m[1] });
      else if (line === 'DONE') onEvent({ type: 'done' });
    }
  };
  installProc.stdout.on('data', onData);
  installProc.stderr.on('data', d => onEvent({ type: 'log', text: d.toString().slice(0, 500) }));
  installProc.on('close', code => { installProc = null; if (code !== 0) onEvent({ type: 'error', text: 'Установщик завершился с ошибкой (код ' + code + ').' }); });
  return true;
}

module.exports = {
  CONF_DIR, VOICE_DIR, PHOTO_DIR,
  detectMode, readSettingsSync, storeGet, storeSet,
  hashPassword, verifyPassword,
  splitTerse, parseWifiList, wifiStatus, wifiScan, wifiConnect, wifiDisconnect, wifiSetEnabled,
  getVolume, setVolume, setMute, power, setTimezone, screenWake,
  listVoices, tts, httpGetJson, httpGetText, aiChat, aiTranscribe,
  tgSend, tgChats, telegram, rustdesk, voiceStart, voiceCtl, voiceCleanup,
  voiceSave, voiceList, voiceDelete, usbList, usbMount, usbUnmount, photosList, photosImport,
  installerDisks, installerStart, parseSmart, diskHealth, internalDisks,
  hostnameFrom, getHostname, setHostname, backupCreate, backupList, backupRestore
};
