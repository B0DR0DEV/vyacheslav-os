/*
 * screens.js — полноэкранные экраны:
 *   заставка с логотипом и прогресс-баром → экран блокировки с паролем →
 *   приветствие по имени → рабочий стол. А также мастер установки на диск.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const LOGO = () => VOS.logoSVG(120, true);

  /* ---------- заставка ---------- */
  function splash() {
    const bar = el('div.sp-bar-fill');
    const txt = el('div.sp-text', { text: 'Запуск…' });
    const s = el('div#splash', null, el('div.sp-logo', { html: VOS.logoSVG(150, true) }), el('div.sp-title', { html: 'Вячеслав<b>OS</b>' }), el('div.sp-bar', null, bar), txt);
    document.body.append(s);
    return {
      set(p, t) { bar.style.width = p + '%'; if (t) txt.textContent = t; },
      async done() { bar.style.width = '100%'; await sleep(350); s.classList.add('fade'); await sleep(600); s.remove(); }
    };
  }

  /* ---------- экран блокировки ---------- */
  function lock() {
    if (VOS.$('#lock')) return;
    VOS.wm.closeStart(); VOS.wm.closePopups(); if (VOS.assistant) VOS.assistant.hide();
    const s = VOS.settings;
    let pw = '';
    const clock = el('div.lk-time'), date = el('div.lk-date');
    const dots = el('div.lk-dots');
    const msg = el('div.lk-msg', { text: 'Введите пароль' });
    const tick = () => { const d = new Date(); clock.textContent = VOS.fmtTime(d); date.textContent = VOS.fmtDateLong(d); };
    tick(); const iv = setInterval(tick, 5000);
    const draw = () => { dots.textContent = ''; for (let i = 0; i < Math.max(4, pw.length); i++) dots.append(el('span' + (i < pw.length ? '.on' : ''))); };
    draw();
    const press = k => {
      VOS.sound.click();
      if (k === '⌫') pw = pw.slice(0, -1);
      else if (k === '✓') return check();
      else if (pw.length < 32) pw += k;
      draw();
      // пароль по умолчанию (4 цифры) проверяем сразу, без кнопки ✓
      if (!VOS.settings.password && pw.length === 4) check();
    };
    async function check() {
      const ok = await B.call('verifyPassword', pw, VOS.settings.password);
      if (ok) { root._cleanup(); unlock(root); return; }
      pw = ''; draw(); msg.textContent = 'Неверный пароль. Попробуйте ещё раз.'; msg.classList.add('err');
      root.querySelector('.lk-card').classList.add('shake'); VOS.sound.error();
      setTimeout(() => root.querySelector('.lk-card').classList.remove('shake'), 500);
    }
    const onKey = e => {
      if (!VOS.$('#lock') || VOS.$('.alarm-overlay')) return;
      if (VOS.settings.noPassword) { if (e.key.length === 1 || e.key === 'Enter' || e.key === ' ') { root._cleanup(); unlock(root); } return; }
      if (/^[0-9a-zа-яё]$/i.test(e.key)) press(e.key);
      else if (e.key === 'Backspace') press('⌫');
      else if (e.key === 'Enter') press('✓');
    };
    document.addEventListener('keydown', onKey);
    const pad = el('div.lk-pad');
    ['1', '2', '3', '4', '5', '6', '7', '8', '9', '⌫', '0', '✓'].forEach(k => { const b = el('button.lk-key' + (k === '✓' ? '.ok' : k === '⌫' ? '.fn' : ''), { text: k === '✓' || k === '⌫' ? '' : k, onclick: () => press(k) }); if (k === '✓') b.innerHTML = VOS.glyph('arrow'); if (k === '⌫') b.innerHTML = VOS.glyph('backspace'); pad.append(b); });
    const enterBtn = el('button.btn.huge.primary.lk-enter', { text: '@arrow', onclick: () => { root._cleanup(); unlock(root); } });
    enterBtn.append('Войти');
    const root = el('div#lock' + (s.noPassword ? '.nopass' : ''), null,
      el('div.lk-left', null, clock, date, el('div.lk-hol', { text: VOS.todayHoliday() || '' })),
      el('div.lk-card', null,
        el('div.avatar.big', { text: (s.name || 'В')[0].toUpperCase() }),
        el('div.lk-name', { text: s.name }),
        s.noPassword ? el('div.lk-msg', { text: 'Нажмите «Войти» или любую клавишу' }) : msg,
        s.noPassword ? enterBtn : dots, s.noPassword ? null : pad,
        !s.password && !s.noPassword ? el('div.lk-hint', { text: 'Подсказка: пароль 1234. Его можно поменять в Настройках.' }) : null),
      el('button.lk-power', { title: 'Выключить', text: '⏻ Выключить', onclick: () => VOS.wm.askPower('poweroff') }));
    root._cleanup = () => { clearInterval(iv); document.removeEventListener('keydown', onKey); };
    document.body.append(root);
  }
  const isLocked = () => !!VOS.$('#lock:not(.unlocking)');
  // разблокировать без приветствия (голосовая команда на экране блокировки)
  function unlockQuiet() {
    const l = VOS.$('#lock:not(.unlocking)'); if (!l) return;
    l._cleanup(); l.classList.add('unlocking'); setTimeout(() => l.remove(), 700);
  }

  /* ---------- приветствие ---------- */
  async function unlock(lockEl) {
    const s = VOS.settings, d = new Date();
    const hol = VOS.todayHoliday();
    const meds = (await VOS.store.get('meds', [])).filter(m => m.enabled !== false);
    const doses = meds.reduce((n, m) => n + m.times.length, 0);
    const g = el('div#greet', null,
      el('div.gr-logo', { html: VOS.logoSVG(96, true) }),
      el('div.gr-hello', { text: VOS.greeting(d) + ', ' + s.name + '!' }),
      el('div.gr-date', { text: 'Сегодня ' + VOS.fmtDateLong(d).toLowerCase() + ', ' + VOS.fmtTime(d) }),
      hol ? el('div.gr-hol', { text: hol }) : null,
      doses ? el('div.gr-hol', { text: 'Сегодня лекарств: ' + doses + ' ' + VOS.plural(doses, 'приём', 'приёма', 'приёмов') }) : null);
    document.body.append(g);
    lockEl.classList.add('unlocking'); setTimeout(() => lockEl.remove(), 700);
    // утренняя сводка — один раз в день при первом входе с 5 до 12 часов
    const brief = await VOS.store.get('briefDone', '');
    const morning = s.morningBrief && VOS.briefing && d.getHours() >= 5 && d.getHours() < 12 && brief !== VOS.dateKey(d);
    if (s.voiceGreeting && !morning) VOS.speak(VOS.greeting(d) + ', ' + s.name + '! ' + (hol ? 'Сегодня ' + hol + '. ' : ''));
    await sleep(2600);
    g.classList.add('fade'); setTimeout(() => g.remove(), 600);
    if (morning) { await VOS.store.set('briefDone', VOS.dateKey(d)); VOS.briefing.run({ open: true, speak: true }); }
  }

  /* ---------- мастер установки ---------- */
  function installer(fromBoot = false) {
    if (VOS.$('#installer')) return;
    const root = el('div#installer');
    const card = el('div.in-card');
    root.append(el('div.in-top', null, el('span', { html: VOS.logoSVG(44) }), el('b', { text: 'Установка ВячеславOS' })), card);
    document.body.append(root);
    const close = () => root.remove();
    let disk = null;

    function step(title, ...content) { card.textContent = ''; card.append(el('h1', { text: title }), ...content); }

    function welcome() {
      step('Добро пожаловать!',
        el('p.in-lead', { text: 'Сейчас ВячеславOS работает с флешки. Можно установить её на жёсткий диск ноутбука — тогда флешка больше не понадобится, а все настройки и записи будут сохраняться.' }),
        el('div.in-btns', null,
          el('button.btn.huge.primary', { text: '💽 Установить на диск', onclick: chooseDisk }),
          el('button.btn.huge', { text: fromBoot ? '👀 Сначала попробовать' : '✕ Отмена', onclick: () => { close(); if (fromBoot) lock(); } }),
          fromBoot ? el('button.btn.huge', { text: '⏻ Выключить', onclick: () => VOS.wm.askPower('poweroff') }) : null));
    }
    async function chooseDisk() {
      step('Куда установить?', el('p', { text: 'Ищу диски…' }));
      const disks = await B.call('installerDisks').catch(() => []);
      const list = el('div.in-disks');
      disks.forEach(d => {
        const blocked = d.isLiveMedium;
        list.append(el('button.in-disk' + (blocked ? '.blocked' : ''), { disabled: blocked, onclick: () => { disk = d; warn(); } },
          el('span.in-disk-icon', { html: VOS.glyph(d.usb ? 'usb' : 'disk') }),
          el('span.grow', null, el('b', { text: (d.usb ? 'Флешка / внешний диск' : 'Жёсткий диск ноутбука') + ' — ' + VOS.fmtSize(d.size) }), el('div.muted', { text: d.model + ' (' + d.path + ')' }), d.health = el('div.in-disk-health')),
          el('span.in-disk-note', { text: blocked ? 'С неё сейчас идёт загрузка' : 'Выбрать →' })));
        // здоровье диска узнаём в фоне — список дисков не ждёт
        if (!blocked && !d.usb && VOS.disk) {
          d.health.textContent = 'Проверяю состояние…';
          d.smart = VOS.disk.check(d.path).then(r => { d.smartResult = r; d.health.textContent = ''; const b = VOS.disk.badge(r); if (b) d.health.append(b); return r; });
        }
      });
      if (!disks.filter(d => !d.isLiveMedium).length) list.append(el('p', { text: 'Подходящих дисков не найдено.' }));
      step('Куда установить?', el('p', { text: 'Обычно это «Жёсткий диск ноутбука».' }), list, el('div.in-btns', null, el('button.btn.big', { text: '◀ Назад', onclick: welcome })));
    }
    async function warn() {
      const r = disk.smart ? await disk.smart : null;
      const agree = el('input.big-check', { type: 'checkbox' });
      const go = el('button.btn.huge.danger', { text: 'Стереть и установить', disabled: true });
      agree.onchange = () => { go.disabled = !agree.checked; };
      go.onclick = async () => { await VOS.saveSettings({ setupDone: false }); run(); };
      step('Внимание!',
        r && (r.status === 'warn' || r.status === 'bad') ? VOS.disk.card(r) : null,
        r && r.status === 'bad' ? el('p.muted', { text: 'Установить всё равно можно, но система на таком диске может работать с ошибками, а записи — потеряться. Надёжнее сначала заменить диск.' }) : null,
        el('div.in-warn', null,
          el('p', null, 'Всё, что сейчас есть на диске ', el('b', { text: disk.model + ' (' + VOS.fmtSize(disk.size) + ')' }), ', будет ', el('b', { text: 'удалено навсегда' }), ':'),
          el('p', { text: 'Windows или другая система, фотографии, документы, музыка — всё.' }),
          el('p', { text: 'Если на ноутбуке есть что-то нужное — сначала скопируйте это на флешку или внешний диск.' })),

        el('div.in-foot', null,
          el('label.check.big', null, agree, ' Я понимаю, что все данные на этом диске будут удалены'),
          el('div.in-btns', null, el('button.btn.big', { text: '◀ Назад', onclick: chooseDisk }), go)));
    }
    function run() {
      const bar = el('div.sp-bar-fill'), txt = el('div.in-status', { text: 'Подготовка…' });
      step('Устанавливаю…', el('p', { text: 'Это займёт 5–15 минут. Не выключайте ноутбук и не вынимайте флешку.' }), el('div.sp-bar.in-bar', null, bar), txt);
      let finished = false;
      B.on('install-progress', ev => {
        if (finished) return;
        if (ev.type === 'progress') { bar.style.width = ev.percent + '%'; txt.textContent = ev.text + ' — ' + ev.percent + '%'; }
        if (ev.type === 'error') { finished = true; failed(ev.text); }
        if (ev.type === 'done') { finished = true; doneScreen(); }
      });
      B.call('installerStart', disk.path).catch(e => { finished = true; failed(String(e.message || e)); });
    }
    function failed(text) {
      step('Установка не удалась', el('p', { text: text }), el('p.muted', { text: 'Ваш ноутбук не пострадал больше, чем было предупреждено. Попробуйте ещё раз или продолжайте работать с флешки.' }),
        el('div.in-btns', null, el('button.btn.huge', { text: 'Попробовать ещё раз', onclick: chooseDisk }), el('button.btn.huge', { text: 'Закрыть', onclick: () => { close(); if (fromBoot) lock(); } })));
    }
    function doneScreen() {
      VOS.sound.win();
      step('Готово!', el('p.in-lead', { text: 'ВячеславOS установлена. Нажмите «Перезагрузить», а когда экран погаснет — выньте флешку. После включения компьютер сам спросит имя, пароль и поможет всё настроить.' }),
        el('div.in-btns', null, el('button.btn.huge.primary', { text: '🔄 Перезагрузить', onclick: () => B.call('power', 'reboot') }),
          el('button.btn.huge', { text: '⏻ Выключить', onclick: () => B.call('power', 'poweroff') })));
      VOS.speak('Установка завершена. Нажмите перезагрузить и выньте флешку.', { force: true });
    }
    welcome();
  }

  /* ---------- запуск ---------- */
  async function boot() {
    const sp = splash();
    try {
      sp.set(15, 'Читаю настройки…');
      VOS.mode = await B.call('mode').catch(() => ({ mode: 'installed' }));
      await VOS.loadSettings();
      // ключ Groq, встроенный в образ, — если свой ещё не введён
      if (!VOS.settings.groqKey) { const k = await B.call('presetGroqKey').catch(() => ''); if (k) await VOS.saveSettings({ groqKey: k }); }
      await sleep(300);
      sp.set(45, 'Готовлю рабочий стол…');
      if (VOS.mode.live && !VOS.app('install')) VOS.registerApp({ id: 'install', title: 'Установить систему', open(w) { setTimeout(() => VOS.wm.close(w), 0); installer(); } });
      VOS.wm.initShell();
      if (VOS.mode.live) {
        const chip = VOS.$('#tray-live');
        chip.classList.remove('hidden');
        chip.onclick = async () => {
          const r = await VOS.ui.dialog({ icon: '💡', title: 'Пробный режим',
            text: VOS.mode.persistent ? 'Система работает с флешки. Ваши записи сохраняются на флешке. Жёсткий диск ноутбука не используется.'
              : 'Система работает с флешки. Всё, что вы сделаете, пропадёт после выключения. Жёсткий диск ноутбука не используется.',
            buttons: [{ label: 'Понятно', value: false }, { label: '💽 Установить на диск', value: true, primary: true }] });
          if (r) installer();
        };
      }
      await sleep(300);
      sp.set(70, 'Проверяю интернет…');
      VOS.backend.call('setVolume', VOS.settings.volume).catch(() => {});
      await sleep(400);
      sp.set(90, 'Почти готово…');
      VOS.scheduler.start();
      await sleep(500);
    } catch (e) { console.error(e); }
    await sp.done();
    if (VOS.mode.mode === 'install') installer(true);
    else if (VOS.mode.mode === 'installed' && !VOS.settings.setupDone && VOS.oobe) VOS.oobe.start();
    else lock();
  }

  VOS.screens = { lock, installer, isLocked, unlockQuiet, greet: () => unlock(el('div')) };
  document.addEventListener('DOMContentLoaded', boot);
})();
