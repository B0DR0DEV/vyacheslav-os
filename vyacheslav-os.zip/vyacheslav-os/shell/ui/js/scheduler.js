/*
 * scheduler.js — каждые 10 секунд проверяет будильники и лекарства.
 * При срабатывании: будит экран, показывает большое окно поверх всего
 * (даже поверх экрана блокировки), играет мелодию и говорит голосом.
 */
(function () {
  'use strict';
  const VOS = window.VOS;
  const fired = new Set();        // чтобы не сработать дважды в одну минуту
  const snoozed = [];             // { at: ms, kind, payload }
  let active = 0;

  async function fire(kind, payload) {
    active++;
    VOS.backend.call('screenWake').catch(() => {});
    const stop = VOS.sound.loop(kind === 'alarm' ? 'alarm' : 'remind');
    const now = new Date();
    let title, text, say, icon;
    if (kind === 'alarm') {
      icon = '⏰'; title = payload.label || 'Будильник';
      text = 'Сейчас ' + VOS.fmtTime(now);
      say = VOS.greeting(now) + ', ' + VOS.settings.name + '! Сейчас ' + VOS.timeWords(now) + '. ' + (payload.label ? payload.label + '.' : '');
    } else {
      icon = '💊'; title = 'Пора принять лекарство';
      text = payload.med.name + (payload.med.dose ? ' — ' + payload.med.dose : '') + (payload.med.note ? ' (' + payload.med.note + ')' : '');
      say = VOS.settings.name + ', пора принять лекарство: ' + payload.med.name + (payload.med.dose ? ', ' + payload.med.dose : '') + '.';
    }
    const buttons = kind === 'alarm'
      ? [{ label: '😴 Через 5 минут', value: 'snooze' }, { label: '✅ Выключить', value: 'ok', primary: true }]
      : [{ label: '⏰ Напомнить через 10 минут', value: 'snooze' }, { label: '✅ Принял', value: 'ok', primary: true }];
    const box = VOS.ui.bigAlert({ icon, title, text, buttons });
    // голос — сразу и потом каждые 40 секунд, пока не нажмут кнопку (до 5 раз)
    const speakOK = kind === 'alarm' || VOS.settings.speakReminders;
    let n = 0;
    const talk = () => { if (speakOK && n++ < 5) VOS.speak(say, { force: true }); };
    setTimeout(talk, 1500);
    const iv = setInterval(talk, 40000);
    const autoClose = setTimeout(() => box.close(), 15 * 60 * 1000);   // через 15 минут тишины — отложить
    const res = await box.promise;
    clearInterval(iv); clearTimeout(autoClose); stop(); VOS.stopSpeaking();
    active--;
    if (res === 'ok') {
      if (kind === 'med') { await VOS.meds.mark(payload.med.id, payload.time, 'taken'); VOS.ui.toast('Отмечено: ' + payload.med.name); }
    } else {
      const mins = kind === 'alarm' ? 5 : 10;
      snoozed.push({ at: Date.now() + mins * 60000, kind, payload });
      VOS.ui.toast('Напомню через ' + mins + ' минут');
    }
  }

  // мягкие ежедневные напоминания: день рождения, счётчики, запас лекарств
  async function onceToday(key) {
    const done = await VOS.store.get('dailyDone', {});
    const day = VOS.dateKey(new Date());
    if (done[key] === day) return false;
    done[key] = day;
    for (const k of Object.keys(done)) if (done[k] !== day) delete done[k];
    await VOS.store.set('dailyDone', done);
    return true;
  }
  async function daily(now) {
    if (active || (VOS.screens.isLocked && VOS.screens.isLocked())) return;   // не мешаем, ждём входа
    const h = now.getHours();
    if (h >= 9 && VOS.contacts) {
      for (const x of await VOS.contacts.birthdays(0)) {
        if (!(await onceToday('bday-' + x.c.id))) continue;
        active++;
        const box = VOS.ui.bigAlert({ icon: '🎉', title: 'День рождения!', text: 'Сегодня день рождения празднует ' + x.c.name + (x.age ? ', исполняется ' + x.age + ' ' + VOS.plural(x.age, 'год', 'года', 'лет') : '') + '.',
          buttons: [{ label: 'Позже', value: 'later' }, { label: '📞 Позвонить и поздравить', value: 'call', primary: true }] });
        VOS.speak('Сегодня день рождения празднует ' + x.c.name + '. Позвоним, поздравим?', { force: true });
        const r = await box.promise; active--;
        if (r === 'call') VOS.wm.open('call', { id: x.c.id });
        return;
      }
    }
    if (h >= 10 && VOS.metersApi) {
      const due = await VOS.metersApi.dueToday();
      for (const r of due) {
        if (!(await onceToday('rem-' + r.id))) continue;
        active++;
        const box = VOS.ui.bigAlert({ icon: '⏰', title: 'Не забудьте', text: r.title, buttons: [{ label: 'Напомнить позже', value: 'later' }, { label: '✅ Сделано', value: 'ok', primary: true }] });
        VOS.speak(VOS.settings.name + ', не забудьте: ' + r.title.toLowerCase() + '.', { force: true });
        const res = await box.promise; active--;
        if (res === 'ok') await VOS.metersApi.markDone(r.id);
        else snoozed.push({ at: Date.now() + 2 * 3600e3, kind: 'gentle', payload: r });
        return;
      }
    }
    if (h >= 11 && VOS.meds && VOS.meds.low) {
      const low = await VOS.meds.low(4);
      if (low.length && await onceToday('lowmeds')) {
        const list = low.map(m => m.name + ' (на ' + VOS.meds.daysLeft(m) + ' ' + VOS.plural(VOS.meds.daysLeft(m), 'день', 'дня', 'дней') + ')').join(', ');
        VOS.assistant.announce('Заканчиваются лекарства: ' + list + '. Нужно купить.', { title: 'Лекарства' });
        // и родным, которые помогают, — чтобы купили
        const helpers = (await VOS.store.get('contacts', [])).filter(c => c.helper !== false && c.tgChat);
        for (const c of helpers) VOS.notify(c, '💊 У ' + VOS.settings.name + ' заканчиваются лекарства: ' + list);
      }
    }
    // раз в неделю — тихая проверка жёсткого диска
    if (h >= 12 && VOS.disk && !diskBusy) { diskBusy = true; VOS.disk.weekly().catch(e => console.error(e)).finally(() => { diskBusy = false; }); }
  }
  let diskBusy = false;

  async function tick() {
    const now = new Date();
    const hm = VOS.fmtTime(now), day = VOS.dateKey(now);
    const wd = (now.getDay() + 6) % 7;     // 0 = понедельник
    // будильники
    const alarms = await VOS.store.get('alarms', []);
    let changed = false;
    for (const a of alarms) {
      if (!a.enabled || a.time !== hm) continue;
      if (a.days.length && !a.days.includes(wd)) continue;
      const key = 'a:' + a.id + ':' + day + ':' + hm;
      if (fired.has(key)) continue;
      fired.add(key);
      if (!a.days.length) { a.enabled = false; changed = true; }   // одноразовый
      fire('alarm', a);
    }
    if (changed) VOS.store.set('alarms', alarms);
    // лекарства
    const meds = await VOS.store.get('meds', []);
    const log = (await VOS.store.get('medlog', {}))[day] || {};
    for (const m of meds) {
      if (m.enabled === false) continue;
      for (const t of m.times) {
        if (t !== hm || log[m.id + '@' + t]) continue;
        const key = 'm:' + m.id + ':' + day + ':' + t;
        if (fired.has(key)) continue;
        fired.add(key);
        fire('med', { med: m, time: t });
      }
    }
    // отложенные
    for (let i = snoozed.length - 1; i >= 0; i--) {
      if (snoozed[i].at > Date.now()) continue;
      const s = snoozed.splice(i, 1)[0];
      if (s.kind === 'gentle') {
        VOS.ui.bigAlert({ icon: '⏰', title: 'Не забудьте', text: s.payload.title, buttons: [{ label: '✅ Хорошо', value: 'ok', primary: true }] })
          .promise.then(() => VOS.metersApi && VOS.metersApi.markDone(s.payload.id));
      } else fire(s.kind, s.payload);
    }
    daily(now).catch(e => console.error(e));
    if (fired.size > 500) fired.clear();
  }

  VOS.scheduler = { start() { tick(); setInterval(tick, 10000); }, fire, busy: () => active > 0 };
})();
