/* Здоровье жёсткого диска (SMART).
 * Проверяется: в установщике (перед стиранием), в «Настройки → О системе»
 * и сам раз в неделю в установленной системе. Если диск начал портиться —
 * родным уходит сообщение в Telegram, а дедушку не пугаем лишний раз.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const RANK = { unknown: 0, good: 1, warn: 2, bad: 3 };

  // Что показать человеку по результату проверки
  function describe(r) {
    const d = (r && r.details) || {};
    const age = d.hours != null ? 'Диск проработал ' + fmtHours(d.hours) + '.' : '';
    const why = (d.reasons || []).join(', ');
    switch (r && r.status) {
      case 'good': return { cls: 'good', icon: '✅', title: 'Диск в порядке', text: (age + ' Признаков износа нет.').trim() };
      case 'warn': return { cls: 'warn', icon: '⚠️', title: 'Диск начал изнашиваться',
        text: 'Работать можно, но важные фото и записи лучше иногда копировать на флешку («Резервная копия» ниже). ' + age + (why ? ' Подробно: ' + why + '.' : '') };
      case 'bad': return { cls: 'bad', icon: '⛔', title: 'Диск может скоро сломаться',
        text: 'Сохраните важное на флешку и попросите родных поменять диск. ' + age + (why ? ' Подробно: ' + why + '.' : '') };
      default: return { cls: 'unknown', icon: 'ℹ️', title: 'Состояние диска узнать не удалось', text: 'Этот диск не сообщает о своём здоровье. Обычно так бывает у флешек и некоторых внешних дисков.' };
    }
  }
  function fmtHours(h) {
    if (h < 48) return h + ' ' + VOS.plural(h, 'час', 'часа', 'часов');
    const days = Math.round(h / 24);
    if (days < 60) return days + ' ' + VOS.plural(days, 'день', 'дня', 'дней');
    const y = Math.round(h / 876) / 10;
    if (y < 1) return Math.round(days / 30) + ' мес. (' + h + ' ч)';
    const word = Number.isInteger(y) ? VOS.plural(y, 'год', 'года', 'лет') : 'года';
    return String(y).replace('.', ',') + ' ' + word + ' (' + h + ' ч)';
  }

  async function check(dev) {
    try { return await B.call('diskHealth', dev); } catch (_) { return { dev, status: 'unknown', details: {}, checked: Date.now() }; }
  }
  // все встроенные диски
  async function checkAll() {
    const disks = await B.call('internalDisks').catch(() => []);
    const out = [];
    for (const d of disks) out.push({ disk: d, ...(await check(d.path)) });
    return out;
  }

  // Карточка для настроек / установщика
  function card(r, extra) {
    const v = describe(r);
    return el('div.disk-health.' + v.cls, null,
      el('span.dh-icon', { text: v.icon }),
      el('div.grow', null, el('b', { text: v.title + (extra ? ' — ' + extra : '') }), el('div', { text: v.text })));
  }
  // Маленькая метка на кнопке диска в установщике
  function badge(r) {
    const v = describe(r);
    const short = { good: 'исправен', warn: 'изношен', bad: 'неисправен', unknown: '' }[v.cls];
    return short ? el('span.dh-badge.' + v.cls, { text: v.icon + ' ' + short }) : null;
  }

  // Раз в неделю (установленная система): сравнить с прошлым разом
  async function weekly() {
    if (!VOS.mode || VOS.mode.mode !== 'installed') return;
    const last = await VOS.store.get('diskHealth', { checked: 0, list: [] });
    if (Date.now() - (last.checked || 0) < 7 * 864e5) return;
    const list = await checkAll();
    await VOS.store.set('diskHealth', { checked: Date.now(), list: list.map(x => ({ dev: x.dev, status: x.status, details: x.details })) });
    for (const x of list) {
      const prev = (last.list || []).find(p => p.dev === x.dev);
      const wasRank = RANK[prev ? prev.status : 'good'] || 1;
      if (RANK[x.status] < 2 || RANK[x.status] <= wasRank) continue;     // не хуже, чем было
      const v = describe(x);
      const helpers = (await VOS.store.get('contacts', [])).filter(c => c.helper !== false && c.tgChat);
      let told = 0;
      for (const c of helpers) if (await VOS.notify(c, '💽 Компьютер ' + VOS.settings.name + ': ' + v.title.toLowerCase() + '. ' + VOS.disk._cap((x.details.reasons || []).join(', ') || 'Подробности в «Настройки → О системе»') +
        '. Модель: ' + (x.details.model || x.dev) + '. Стоит сделать резервную копию' + (x.status === 'bad' ? ' и заменить диск.' : '.'))) told++;
      // дедушке — только если всё серьёзно, или если сообщить некому
      if (x.status === 'bad' || !told) {
        VOS.assistant.announce(x.status === 'bad'
          ? VOS.settings.name + ', жёсткий диск компьютера начал портиться. ' + (told ? 'Я уже написал родным.' : 'Пожалуйста, позвоните родным и скажите, что компьютер просит проверить диск.')
          : 'Жёсткий диск начал понемногу изнашиваться. Ничего страшного, но важные фото стоит скопировать на флешку.', { title: 'Жёсткий диск' });
      }
    }
  }

  VOS.disk = { check, checkAll, describe, card, badge, weekly, _cap: t => t.charAt(0).toUpperCase() + t.slice(1) };
})();
