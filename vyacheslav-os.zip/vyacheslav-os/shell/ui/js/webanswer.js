/* Ответы на вопросы через поиск Яндекса — без ключей и аккаунтов.
 *
 * «Василиса, кто такой Пушкин?» → открывается «Поиск в интернете» с этим
 * вопросом, помощник ждёт, пока Яндекс покажет ответ Алисы (блок с ответом
 * нейросети над результатами), и читает его вслух. Если такого блока нет —
 * читает «быстрый ответ» или начало первых результатов. Если Яндекс не
 * открылся — пробует короткую справку из Википедии.
 *
 * Страницу Яндекса никто не обещал не менять, поэтому блок ищется сразу
 * несколькими способами: по названиям классов, по заголовку «Алиса»/«Нейро»
 * и по атрибутам. Если что-то поменяется — правится только GRAB ниже.
 */
(function () {
  'use strict';
  const VOS = window.VOS, B = VOS.backend;
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // Выполняется внутри страницы поиска. Возвращает JSON-строку.
  const GRAB = `(() => {
    const txt = e => ((e && e.innerText) || '').replace(/[ \\t]+/g, ' ').replace(/\\n{2,}/g, '\\n').trim();
    const topOf = e => { const r = e.getBoundingClientRect(); return r.top + (window.scrollY || 0); };
    const visible = e => { const r = e.getBoundingClientRect(); return r.width > 50 && r.height > 20; };
    const captcha = /showcaptcha|captcha/i.test(location.href) ||
      !!document.querySelector('.CheckboxCaptcha, .AdvancedCaptcha, #checkbox-captcha-form, form[action*="captcha"], .SmartCaptcha');
    // 1. ответ нейросети (Алиса AI / Нейро)
    const SELS = ['[class*="FuturisGPT"]', '[class*="Futuris"]', '[class*="Neuro"]', '[class*="neuro"]', '[class*="GptAnswer"]',
      '[class*="YandexGPT"]', '[class*="AliceAnswer"]', '[class*="alice-answer"]', '[class*="AliceAI"]',
      '[data-fast-name*="neuro"]', '[data-fast-name*="gpt"]', '[data-fast-name*="alice"]', '[data-fast-wzrd*="neuro"]', '[data-fast-wzrd*="alice"]'];
    const cands = new Set();
    SELS.forEach(s => document.querySelectorAll(s).forEach(e => cands.add(e)));
    const HEAD = /^(Алиса(\\s*AI)?|Ответ Алисы|Алиса отвечает|Нейро|Ответ нейросети)\\s*$/i;
    [...document.querySelectorAll('h1, h2, h3, h4, header, div, span, b')].filter(e => e.children.length <= 3 && HEAD.test((e.textContent || '').trim())).slice(0, 6)
      .forEach(h => { let p = h; for (let i = 0; i < 7 && p.parentElement; i++) { p = p.parentElement; if (txt(p).length > 120) { cands.add(p); break; } } });
    let ai = null, aiLen = 0;
    cands.forEach(e => {
      if (!visible(e) || topOf(e) > 2200) return;
      const t = txt(e); if (t.length < 60 || t.length > 8000) return;
      if (/Реклама|Яндекс Директ/.test(t.slice(0, 80))) return;
      // самый «внешний» подходящий блок с самым длинным текстом
      if (t.length > aiLen) { ai = e; aiLen = t.length; }
    });
    const busy = ai ? !!ai.querySelector('[class*="Skeleton"], [class*="skeleton"], [class*="Loader"], [class*="Spinner"], [class*="Typing"], [class*="typing"], [class*="Cursor"], [aria-busy="true"]') : false;
    // 2. быстрый ответ / карточка (факт, объект)
    let fact = '';
    const f = document.querySelector('.Fact, [class*="Fact-"], [data-fast-name="entity_search"], [data-fast-name="fact"], [class*="EntitySearch"], .entity-search');
    if (f && visible(f)) fact = txt(f).slice(0, 3000);
    // 3. первые результаты поиска
    const snippets = [];
    document.querySelectorAll('li.serp-item, #search-result > li, [data-cid]').forEach(li => {
      if (snippets.length >= 3) return;
      const all = txt(li); if (!all || /Реклама/.test(all.slice(0, 120)) || li.querySelector('[class*="Label_type_ad"], .label_theme_direct')) return;
      const body = txt(li.querySelector('[class*="OrganicText"], .organic__content-wrapper, [class*="TextContainer"], .organic__text, .text-container'));
      const title = txt(li.querySelector('h2, .OrganicTitle, .organic__title'));
      if (body.length > 40) snippets.push({ title, body: body.slice(0, 1200) });
    });
    return JSON.stringify({ captcha, ai: ai ? txt(ai) : '', busy, fact, snippets, url: location.href, ready: document.readyState });
  })()`;

  // убрать служебные строки блока («Источники», «Показать полностью»…)
  const JUNK = /^(Алиса(\s*AI)?|Ответ Алисы|Алиса отвечает|Нейро|Ответ нейросети|Источники|Ещё|Еще|Показать (полностью|ещё|еще)|Поделиться|Скопировать|Нравится|Не нравится|Сгенерировано.*|Ответ сгенерирован.*|Может содержать ошибки.*|Спросить .*|Уточнить|Продолжить в чате.*|Открыть в Алисе.*|Быстрый ответ|Подробнее|Читать далее|\d+|[\w.-]+\.(ru|com|org|рф|su|net|info)(\/\S*)?)$/i;
  function clean(t) {
    return String(t || '').split('\n').map(s => s.trim())
      .filter(s => s && !JUNK.test(s))
      .join('\n')
      .replace(/\[\d+\]/g, '')                                   // сноски [1]
      .replace(/[*#_`>|]+/g, ' ')
      .replace(/[ \t]+/g, ' ').replace(/ +([.,;:!?])/g, '$1').trim();
  }
  // Первые несколько предложений — чтобы не читать целую статью
  function excerpt(t, max = 650) {
    t = clean(t).replace(/\n+/g, '. ').replace(/\.\s*\./g, '.').replace(/:\./g, ':');
    if (t.length <= max) return t;
    const parts = t.match(/[^.!?…]+[.!?…]+/g) || [t];
    let out = '';
    for (const p of parts) { if ((out + p).length > max && out) break; out += p; }
    return (out || t.slice(0, max)).trim();
  }

  async function grab(view) {
    try {
      let s = null;
      if (view.executeJavaScript) s = await view.executeJavaScript(GRAB);
      else if (view.contentWindow && view.contentWindow.eval) s = view.contentWindow.eval(GRAB);   // проверка в обычном браузере
      return s ? JSON.parse(s) : null;
    } catch (_) { return null; }    // страница ещё грузится или чужая
  }

  // Короткая справка из Википедии (если Яндекс не открылся)
  async function wiki(q) {
    const term = q.replace(/^(а\s+)?(скажи|расскажи|подскажи)(\s+мне)?,?\s*/i, '')
      .replace(/^(кто так(ой|ая|ие)|что так(ое|ой|ая)|кто был[аи]?|что значит|где находится|где)\s+/i, '').replace(/[?!.]+$/, '').trim();
    if (!term || term.split(' ').length > 6) return '';
    try {
      const os = await B.call('httpGetJson', 'https://ru.wikipedia.org/w/api.php?action=opensearch&format=json&limit=1&search=' + encodeURIComponent(term));
      const title = os && os[1] && os[1][0]; if (!title) return '';
      const sum = await B.call('httpGetJson', 'https://ru.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(title.replace(/ /g, '_')));
      return sum && sum.extract ? excerpt(sum.extract, 600) : '';
    } catch (_) { return ''; }
  }

  let asking = 0;
  VOS.webAnswer = async function (question, { onStatus } = {}) {
    const my = ++asking;
    const status = t => { if (onStatus) onStatus(t); };
    const w = VOS.wm.open('search', { query: question });
    await sleep(300);
    const view = w && w.el && w.el.querySelector('.web-view');
    const t0 = Date.now();
    let deadline = t0 + 15000, captchaSaid = false;
    let lastAi = '', stableSince = 0, best = null;
    status('Ищу в Яндексе…');
    while (view && Date.now() < deadline) {
      await sleep(500);
      if (my !== asking || !document.body.contains(view)) return { say: '', quiet: true };   // задали новый вопрос или окно закрыли
      const r = await grab(view);
      if (!r) continue;
      if (r.captcha) {
        if (!captchaSaid) {
          captchaSaid = true; deadline = Date.now() + 60000;
          status('Яндекс просит подтвердить, что вы не робот');
          VOS.speak('Яндекс просит подтвердить, что вы не робот. Нажмите на экране галочку «Я не робот».', { force: true });
        }
        continue;
      }
      if (r.ai) {
        status('Читаю ответ Алисы…');
        if (r.ai !== lastAi) { lastAi = r.ai; stableSince = Date.now(); }
        // ответ «печатается» на глазах — ждём, пока перестанет меняться
        if (!r.busy && Date.now() - stableSince > 1500 && excerpt(r.ai).length > 40) { best = { kind: 'ai', text: r.ai }; break; }
        deadline = Math.max(deadline, Date.now() + 3000);
        continue;
      }
      // ответа Алисы нет: подождём немного (он появляется не сразу), потом берём что есть
      const waited = Date.now() - t0;
      if (r.ready === 'complete' && waited > 6000) {
        if (r.fact && excerpt(r.fact).length > 40) { best = { kind: 'fact', text: r.fact }; break; }
        if (r.snippets && r.snippets.length) { best = { kind: 'snip', text: r.snippets.slice(0, 2).map(s => s.body).join('\n') }; break; }
      }
    }
    if (my !== asking) return { say: '', quiet: true };
    if (!best && lastAi) best = { kind: 'ai', text: lastAi };
    if (best) {
      const t = excerpt(best.text);
      const lead = best.kind === 'ai' ? 'Вот что отвечает Алиса. ' : 'Вот что нашлось. ';
      return { say: lead + t, web: true };
    }
    const wk = await wiki(question);
    if (wk) return { say: 'Вот что пишет Википедия. ' + wk, web: true };
    return { say: view ? 'Я ' + VOS.gx('открыла', 'открыл') + ' поиск — ответ на экране.' : 'Не получилось найти ответ. Проверьте интернет.', web: true };
  };
  VOS.webAnswer._grab = GRAB;
  VOS.webAnswer._excerpt = excerpt;
})();
