/*
 * backend.js — единая точка связи интерфейса с системой.
 * В ВячеславOS вызовы уходят в главный процесс (main.js → system.js).
 * Если интерфейс открыт в обычном браузере (для проверки на любом
 * компьютере), включается «имитация»: данные хранятся в localStorage,
 * Wi-Fi и диски показываются тестовые.
 */
(function () {
  'use strict';
  const native = window.vosNative;

  const mock = (function () {
    const ls = {
      get(k, d) { try { const v = localStorage.getItem('vos:' + k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } },
      set(k, v) { try { localStorage.setItem('vos:' + k, JSON.stringify(v)); } catch (_) { /* нет места */ } }
    };
    let volume = 60, muted = false, wifiOn = true, connected = 'Дом_Ростелеком';
    const nets = [
      { ssid: 'Дом_Ростелеком', signal: 82, secure: true },
      { ssid: 'TP-Link_5A2C', signal: 54, secure: true },
      { ssid: 'Соседи', signal: 31, secure: true },
      { ssid: 'Free_WiFi', signal: 20, secure: false }
    ];
    const voices = [];
    const params = new URLSearchParams(location.search);
    const modeName = params.get('mode') || 'live';
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    async function sha(s) {
      if (!(window.crypto && crypto.subtle)) return 'x' + s;
      const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
      return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
    }
    let installCb = null;
    const voiceCbs = [];
    const vEmit = ev => setTimeout(() => voiceCbs.forEach(f => f(ev)), 0);
    let vState = params.get('voice') === '0' ? { state: 'unavailable', reason: 'Имитация: служба голоса выключена' } : { state: 'on' };
    const tgLog = [];
    return {
      mode: () => ({ mode: modeName, live: modeName !== 'installed', persistent: false, mock: true, toram: modeName === 'live',
        hw: params.get('lite') === '1' ? { cpu: 'Intel(R) Core(TM)2 Duo CPU T6670 @ 2.20GHz', cores: 2, memGB: 3.8, sse42: false, avx: false }
          : { cpu: 'Браузер', cores: navigator.hardwareConcurrency || 4, memGB: navigator.deviceMemory || 8, sse42: true, avx: true } }),
      storeGet: (n, d) => ls.get('store:' + n, d),
      storeSet: (n, v) => { ls.set('store:' + n, v); return true; },
      hashPassword: async pw => { const salt = Math.random().toString(36).slice(2); return { salt, hash: await sha(salt + pw) }; },
      verifyPassword: async (pw, rec) => (!rec || !rec.salt) ? String(pw) === '1234' : (await sha(rec.salt + pw)) === rec.hash,
      wifiStatus: () => ({ available: true, enabled: wifiOn, wired: false, ssid: wifiOn ? connected : null, signal: 82, online: wifiOn && !!connected }),
      wifiScan: async () => { await sleep(700); return wifiOn ? nets.map(n => ({ ...n, connected: n.ssid === connected })) : []; },
      wifiConnect: async (s, p) => { await sleep(1200); if (nets.find(n => n.ssid === s).secure && (!p || p.length < 8)) return { ok: false, error: 'Неверный пароль от Wi-Fi. Проверьте пароль и попробуйте ещё раз.' }; connected = s; return { ok: true }; },
      wifiDisconnect: () => { connected = null; return true; },
      wifiSetEnabled: on => { wifiOn = on; return true; },
      getVolume: () => ({ volume, muted }),
      setVolume: v => { volume = v; muted = v === 0; return true; },
      setMute: m => { muted = m; return true; },
      power: a => { document.body.innerHTML = '<div style="color:#fff;font:32px sans-serif;padding:60px">(Имитация) Компьютер ' + (a === 'reboot' ? 'перезагружается' : 'выключается') + '…</div>'; return true; },
      setTimezone: () => true,
      screenWake: () => true,
      listVoices: () => voices.length ? voices : [{ id: 'aleksandr', name: 'Александр (мужской)' }, { id: 'anna', name: 'Анна (женский)' }],
      tts: () => null,
      netCheck: async () => { await sleep(700); return [{ name: 'Яндекс', ok: true, status: 200, ms: 180, bytes: 52000 }, { name: 'Погода: Open-Meteo', ok: false, error: 'Сайт не ответил за 12 с', ms: 12000 }, { name: 'Погода: MET Norway', ok: true, status: 200, ms: 640, bytes: 31000 }, { name: 'Радио: Маяк', ok: true, status: 200, ms: 300, bytes: 65536 }, { name: 'Telegram', ok: true, status: 404, ms: 420, bytes: 100 }]; },
      httpGetJson: async url => { const r = await fetch(url); if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); },
      voiceSave: async d => { const list = ls.get('mockvoice', []); const name = 'Заметка ' + new Date().toLocaleString('ru-RU'); list.unshift({ name, path: 'mock:' + Date.now(), mtime: Date.now(), size: d.byteLength }); ls.set('mockvoice', list); return list[0].path; },
      voiceList: () => ls.get('mockvoice', []),
      voiceDelete: p => { ls.set('mockvoice', ls.get('mockvoice', []).filter(x => x.path !== p)); return true; },
      usbList: () => [{ path: '/dev/sdc1', label: 'ФЛЕШКА', size: 8e9, mountpoint: null }],
      usbMount: () => '/media/vos/ФЛЕШКА',
      // &usbkey=0 — на флешке ключа нет
      keysFromUsb: async () => { await sleep(400); return params.get('usbkey') === '0' ? { files: [] } : { tg: '123456789:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw', files: ['telegram.txt'] }; },
      usbUnmount: () => true,
      photosList: () => [],
      photosImport: () => 0,
      photoDir: () => '~/Фото',
      installerDisks: () => [
        { path: '/dev/sda', size: 320072933376, model: 'Hitachi HTS545032B9A300', usb: false, isLiveMedium: false },
        { path: '/dev/sdb', size: 15931539456, model: 'SanDisk Cruzer Blade', usb: true, isLiveMedium: true }
      ],
      // имитация SMART: &smart=good|warn|bad|unknown
      diskHealth: async dev => {
        await sleep(400);
        const st = params.get('smart') || 'good';
        const details = { model: 'Hitachi HTS545032B9A300', hdd: true, hours: 21437, temp: 39, realloc: st === 'warn' ? 8 : 0, pending: st === 'bad' ? 24 : 0, uncorrectable: st === 'bad' ? 3 : 0,
          reasons: st === 'warn' ? ['переназначенных секторов: 8'] : st === 'bad' ? ['нестабильных секторов: 24', 'нечитаемых секторов: 3'] : [] };
        if (dev !== '/dev/sda' || st === 'unknown') return { dev, checked: Date.now(), status: 'unknown', details: {} };
        return { dev, checked: Date.now(), status: st, details };
      },
      internalDisks: () => [{ path: '/dev/sda', size: 320072933376, model: 'Hitachi HTS545032B9A300', usb: false, isLiveMedium: false }],
      installerStart: dev => {
        const steps = ['Подготовка диска ' + dev, 'Создание раздела', 'Копирование системы', 'Копирование системы', 'Копирование системы', 'Настройка загрузчика', 'Перенос ваших настроек', 'Завершение'];
        let p = 0;
        const t = setInterval(() => {
          p += 4;
          if (installCb) installCb({ type: 'progress', percent: Math.min(p, 100), text: steps[Math.min(steps.length - 1, Math.floor(p / 13))] });
          if (p >= 100) { clearInterval(t); installCb && installCb({ type: 'done' }); }
        }, 250);
        return true;
      },
      reloadShell: () => location.reload(),
      httpGetText: async url => { const r = await fetch(url); if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); },
      voiceCtl: msg => {
        if (msg.cmd === 'listen' && vState.state === 'on') vEmit({ type: 'listening', reason: msg.reason });
        return vState;
      },
      voiceCleanup: () => true,
      tgSend: async (t, c, m) => { if (!t) throw new Error('Неверный токен Telegram-бота'); tgLog.push({ c, m }); return { ok: true }; },
      tgChats: async () => [{ id: 1001, name: 'Случайный человек', username: 'sasha' }, { id: 1002, name: 'Мария', username: '' }, { id: 1003, name: 'Роман', username: 'BodRoman_17' }],
      // имитация ВКонтакте: сообщество «Компьютер дедушки», двое доверенных
      vkPreset: () => params.get('vkpreset') === '1' ? { token: 'vk1.a.' + 'P'.repeat(80), trusted: 'https://vk.com/roman_b, https://vk.com/nadya_p' } : { token: '', trusted: '' },
      vkMe: async t => { if (!/^vk1\.a\./.test(t || '')) throw new Error('Неверный ключ сообщества ВКонтакте'); return { id: 777, name: 'Компьютер дедушки', screen: 'club777' }; },
      vkResolve: async (t, names) => names.map(n => String(n).replace(/^https?:\/\/vk\.com\//, '')).filter(n => n !== 'nobody').map((n, i) => ({ id: 1000 + i, name: n === 'roman_b' ? 'Роман Б.' : 'Надежда П.', screen: n })),
      vkAllowed: async (t, g, u) => u === 1000,
      vkSend: async (t, u, m) => { if (u !== 1000) { const e = new Error('Человек ещё не разрешил сообщения от сообщества'); throw e; } (window.__vkLog = window.__vkLog || []).push({ u, m }); return 1; },
      tgMe: async () => ({ username: 'vyacheslav_home_bot', first_name: 'Дом Вячеслава' }),
      rustdesk: async (a) => a === 'id' ? { available: true, id: '123456789' } : { available: true, ok: true },
      _voice: { emit: vEmit, on: f => voiceCbs.push(f), tgLog },
      getHostname: () => ({ hostname: 'vyacheslav-pc', pretty: ls.get('pretty', '') }),
      setHostname: n => { ls.set('pretty', n); return { ok: true, pretty: n, hostname: 'noutbuk' }; },
      backupCreate: async () => { await sleep(900); return { file: '/media/vos/ФЛЕШКА/ВячеславOS-копия.tar.gz', size: 12e6 }; },
      backupList: () => params.get('backup') ? [{ file: '/media/vos/ФЛЕШКА/ВячеславOS-копия-2026-10-01.tar.gz', name: 'ВячеславOS-копия-2026-10-01.tar.gz', size: 15e6, mtime: Date.now() - 864e5 * 25 }] : [],
      backupRestore: async () => { await sleep(900); return true; },
      _onInstall: fn => { installCb = fn; }
    };
  })();

  const VOS = window.VOS = window.VOS || {};
  VOS.isNative = !!native;
  /* ---------- имитация «Моих файлов» (в памяти) и батареи ---------- */
  const mockBus = {};
  const params = new URLSearchParams(location.search);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const emit = (ch, ev) => (mockBus[ch] || []).forEach(f => f(ev));
  const H = '/home/vos', U = '/media/vos/ФЛЕШКА';
  const DIRS = { docs: H + '/Документы', downloads: H + '/Загрузки', photos: H + '/Фото', voice: H + '/Голосовые заметки' };
  const T = H + '/.local/share/vos-trash';
  const kindOf = n => /\.(docx?|odt|rtf|txt)$/i.test(n) ? 'doc' : /\.(xlsx?|ods|csv)$/i.test(n) ? 'sheet' : /\.(pptx?|odp)$/i.test(n) ? 'slides' : /\.pdf$/i.test(n) ? 'pdf' : /\.(jpe?g|png|gif|webp)$/i.test(n) ? 'image' : /\.(mp3|ogg|wav|m4a)$/i.test(n) ? 'audio' : /\.(mp4|webm|mkv|avi)$/i.test(n) ? 'video' : 'file';
  const fsm = new Map();      // путь → { dir, size, mtime, from? }
  const put = (p, size, dir = false) => fsm.set(p, { dir, size, mtime: Date.now() - Math.random() * 9e8 });
  [...Object.values(DIRS), T, H + '/Документы/Рецепты'].forEach(d => put(d, 0, true));
  put(DIRS.docs + '/Письмо внуку.docx', 14200); put(DIRS.docs + '/Пенсия 2026.xlsx', 9800); put(DIRS.docs + '/Рецепты/Борщ.docx', 22000);
  put(DIRS.downloads + '/Квитанция.pdf', 180000); put(DIRS.photos + '/Дача.jpg', 2400000);
  let usbIn = params.get('usb') !== '0';
  if (usbIn) { put(U, 0, true); put(U + '/Фото с юбилея', 0, true); put(U + '/Фото с юбилея/IMG_0012.jpg', 3100000); put(U + '/Список покупок.docx', 12000); put(U + '/Песни.mp3', 5200000); }
  const parent = p => p.slice(0, p.lastIndexOf('/'));
  const base = p => p.slice(p.lastIndexOf('/') + 1);
  const childrenOf = d => [...fsm.keys()].filter(k => parent(k) === d);
  const uniq = (dir, name) => { const m = name.match(/^(.*?)(\.[^.]*)?$/); let p = dir + '/' + name, i = 2; while (fsm.has(p)) p = dir + '/' + m[1] + ' (' + (i++) + ')' + (m[2] || ''); return p; };
  const subtree = p => [...fsm.keys()].filter(k => k === p || k.startsWith(p + '/'));
  Object.assign(mock, {
    fsDirs: () => DIRS,
    fsRoots: () => [...Object.entries({ docs: 'Документы', downloads: 'Загрузки', photos: 'Фото', voice: 'Голосовые заметки' }).map(([id, name]) => ({ id, kind: 'home', name, path: DIRS[id] })),
      { id: 'trash', kind: 'trash', name: 'Корзина', path: T }, ...(usbIn && fsm.has(U) ? [{ id: 'usb:/dev/sdc1', kind: 'usb', dev: '/dev/sdc1', name: 'ФЛЕШКА', path: U, free: 6.2e9, total: 8e9 }] : [])],
    fsList: d => { if (!fsm.has(d)) throw new Error('Папка не открывается'); return { path: d, entries: childrenOf(d).map(p => ({ name: base(p), path: p, dir: fsm.get(p).dir, size: fsm.get(p).size, mtime: fsm.get(p).mtime, kind: fsm.get(p).dir ? 'folder' : kindOf(p), from: fsm.get(p).from })).sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name, 'ru')) }; },
    fsRecent: k => [...fsm.entries()].filter(([p, v]) => !v.dir && kindOf(p) === k && !p.startsWith(T) && !p.startsWith(U)).map(([p, v]) => ({ name: base(p), path: p, mtime: v.mtime, size: v.size, kind: k })).sort((a, b) => b.mtime - a.mtime),
    fsCopy: async (srcs, dest, move) => {
      const total = srcs.reduce((n, s) => n + subtree(s).reduce((m, k) => m + fsm.get(k).size, 0), 0);
      for (let i = 1; i <= 4; i++) { await sleep(150); emit('fs-progress', { done: total * i / 5, total, percent: i * 20 }); }
      const out = [];
      for (const s of srcs) { const t = uniq(dest, base(s)); for (const k of subtree(s)) { fsm.set(t + k.slice(s.length), { ...fsm.get(k), mtime: Date.now() }); if (move) fsm.delete(k); } out.push(t); }
      emit('fs-progress', { done: total, total, percent: 100, finished: true });
      return out;
    },
    fsMkdir: (d, n) => { const p = uniq(d, n); put(p, 0, true); return p; },
    fsRename: (p, n) => { const t = parent(p) + '/' + n; if (fsm.has(t)) throw new Error('Такое имя уже есть'); for (const k of subtree(p)) { fsm.set(t + k.slice(p.length), fsm.get(k)); fsm.delete(k); } return t; },
    fsDelete: ps => { ps.forEach(p => { if (p.startsWith(U) || p.startsWith(T)) subtree(p).forEach(k => fsm.delete(k)); else { const t = uniq(T, base(p)); for (const k of subtree(p)) { fsm.set(t + k.slice(p.length), { ...fsm.get(k), from: k === p ? p : undefined }); fsm.delete(k); } } }); return ps.length; },
    fsRestore: ps => { ps.forEach(p => { const v = fsm.get(p); const to = uniq(v && v.from ? parent(v.from) : DIRS.docs, base(v && v.from ? v.from : p)); for (const k of subtree(p)) { fsm.set(to + k.slice(p.length), { ...fsm.get(k), from: undefined }); fsm.delete(k); } }); return ps.length; },
    fsEmptyTrash: () => { childrenOf(T).forEach(p => subtree(p).forEach(k => fsm.delete(k))); return true; },
    fsNewDoc: (k, d, n) => { const ext = { doc: '.docx', sheet: '.xlsx', slides: '.pptx' }[k]; const p = uniq(d || DIRS.docs, (n || { doc: 'Новый документ', sheet: 'Новая таблица', slides: 'Новая презентация' }[k]) + ext); put(p, 1000); return p; },
    fsOpen: p => { const v = fsm.get(p); if (!v) throw new Error('Файл не найден'); if (v.dir) return { viewer: 'folder', path: p }; const k = kindOf(p); if (['image', 'audio', 'video'].includes(k)) return { viewer: k, path: p }; (window.__opened = window.__opened || []).push(p); return { launched: k === 'pdf' ? 'mupdf' : 'soffice' }; },
    fsEject: () => { subtree(U).forEach(k => fsm.delete(k)); usbIn = false; return true; },
    // &battery=15 — заряд, &charging=1 — на зарядке, &battery=none — без батареи
    battery: () => { const b = params.get('battery'); if (b === 'none') return { present: false }; const pc = b ? +b : 78; const ch = params.get('charging') === '1'; return { present: true, percent: pc, charging: ch, full: pc >= 100, ac: ch, minutes: ch ? 45 : Math.round(pc * 1.8), status: ch ? 'Charging' : 'Discharging' }; },
    _download: (name) => { const p = uniq(DIRS.downloads, name); put(p, 50000); emit('download', { state: 'completed', name: base(p), path: p }); }
  });
  VOS._mock = native ? null : mock;
  VOS.backend = {
    call(method, ...args) {
      if (native) return native.call(method, ...args);
      const f = mock[method];
      if (!f) return Promise.reject(new Error('Нет метода ' + method));
      try { return Promise.resolve(f(...args)); } catch (e) { return Promise.reject(e); }
    },
    on(channel, fn) {
      if (native) native.on(channel, fn);
      else if (channel === 'install-progress') mock._onInstall(fn);
      else if (channel === 'voice') mock._voice.on(fn);
      else if (channel === 'fs-progress' || channel === 'download') (mockBus[channel] = mockBus[channel] || []).push(fn);
    }
  };
})();
