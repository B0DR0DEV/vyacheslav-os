/* Голосовые заметки: запись с микрофона ноутбука, прослушивание, расшифровка в текст через Groq. */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;

  VOS.registerApp({
    id: 'voicenotes', title: 'Голосовые заметки', desktop: false, width: 860, height: 640,
    words: ['голосовые заметки', 'диктофон', 'запись голоса', 'голосовая заметка', 'записать голос'],
    open(w) {
      let rec = null, timer = null, started = 0;
      const mockBlobs = {};
      const recBtn = el('button.btn.huge.rec', { text: '⏺ Начать запись' });
      const time = el('div.rec-time', { text: '0:00' });
      const list = el('div.list');
      let player = null;
      const transcripts = {};

      async function render() {
        const items = await B.call('voiceList');
        const tr = await VOS.store.get('voiceText', {});
        list.textContent = '';
        if (!items.length) list.append(el('div.empty', { text: 'Записей пока нет. Нажмите красную кнопку и говорите.' }));
        items.forEach(it => {
          const text = tr[it.path] || transcripts[it.path];
          list.append(el('div.list-row.vn', null,
            el('button.btn.round.primary', { text: '▶', title: 'Слушать', onclick: () => play(it) }),
            el('div.grow', null, el('b', { text: it.name }), text ? el('div.vn-text', { text: '«' + text + '»' }) : null),
            el('button.btn.small', { text: '📝 В текст', title: 'Расшифровать', onclick: async e => {
              e.target.disabled = true; e.target.textContent = '…';
              try {
                const r = await B.call('aiTranscribe', { key: VOS.settings.groqKey, filePath: it.path });
                tr[it.path] = r.text || '(не разобрать)'; await VOS.store.set('voiceText', tr);
              } catch (err) { VOS.ui.alert('Не получилось', err.message.replace(/^Error.*?: /, ''), '⚠️'); }
              render();
            } }),
            el('button.btn.small.danger', { text: '🗑', onclick: async () => {
              if (!(await VOS.ui.confirm({ title: 'Удалить запись?', text: it.name, yes: 'Удалить', danger: true }))) return;
              await B.call('voiceDelete', it.path); delete tr[it.path]; await VOS.store.set('voiceText', tr); render();
            } })));
        });
      }
      function play(it) {
        if (player) player.pause();
        const src = it.path.startsWith('mock:') ? mockBlobs[it.path] : 'file://' + it.path.split('/').map(encodeURIComponent).join('/');
        if (!src) return VOS.ui.toast('Запись недоступна в режиме проверки');
        player = new Audio(src); player.play().catch(() => VOS.ui.toast('Не удалось воспроизвести'));
      }
      async function toggle() {
        if (rec) {
          clearInterval(timer);
          recBtn.disabled = true;
          const blob = await rec.stop(); rec = null;
          recBtn.disabled = false; VOS.setBtn(recBtn, '⏺ Начать запись'); recBtn.classList.remove('on');
          if (blob && blob.size > 1000) {
            const buf = await blob.arrayBuffer();
            const p = await B.call('voiceSave', buf);
            if (String(p).startsWith('mock:')) mockBlobs[p] = URL.createObjectURL(blob);
            VOS.ui.toast('Запись сохранена'); render();
          }
          return;
        }
        try { rec = await VOS.recordAudio({ maxMs: 10 * 60 * 1000 }); }
        catch (_) { VOS.ui.alert('Микрофон недоступен', 'Не удалось включить микрофон. Проверьте, что он не выключен.', '🎙️'); return; }
        started = Date.now();
        VOS.setBtn(recBtn, '⏹ Остановить'); recBtn.classList.add('on');
        timer = setInterval(() => { const s = Math.floor((Date.now() - started) / 1000); time.textContent = Math.floor(s / 60) + ':' + VOS.pad(s % 60); }, 250);
      }
      recBtn.onclick = toggle;
      w.body.append(el('div.app-pad', null, el('div.rec-box', null, recBtn, time), list));
      render();
      return () => { clearInterval(timer); if (rec) rec.stop(); if (player) player.pause(); };
    }
  });
})();
