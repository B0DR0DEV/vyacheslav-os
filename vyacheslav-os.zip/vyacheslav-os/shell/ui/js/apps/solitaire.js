/*
 * Косынка (пасьянс «Клондайк», по одной карте из колоды).
 * Управление для пожилого человека упрощено:
 *   • один щелчок по открытой карте — она сама переходит в лучшее место;
 *   • карты можно и перетаскивать мышью;
 *   • щелчок по колоде — открыть следующую карту;
 *   • есть «Отменить ход» и «Собрать всё», игра сохраняется при закрытии.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;
  const SUITS = ['♠', '♥', '♦', '♣'];
  const RANKS = { 1: 'Т', 11: 'В', 12: 'Д', 13: 'К' };
  const red = c => c.s === 1 || c.s === 2;
  const rankName = r => RANKS[r] || String(r);

  function newGame() {
    const deck = [];
    for (let s = 0; s < 4; s++) for (let r = 1; r <= 13; r++) deck.push({ s, r, up: false });
    for (let i = deck.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
    const tab = [];
    for (let i = 0; i < 7; i++) { tab.push(deck.splice(0, i + 1)); tab[i][i].up = true; }
    return { stock: deck, waste: [], found: [[], [], [], []], tab, moves: 0, started: Date.now() };
  }

  VOS.registerApp({
    id: 'solitaire', title: 'Косынка', width: 1100, height: 720, maximized: true,
    words: ['косынку', 'косынка', 'пасьянс', 'карты', 'солитер'],
    async open(w) {
      let st = await VOS.store.get('solitaire', null);
      if (!st || !st.tab) st = newGame();
      let undo = [];
      const board = el('div.sol-board');
      const info = el('span.sol-info');
      const save = VOS.debounce(() => VOS.store.set('solitaire', st), 800);
      let geo = {};

      const pileOf = ref => ref.t === 'stock' ? st.stock : ref.t === 'waste' ? st.waste : ref.t === 'found' ? st.found[ref.i] : st.tab[ref.i];
      const snapshot = () => { undo.push(JSON.stringify(st)); if (undo.length > 200) undo.shift(); };

      function canTab(cards, pile) {
        const top = pile[pile.length - 1], c = cards[0];
        if (!top) return c.r === 13;
        return top.up && red(top) !== red(c) && top.r === c.r + 1;
      }
      function canFound(cards, pile) {
        if (cards.length !== 1) return false;
        const top = pile[pile.length - 1], c = cards[0];
        return top ? (top.s === c.s && c.r === top.r + 1) : c.r === 1;
      }
      function doMove(from, idx, to) {
        const src = pileOf(from), cards = src.slice(idx), dst = pileOf(to);
        if (to.t === 'tab' ? !canTab(cards, dst) : to.t === 'found' ? !canFound(cards, dst) : true) return false;
        snapshot();
        src.splice(idx); dst.push(...cards);
        if (from.t === 'tab' && src.length && !src[src.length - 1].up) src[src.length - 1].up = true;
        st.moves++;
        afterMove();
        return true;
      }
      function afterMove() {
        save(); render();
        if (st.found.every(f => f.length === 13)) {
          VOS.sound.win();
          setTimeout(() => VOS.ui.dialog({ icon: '🏆', title: 'Победа!', text: 'Пасьянс сложился за ' + st.moves + ' ' + VOS.plural(st.moves, 'ход', 'хода', 'ходов') + '. Молодец!',
            buttons: [{ label: 'Новая игра', value: true, primary: true }] }).then(() => { st = newGame(); undo = []; afterMove(); }), 400);
        }
      }
      // один щелчок: карта идёт в «дом», а если нельзя — на подходящую стопку
      function autoMove(from, idx) {
        const src = pileOf(from), cards = src.slice(idx);
        if (cards.length === 1) for (let i = 0; i < 4; i++) if (canFound(cards, st.found[i])) return doMove(from, idx, { t: 'found', i });
        // сначала стопки с картами, потом пустые
        const order = [0, 1, 2, 3, 4, 5, 6].filter(i => !(from.t === 'tab' && from.i === i)).sort((a, b) => (st.tab[a].length === 0) - (st.tab[b].length === 0));
        for (const i of order) {
          if (cards[0].r === 13 && from.t === 'tab' && idx === 0 && !st.tab[i].length) continue;   // король уже внизу — не гоняем
          if (canTab(cards, st.tab[i])) return doMove(from, idx, { t: 'tab', i });
        }
        return false;
      }
      function clickStock() {
        snapshot();
        if (st.stock.length) { const c = st.stock.pop(); c.up = true; st.waste.push(c); }
        else if (st.waste.length) { st.stock = st.waste.reverse().map(c => ({ ...c, up: false })); st.waste = []; }
        else { undo.pop(); return; }
        st.moves++; save(); render();
      }
      function autoFinish() {
        const step = () => {
          for (let i = 0; i < 7; i++) { const p = st.tab[i]; if (p.length && autoMoveFound({ t: 'tab', i }, p.length - 1)) return setTimeout(step, 120); }
          if (st.waste.length && autoMoveFound({ t: 'waste' }, st.waste.length - 1)) return setTimeout(step, 120);
        };
        step();
      }
      function autoMoveFound(from, idx) {
        const cards = pileOf(from).slice(idx);
        for (let i = 0; i < 4; i++) if (canFound(cards, st.found[i])) return doMove(from, idx, { t: 'found', i });
        return false;
      }

      /* ---------- рисование ---------- */
      function layout() {
        const W = board.clientWidth || 1000, H = board.clientHeight || 600;
        const gap = Math.max(8, Math.round(W * 0.012));
        const cw = Math.min(Math.floor((W - gap * 8) / 7), Math.floor((H - gap * 3) / 1.42 / 3.2), 130);
        const ch = Math.round(cw * 1.42);
        const colX = i => gap + i * (cw + gap) + Math.max(0, (W - (gap * 8 + cw * 7)) / 2);
        geo = { W, H, gap, cw, ch, colX, tabY: gap * 2 + ch };
        board.style.setProperty('--cw', cw + 'px');
      }
      function cardEl(c, x, y, ref, idx, z) {
        const e = el('div.card' + (c.up ? (red(c) ? '.red' : '') : '.back'), { style: { left: x + 'px', top: y + 'px', width: geo.cw + 'px', height: geo.ch + 'px', zIndex: z } });
        if (c.up) e.append(el('div.c-corner', { text: rankName(c.r) + SUITS[c.s] }), el('div.c-mid', { text: SUITS[c.s] }), el('div.c-corner.br', { text: rankName(c.r) + SUITS[c.s] }));
        e._ref = ref; e._idx = idx;
        return e;
      }
      function slot(x, y, label, ref) {
        const s = el('div.slot', { text: label, style: { left: x + 'px', top: y + 'px', width: geo.cw + 'px', height: geo.ch + 'px' } });
        s._ref = ref; s._idx = 0; return s;
      }
      function render() {
        layout();
        board.textContent = '';
        const { gap, ch, colX, tabY, H } = geo;
        // колода и сброс
        const stockSlot = slot(colX(0), gap, st.stock.length ? '' : '↻', { t: 'stock' });
        board.append(stockSlot);
        if (st.stock.length) board.append(cardEl(st.stock[st.stock.length - 1], colX(0), gap, { t: 'stock' }, st.stock.length - 1, 2));
        board.append(slot(colX(1), gap, '', { t: 'waste' }));
        const wv = st.waste.slice(-3);
        wv.forEach((c, i) => board.append(cardEl(c, colX(1) + i * Math.round(geo.cw * 0.18), gap, { t: 'waste' }, st.waste.length - wv.length + i, 2 + i)));
        // «дом»
        for (let i = 0; i < 4; i++) {
          board.append(slot(colX(3 + i), gap, 'Т', { t: 'found', i }));
          const f = st.found[i]; if (f.length) board.append(cardEl(f[f.length - 1], colX(3 + i), gap, { t: 'found', i }, f.length - 1, 2));
        }
        // стопки
        for (let i = 0; i < 7; i++) {
          const p = st.tab[i];
          board.append(slot(colX(i), tabY, 'К', { t: 'tab', i }));
          const downs = p.filter(c => !c.up).length, ups = p.length - downs;
          let dOff = ch * 0.12, uOff = ch * 0.27;
          const need = downs * dOff + Math.max(0, ups - 1) * uOff + ch, avail = H - tabY - gap;
          if (need > avail && p.length > 1) { const k = (avail - ch) / (need - ch); dOff *= k; uOff *= k; }
          let y = tabY;
          p.forEach((c, j) => { board.append(cardEl(c, colX(i), y, { t: 'tab', i }, j, 10 + j)); y += c.up ? uOff : dOff; });
        }
        info.textContent = 'Ходов: ' + st.moves + '   В колоде: ' + st.stock.length;
        finishBtn.hidden = !(st.stock.length === 0 && st.waste.length === 0 && st.tab.every(p => p.every(c => c.up)) && !st.found.every(f => f.length === 13));
      }

      /* ---------- мышь: щелчок и перетаскивание ---------- */
      let drag = null;
      board.addEventListener('pointerdown', e => {
        const t = e.target.closest('.card,.slot'); if (!t || e.button !== 0) return;
        const ref = t._ref, idx = t._idx;
        if (ref.t === 'stock') { clickStock(); return; }
        const pile = pileOf(ref), c = pile[idx];
        if (!c) return;
        if (!c.up) {   // закрытая верхняя карта — открыть
          if (ref.t === 'tab' && idx === pile.length - 1) { snapshot(); c.up = true; save(); render(); }
          return;
        }
        if (ref.t === 'waste' && idx !== st.waste.length - 1) return;
        const els = [...board.querySelectorAll('.card')].filter(x => x._ref.t === ref.t && x._ref.i === ref.i && x._idx >= idx);
        drag = { ref, idx, els, sx: e.clientX, sy: e.clientY, moved: false, starts: els.map(x => [x.offsetLeft, x.offsetTop]) };
        board.setPointerCapture(e.pointerId);
      });
      board.addEventListener('pointermove', e => {
        if (!drag) return;
        const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
        if (!drag.moved && Math.hypot(dx, dy) < 6) return;
        drag.moved = true;
        drag.els.forEach((x, i) => { x.style.left = drag.starts[i][0] + dx + 'px'; x.style.top = drag.starts[i][1] + dy + 'px'; x.style.zIndex = 1000 + i; x.classList.add('lift'); });
      });
      board.addEventListener('pointerup', e => {
        if (!drag) return;
        const d = drag; drag = null;
        if (!d.moved) { if (!autoMove(d.ref, d.idx)) { d.els[0].classList.add('shake'); setTimeout(render, 350); } return; }
        // куда бросили: по центру верхней перетаскиваемой карты
        const r0 = d.els[0].getBoundingClientRect(), br = board.getBoundingClientRect();
        const cx = r0.left + r0.width / 2 - br.left, cy = r0.top + r0.height / 2 - br.top;
        let target = null;
        for (let i = 0; i < 4 && !target; i++) { const x = geo.colX(3 + i); if (cx >= x && cx <= x + geo.cw && cy < geo.tabY) target = { t: 'found', i }; }
        for (let i = 0; i < 7 && !target; i++) { const x = geo.colX(i); if (cx >= x - geo.gap / 2 && cx <= x + geo.cw + geo.gap / 2 && cy >= geo.tabY - geo.ch / 2) target = { t: 'tab', i }; }
        if (!target || (target.t === d.ref.t && target.i === d.ref.i) || !doMove(d.ref, d.idx, target)) render();
      });

      const finishBtn = el('button.btn.primary', { text: '✨ Собрать всё', onclick: autoFinish, hidden: true });
      const tools = el('div.toolbar', null,
        el('button.btn', { text: '🆕 Новая игра', onclick: async () => { if (st.moves < 3 || await VOS.ui.confirm({ title: 'Начать новую игру?', text: 'Текущая раскладка пропадёт.', yes: 'Новая игра' })) { st = newGame(); undo = []; afterMove(); } } }),
        el('button.btn', { text: '↩ Отменить ход', onclick: () => { if (undo.length) { st = JSON.parse(undo.pop()); save(); render(); } } }),
        finishBtn, el('span.spacer'), info,
        el('button.btn', { text: '❓ Правила', onclick: () => VOS.ui.alert('Как играть', 'Цель — разложить все карты по мастям в четыре «дома» вверху справа: от туза (Т) до короля (К). ' +
          'В нижних стопках карты кладутся по убыванию, чередуя цвет: на чёрную девятку — красную восьмёрку. В пустую стопку можно положить только короля. ' +
          'Просто щёлкните по карте — она сама пойдёт куда можно. Щелчок по колоде открывает новую карту.', '🃏') }));
      w.body.append(el('div.sol', null, tools, board));
      w.onResize = render;
      const ro = new ResizeObserver(() => render()); ro.observe(board);
      setTimeout(render, 30);
      return () => ro.disconnect();
    }
  });
})();
