/* Будильник: несколько будильников, по дням недели или один раз. Срабатывание — в scheduler.js. */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;
  const DAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];   // индексы 0..6 = пн..вс

  VOS.registerApp({
    id: 'alarm', title: 'Будильник', width: 820, height: 620,
    words: ['будильник', 'разбуди', 'будильники'],
    open(w) {
      const list = el('div.list');
      async function render() {
        const alarms = await VOS.store.get('alarms', []);
        list.textContent = '';
        if (!alarms.length) list.append(el('div.empty', { text: 'Будильников нет. Нажмите «Добавить будильник».' }));
        alarms.sort((a, b) => a.time.localeCompare(b.time)).forEach(a => list.append(el('div.list-row.alarm' + (a.enabled ? '' : '.off'), null,
          el('span.alarm-time', { text: a.time }),
          el('span.grow', null, el('b', { text: a.label || 'Будильник' }), el('div.muted', { text: a.days.length ? (a.days.length === 7 ? 'Каждый день' : a.days.map(d => DAYS[d]).join(', ')) : 'Один раз' })),
          el('label.switch-row', null, el('input', { type: 'checkbox', checked: a.enabled, onchange: async e => { a.enabled = e.target.checked; await VOS.store.set('alarms', alarms); render(); } })),
          el('button.btn.small.danger', { text: '🗑', onclick: async () => { await VOS.store.set('alarms', alarms.filter(x => x !== a)); render(); } }))));
      }
      async function add() {
        const time = el('input.big-input.time', { type: 'time', value: '07:00' });
        const label = el('input.big-input', { placeholder: 'Подпись (необязательно)' });
        const dayBox = el('div.day-picks');
        const picks = DAYS.map((d, i) => { const c = el('input', { type: 'checkbox', checked: i < 5 }); dayBox.append(el('label.day-pick', null, c, d)); return c; });
        const ok = await VOS.ui.dialog({ icon: '⏰', title: 'Новый будильник', body: el('div.form', null, el('label', { text: 'Время' }), time, el('label', { text: 'Дни (если ничего не отметить — сработает один раз)' }), dayBox, label),
          buttons: [{ label: 'Отмена', value: false }, { label: 'Сохранить', value: true, primary: true }] });
        if (!ok || !time.value) return;
        const alarms = await VOS.store.get('alarms', []);
        alarms.push({ id: VOS.uid(), time: time.value, label: label.value.trim(), days: picks.map((c, i) => c.checked ? i : -1).filter(i => i >= 0), enabled: true });
        await VOS.store.set('alarms', alarms); render();
        VOS.ui.toast('Будильник заведён на ' + time.value);
      }
      w.body.append(el('div.app-pad', null,
        el('div.toolbar', null, el('div.big-clock', { text: VOS.fmtTime(new Date()) }), el('span.spacer'), el('button.btn.primary', { text: '➕ Добавить будильник', onclick: add })),
        list, el('p.muted', { text: 'Будильник звонит, только когда компьютер включён. Закрывать крышку можно — компьютер не уснёт.' })));
      render();
      const t = setInterval(() => { const c = w.body.querySelector('.big-clock'); if (c) c.textContent = VOS.fmtTime(new Date()); }, 5000);
      return () => clearInterval(t);
    }
  });
})();
