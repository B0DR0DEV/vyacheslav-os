/*
 * Настройки: имя, пароль, город и часовой пояс, оформление (тема, цвет,
 * размер шрифта, обои), звук и голос, интернет, помощник (ключ Groq), о системе.
 * Всё применяется сразу и сохраняется в ~/.config/vyacheslav-os/data/settings.json
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const TZ = [
    ['Europe/Kaliningrad', 'Калининград (МСК−1)'], ['Europe/Moscow', 'Москва (МСК)'], ['Europe/Samara', 'Самара (МСК+1)'],
    ['Asia/Yekaterinburg', 'Екатеринбург (МСК+2)'], ['Asia/Omsk', 'Омск (МСК+3)'], ['Asia/Novosibirsk', 'Новосибирск (МСК+4)'],
    ['Asia/Krasnoyarsk', 'Красноярск (МСК+4)'], ['Asia/Irkutsk', 'Иркутск (МСК+5)'], ['Asia/Yakutsk', 'Якутск (МСК+6)'],
    ['Asia/Vladivostok', 'Владивосток (МСК+7)'], ['Asia/Magadan', 'Магадан (МСК+8)'], ['Asia/Kamchatka', 'Камчатка (МСК+9)']
  ];
  const row = (label, ...ctrl) => el('div.set-row', null, el('div.set-label', { text: label }), el('div.set-ctrl', null, ...ctrl));

  // Кнопка «С флешки»: ключ не нужно перепечатывать — на любом компьютере
  // кладут на обычную флешку текстовый файл с ключом (например, groq.txt).
  VOS.usbKeyButton = (input, kind, onFound) => el('button.btn', { text: '@download', title: 'Взять ключ из текстового файла на флешке', onclick: async e => {
    const btn = e.currentTarget; btn.disabled = true;
    try {
      const r = await B.call('keysFromUsb').catch(() => ({ files: [] }));
      if (r && r[kind]) {
        input.value = r[kind];
        VOS.ui.toast('Ключ взят с флешки (файл ' + r.files.join(', ') + '). Флешку можно вынуть.', 5000);
        if (onFound) await onFound(r[kind]);
      } else {
        VOS.ui.alert('Ключ на флешке не найден', 'На любом компьютере создайте на флешке текстовый файл (например, ' + (kind === 'tg' ? 'telegram.txt' : 'groq.txt') +
          '), вставьте в него ключ и сохраните. Потом вставьте флешку сюда, подождите 5 секунд и нажмите кнопку ещё раз. Флешка с самой системой не подходит — нужна другая.', '🔌');
      }
    } finally { btn.disabled = false; }
  } }, 'С флешки');

  const SECTIONS = {
    user: { icon: 'user', name: 'Пользователь', render(box) {
      const s = VOS.settings;
      const name = el('input.big-input', { value: s.name });
      box.append(row('Имя', name, el('button.btn.primary', { text: 'Сохранить', onclick: async () => { if (!name.value.trim()) return; await VOS.saveSettings({ name: name.value.trim() }); VOS.ui.toast('Имя сохранено'); } })));
      const old = el('input.big-input', { type: 'password', placeholder: 'Старый пароль' });
      const nw = el('input.big-input', { type: 'password', placeholder: 'Новый пароль' });
      const nw2 = el('input.big-input', { type: 'password', placeholder: 'Новый пароль ещё раз' });
        box.append(row('Вход', el('label.check', null, el('input', { type: 'checkbox', checked: !!s.noPassword, onchange: e => VOS.saveSettings({ noPassword: e.target.checked }) }), ' Входить без пароля (одним нажатием)')));
      box.append(el('h3', { text: 'Пароль для входа' }),
        el('p.muted', { text: s.password ? 'Пароль изменён вами.' : 'Сейчас стоит пароль по умолчанию: 1234.' }),
        el('div.form', null, old, nw, nw2, el('button.btn.primary', { text: 'Сменить пароль', onclick: async () => {
          if (!(await B.call('verifyPassword', old.value, VOS.settings.password))) return VOS.ui.alert('Неверный старый пароль', 'Введите пароль, которым вы входите сейчас.', '⚠️');
          if (nw.value.length < 1) return VOS.ui.alert('Пустой пароль', 'Придумайте новый пароль — хотя бы 4 цифры.', '⚠️');
          if (nw.value !== nw2.value) return VOS.ui.alert('Пароли не совпадают', 'Новый пароль нужно ввести два раза одинаково.', '⚠️');
          await VOS.saveSettings({ password: await B.call('hashPassword', nw.value) });
          old.value = nw.value = nw2.value = ''; VOS.ui.alert('Готово', 'Пароль изменён. Запишите его в надёжное место.', '🔒');
        } })));
    } },
    look: { icon: 'palette', name: 'Оформление', render(box) {
      const s = VOS.settings;
      const choice = (opts, cur, onPick) => { const r = el('div.row'); opts.forEach(([v, label]) => r.append(el('button.btn' + (v === cur ? '.primary' : ''), { text: label, onclick: async () => { await onPick(v); rerender(); } }))); return r; };
      box.append(row('Тема', choice([['light', '☀️ Светлая'], ['dark', '🌙 Тёмная']], s.theme, v => VOS.saveSettings({ theme: v }))));
      box.append(row('Размер текста', choice([[1, 'Обычный'], [1.15, 'Крупный'], [1.3, 'Очень крупный'], [1.5, 'Огромный']], s.fontScale, v => VOS.saveSettings({ fontScale: v }))));
      const colors = el('div.row');
      VOS.ACCENTS.forEach(a => colors.append(el('button.swatch' + (a.c === s.accent ? '.on' : ''), { title: a.name, style: { background: a.c }, onclick: async () => { await VOS.saveSettings({ accent: a.c }); rerender(); } })));
      box.append(row('Цвет', colors));
      const wp = el('div.row');
      Object.entries(VOS.WALLPAPER_NAMES).forEach(([k, n]) => wp.append(el('button.wp' + (k === s.wallpaper ? '.on' : ''), { text: n, style: { backgroundImage: VOS.wallpaperURL(k) }, onclick: async () => { await VOS.saveSettings({ wallpaper: k }); rerender(); } })));
      box.append(row('Обои', wp));
      box.append(row('Окна', el('label.check', null, el('input', { type: 'checkbox', checked: s.maximizeWindows, onchange: e => VOS.saveSettings({ maximizeWindows: e.target.checked }) }), ' Открывать программы на весь экран')));
      box.append(row('Эффекты', el('label.check', null, el('input', { type: 'checkbox', checked: s.effects !== false, onchange: e => VOS.saveSettings({ effects: e.target.checked }) }), ' Прозрачность и размытие панелей (если компьютер тормозит — выключите)')));
      const weak = VOS.weakHardware();
      box.append(row('Облегчённый режим', choice([['auto', 'Сам решает'], [true, 'Включён'], [false, 'Выключен']], s.lite, v => VOS.saveSettings({ lite: v })),
        el('div.muted', { text: 'Без размытия и с короткими анимациями — для старых компьютеров. ' +
          (s.lite === 'auto' ? (weak ? 'Сейчас включён: компьютер не самый быстрый.' : 'Сейчас выключен: компьютер достаточно быстрый.') : '') })));
    } },
    sound: { icon: 'volume', name: 'Звук и голос', async render(box) {
      const s = VOS.settings;
      box.append(row('Громкость', VOS.volumePanel()));
      const voices = await B.call('listVoices').catch(() => []);
      const sel = el('select.big-select');
      voices.forEach(v => sel.append(el('option', { value: v.id, text: v.name, selected: v.id === s.voice })));
      sel.onchange = () => VOS.saveSettings({ voice: sel.value });
      const rate = el('select.big-select');
      [[75, 'Медленно'], [95, 'Обычно'], [115, 'Быстрее']].forEach(([v, n]) => rate.append(el('option', { value: v, text: n, selected: v === s.voiceRate })));
      rate.onchange = () => VOS.saveSettings({ voiceRate: +rate.value });
      box.append(row('Голос', sel, el('button.btn', { text: '▶ Послушать', onclick: () => VOS.speak('Здравствуйте, ' + VOS.settings.name + '! Так звучит мой голос.', { force: true }) })));
      box.append(row('Скорость речи', rate));
      const chk = (key, label) => el('label.check', null, el('input', { type: 'checkbox', checked: !!s[key], onchange: e => VOS.saveSettings({ [key]: e.target.checked }) }), ' ' + label);
      box.append(row('Озвучивание', el('div.col', null, chk('voiceEnabled', 'Говорить вслух (ответы помощника, напоминания)'), chk('voiceGreeting', 'Здороваться голосом при входе'), chk('speakReminders', 'Произносить напоминания о лекарствах'))));
    } },
    net: { icon: 'wifi', name: 'Интернет', render(box) { box.append(el('p.muted', { text: 'Выберите вашу сеть Wi-Fi и введите пароль. Если подключить кабель интернета — всё заработает само.' }), VOS.wifiPanel()); } },
    place: { icon: 'globe', name: 'Город и время', render(box) {
      const s = VOS.settings;
      const city = el('input.big-input', { value: s.city });
      box.append(row('Город (для погоды)', city, el('button.btn.primary', { text: 'Сохранить', onclick: async () => { await VOS.saveSettings({ city: city.value.trim() || 'Москва' }); VOS.ui.toast('Город сохранён'); } })));
      const tz = el('select.big-select');
      TZ.forEach(([v, n]) => tz.append(el('option', { value: v, text: n, selected: v === s.timezone })));
      tz.onchange = async () => {
        const ok = await B.call('setTimezone', tz.value).catch(() => false);
        await VOS.saveSettings({ timezone: tz.value });
        VOS.ui.toast(ok ? 'Часовой пояс изменён' : 'Сохранено (применится после перезагрузки)');
      };
      box.append(row('Часовой пояс', tz));
      box.append(el('p.muted', { text: 'Время устанавливается автоматически через интернет.' }));
    } },
    ai: { icon: 'bot', name: 'Голосовой помощник', render(box) {
      const s = VOS.settings;
      const chk = (key, label) => el('label.check', null, el('input', { type: 'checkbox', checked: !!s[key], onchange: e => VOS.saveSettings({ [key]: e.target.checked }) }), ' ' + label);
      const choice = (key, opts) => { const r = el('div.row'); opts.forEach(([v, label]) => r.append(el('button.btn' + (s[key] === v ? '.primary' : ''), { text: label, onclick: async () => { await VOS.saveSettings({ [key]: v }); rerender(); } }))); return r; };
      const vstate = el('div.voice-state');
      const paintState = () => {
        const v = VOS.voice || {};
        vstate.className = 'voice-state ' + (v.state === 'on' ? 'ok' : 'off');
        vstate.textContent = v.state === 'on' ? (s.wakeEnabled ? 'Слушаю. Скажите «' + VOS.assistantName() + '» и вопрос.' : 'Распознавание готово, но постоянное слушание выключено.')
          : v.state === 'starting' || v.state === 'restarting' ? 'Запускается…'
          : 'Постоянное слушание недоступно' + (v.reason ? ': ' + v.reason : '') + '. Работает кнопка «Спросить помощника».';
      };
      paintState(); VOS.on('voice-state', paintState);
      box.append(el('p', { text: 'Помощник слушает всё время и откликается на своё имя — как «Алиса», только своё. Скажите, например: «' + VOS.assistantName() + ', какая погода?», «' + VOS.assistantName() + ', позвони внуку», «' + VOS.assistantName() + ', доброе утро».' }), vstate);
      box.append(row('Слушать всегда', chk('wakeEnabled', 'Откликаться на имя без нажатия кнопок')));
      box.append(row('Имя помощника', choice('wakeWord', Object.entries(VOS.WAKE_WORDS).map(([k, v]) => [k, v.name]))));
      box.append(row('Чуткость', choice('wakeSens', [['low', 'Низкая'], ['normal', 'Обычная'], ['high', 'Высокая']]), el('div.muted.small', { text: 'Если помощник откликается сам по себе (например, на телевизор) — выберите «Низкая». Если плохо слышит — «Высокая».' })));
      box.append(row('Разговор', el('div.col', null,
        chk('followUp', 'Если помощник задал вопрос — слушать ответ без повторного имени'),
        chk('voiceOnLock', 'Отвечать и на экране блокировки (без ввода пароля)'),
        chk('morningBrief', 'Утренняя сводка при первом входе с 5 до 12 часов'))));
      box.append(el('h3', { text: 'Ответы на любые вопросы — сервис Groq' }));
      const key = el('input.big-input', { type: 'password', value: s.groqKey, placeholder: 'gsk_…' });
      const model = el('input.big-input', { value: s.groqModel, placeholder: 'автоматически' });
      const status = el('div.muted');
      box.append(el('p.muted', { text: 'Нужен ключ (бесплатно, сайт console.groq.com). Без ключа работают простые команды, но не ответы на вопросы и не точное распознавание речи. Чтобы не перепечатывать ключ: на другом компьютере положите на обычную флешку файл groq.txt с ключом и нажмите «С флешки».' }));
      box.append(row('Ключ Groq', key, VOS.usbKeyButton(key, 'groq', async v => { await VOS.saveSettings({ groqKey: v }); }), el('label.check', null, el('input', { type: 'checkbox', onchange: e => { key.type = e.target.checked ? 'text' : 'password'; } }), ' показать')));
      box.append(row('Модель', model, el('span.muted.small', { text: 'Оставьте пустым — выберется сама' })));
      box.append(el('div.row', null,
        el('button.btn.primary', { text: 'Сохранить', onclick: async () => { await VOS.saveSettings({ groqKey: key.value.trim(), groqModel: model.value.trim() }); VOS.ui.toast('Сохранено'); } }),
        el('button.btn', { text: 'Проверить', onclick: async () => {
          await VOS.saveSettings({ groqKey: key.value.trim(), groqModel: model.value.trim() });
          status.textContent = 'Проверяю…';
          const t0 = Date.now();
          let r;
          try { r = await B.call('aiCheck', { key: VOS.settings.groqKey, model: VOS.settings.groqModel }); }
          catch (e) { r = { ok: false, error: String(e.message).replace(/^Error invoking remote method 'vos': (Error: )?/, '') }; }
          const sec = ((Date.now() - t0) / 1000).toFixed(1).replace('.', ',');
          status.textContent = r.ok ? 'Работает (модель ' + r.model + ', ответ за ' + sec + ' с): ' + r.text.slice(0, 60)
            : 'Не работает: ' + r.error + (r.detail ? ' Ответ сервера: ' + r.detail : '');
        } })), status);
    } },
    family: { icon: 'heart', name: 'Родные и связь', render(box) {
      const s = VOS.settings;
      box.append(el('p', { text: 'Здесь настраивается то, что обычно делают внуки: уведомления в Telegram и сервер для видеозвонков. Сами родные добавляются в программе «Родные».' }),
        el('button.btn.primary', { text: '@heart', onclick: () => VOS.wm.open('contacts') }, 'Открыть «Родные»'));
      box.append(el('h3', { text: 'Telegram-бот: звонки и просьбы о помощи приходят родным в Telegram' }));
      box.append(el('ol.howto', null,
        el('li', { text: 'В Telegram откройте @BotFather → /newbot → придумайте имя. Он пришлёт токен вида 123456:ABC…' }),
        el('li', { text: 'Вставьте токен ниже и нажмите «Проверить».' }),
        el('li', { text: 'Каждый родственник открывает этого бота и нажимает «Старт».' }),
        el('li', { text: 'В «Родных» в карточке родственника нажмите «Найти» рядом с Telegram.' })));
      const tok = el('input.big-input', { type: 'password', value: s.tgToken, placeholder: '123456789:AA…' });
      const st = el('div.muted');
      box.append(row('Токен бота', tok, VOS.usbKeyButton(tok, 'tg', async v => { await VOS.saveSettings({ tgToken: v }); }), el('button.btn.primary', { text: 'Проверить', onclick: async () => {
        await VOS.saveSettings({ tgToken: tok.value.trim() });
        st.textContent = 'Проверяю…';
        try { const me = await B.call('tgMe', VOS.settings.tgToken); st.textContent = 'Работает: бот @' + me.username + '. Родные должны открыть его и нажать «Старт».'; }
        catch (e) { st.textContent = 'Ошибка: ' + String(e.message).replace(/^Error invoking remote method 'vos': (Error: )?/, ''); }
      } })), st);
      box.append(el('h3', { text: 'Видеозвонки' }));
      const srv = el('input.big-input', { value: s.jitsiServer, placeholder: 'meet.ffmuc.net' });
      box.append(el('p.muted', { text: 'Лучше всего, если у каждого родственника в карточке указана своя ссылка (Яндекс Телемост, VK Звонки). Если ссылки нет, звонок идёт в комнату Jitsi на этом сервере — нужен сервер, где не требуется вход в аккаунт.' }),
        row('Сервер Jitsi', srv, el('button.btn', { text: 'Сохранить', onclick: async () => { await VOS.saveSettings({ jitsiServer: srv.value.trim() || 'meet.ffmuc.net' }); VOS.ui.toast('Сохранено'); } })));
      box.append(el('h3', { text: 'Удалённая помощь' }), el('button.btn', { text: '@help', onclick: () => VOS.wm.open('help') }, 'Открыть «Помощь с компьютером»'));
    } },
    about: { icon: 'info', name: 'О системе', render(box) {
      const m = VOS.mode || {};
      const modeText = m.mode === 'installed' ? 'Установлена на жёсткий диск. Все данные сохраняются.'
        : m.persistent ? 'Пробный режим с флешки. Данные сохраняются на флешке.'
        : 'Пробный режим с флешки. Данные хранятся только в памяти и пропадут после выключения. Жёсткий диск ноутбука не трогается.';
      box.append(el('div.about', null, el('div.about-logo', { html: VOS.logoSVG(80) }), el('div', null, el('h2', { text: 'ВячеславOS 1.5' }), el('p', { text: modeText }))));
      if (m.live) box.append(el('button.btn.primary.big', { text: '💽 Установить ВячеславOS на этот компьютер', onclick: () => VOS.screens.installer() }));
      const hw = m.hw || {};
      if (hw.cpu) box.append(el('p.muted', { text: 'Процессор: ' + hw.cpu.replace(/\(R\)|\(TM\)|CPU/g, '').replace(/\s+/g, ' ').trim() + ', ядер: ' + hw.cores + ', память: ' + String(hw.memGB).replace('.', ',') + ' ГБ' + (m.toram ? '. Система загружена в память — флешка почти не используется.' : '') }));
      const dh = el('div.disk-list', null, el('div.muted', { text: 'Проверяю жёсткий диск…' }));
      box.append(el('h3', { text: 'Жёсткий диск' }), dh,
        el('div.row', null, el('button.btn', { text: '@refresh', onclick: () => paintDisks(true) }, 'Проверить ещё раз')));
      async function paintDisks(fresh) {
        dh.textContent = ''; dh.append(el('div.muted', { text: 'Проверяю жёсткий диск…' }));
        const list = await VOS.disk.checkAll();
        dh.textContent = '';
        if (!list.length) dh.append(el('div.muted', { text: 'Встроенный жёсткий диск не найден.' }));
        list.forEach(x => dh.append(VOS.disk.card(x, (x.details.model || x.disk.model) + ', ' + VOS.fmtSize(x.disk.size))));
        if (fresh) VOS.sound.click();
      }
      paintDisks(false);
      const dev = el('input.big-input', { value: VOS.settings.deviceName || '', placeholder: 'Ноутбук ' + VOS.genitive(VOS.settings.name) });
      box.append(row('Имя компьютера', dev, el('button.btn', { text: 'Сохранить', onclick: async () => { if (!dev.value.trim()) return; await B.call('setHostname', dev.value.trim()).catch(() => {}); await VOS.saveSettings({ deviceName: dev.value.trim() }); VOS.ui.toast('Имя компьютера сохранено'); } })));
      const bst = el('div.muted');
      const usbDir = async () => {
        const devs = await B.call('usbList').catch(() => []);
        for (const d of devs) { const mp = d.mountpoint || await B.call('usbMount', d.path).catch(() => null); if (mp) return mp; }
        return null;
      };
      box.append(el('h3', { text: 'Резервная копия на флешку' }),
        el('p.muted', { text: 'Сохраняет заметки, лекарства, родных, дневник давления, настройки и фото. Пригодится при переустановке или новом компьютере.' }),
        el('div.row', null,
          el('button.btn.primary', { text: '@download', onclick: async () => {
            const dir = await usbDir(); if (!dir) return VOS.ui.alert('Флешка не найдена', 'Вставьте флешку и подождите 5 секунд.', '🔌');
            bst.textContent = 'Сохраняю…';
            try { const r = await B.call('backupCreate', dir, true); bst.textContent = 'Готово: копия сохранена (' + VOS.fmtSize(r.size) + '). Флешку можно вынуть.'; VOS.sound.chime(); }
            catch (e) { bst.textContent = 'Не получилось: ' + String(e.message || e).replace(/^Error invoking remote method 'vos': (Error: )?/, ''); }
          } }, 'Сохранить копию на флешку'),
          el('button.btn', { text: '@refresh', onclick: async () => {
            const dir = await usbDir(); if (!dir) return VOS.ui.alert('Флешка не найдена', 'Вставьте флешку с копией.', '🔌');
            const list = await B.call('backupList', dir).catch(() => []);
            if (!list.length) return VOS.ui.alert('Копий нет', 'На этой флешке нет копии ВячеславOS.', 'ℹ️');
            const c = list[0];
            if (!(await VOS.ui.confirm({ title: 'Восстановить копию от ' + new Date(c.mtime).toLocaleDateString('ru-RU') + '?', text: 'Текущие записи заменятся записями из копии.', yes: 'Восстановить', danger: true }))) return;
            bst.textContent = 'Восстанавливаю…';
            try { await B.call('backupRestore', c.file); await VOS.ui.alert('Готово', 'Данные восстановлены. Рабочий стол перезапустится.', 'ℹ️'); B.call('reloadShell'); }
            catch (e) { bst.textContent = 'Не получилось: ' + String(e.message || e); }
          } }, 'Восстановить с флешки')), bst);
      box.append(el('h3', { text: 'Обучение' }), el('div.row', null,
        el('button.btn', { text: '@sparkle', onclick: () => { VOS.wm.closeAll(); VOS.tour(); } }, 'Экскурсия по экрану'),
        el('button.btn', { text: '@grid', onclick: () => VOS.wm.open('learn') }, 'Уроки'),
        el('button.btn', { text: '@refresh', onclick: async () => { if (await VOS.ui.confirm({ title: 'Пройти первоначальную настройку заново?', text: 'Записи не пропадут.', yes: 'Начать' })) { VOS.wm.closeAll(); VOS.oobe.start({ again: true }); } } }, 'Первоначальная настройка')));
      box.append(row('Графика', el('label.check', null, el('input', { type: 'checkbox', checked: VOS.settings.hwAccel, onchange: async e => {
        await VOS.saveSettings({ hwAccel: e.target.checked });
        if (await VOS.ui.confirm({ title: 'Перезапустить рабочий стол?', text: 'Изменение вступит в силу после перезапуска. Если экран начнёт мигать — выключите эту галочку.', yes: 'Перезапустить' })) B.call('reloadShell');
      } }), ' Аппаратное ускорение (быстрее, но на видеокарте GT 320M возможны помехи)')));
      box.append(el('p.muted.small', { text: 'Основа: ядро Linux и Debian 13, оболочка ВячеславOS. Режим загрузки: ' + (m.mode || '?') + (m.safeGraphics ? ', безопасная графика' : '') + '.' }));
    } }
  };
  let rerender = () => {};

  VOS.registerApp({
    id: 'settings', title: 'Настройки', width: 1020, height: 700,
    words: ['настройки', 'параметры', 'настройку'],
    open(w, args) {
      let cur = args.section || 'user';
      const nav = el('div.set-nav'), box = el('div.set-box');
      const render = async () => {
        nav.textContent = '';
        Object.entries(SECTIONS).forEach(([k, sct]) => nav.append(el('button.set-tab' + (k === cur ? '.on' : ''), { onclick: () => { cur = k; render(); } }, VOS.gl(sct.icon), el('span', { text: sct.name }))));
        box.textContent = '';
        box.append(el('h2.set-h', null, VOS.gl(SECTIONS[cur].icon), el('span', { text: SECTIONS[cur].name })));
        await SECTIONS[cur].render(box);
      };
      rerender = render;
      w.body.append(el('div.settings', null, nav, box));
      render();
      w.onArgs = a => { if (a.section) { cur = a.section; render(); } };
    }
  });
})();
