/*
 * «Счётчики и платежи»: показания воды, света и газа по месяцам
 * (видно, сколько израсходовано) и ежемесячные напоминания —
 * «передать показания» 20-го числа, «оплатить квартплату» 10-го и т.п.
 * Напоминания срабатывают в scheduler.js и попадают в утреннюю сводку.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;
  const DEFAULT = {
    meters: [
      { id: 'cold', name: 'Холодная вода', unit: 'м³', readings: [] },
      { id: 'hot', name: 'Горячая вода', unit: 'м³', readings: [] },
      { id: 'elec', name: 'Электричество', unit: 'кВт·ч', readings: [] }
    ],
    reminders: [
      { id: 'r1', title: 'Передать показания счётчиков', day: 20, enabled: true },
      { id: 'r2', title: 'Оплатить квартплату', day: 10, enabled: true }
    ]
  };
  const load = async () => VOS.store.get('meters', JSON.parse(JSON.stringify(DEFAULT)));
  const save = d => VOS.store.set('meters', d);

  VOS.metersApi = {
    // напоминания на сегодня, ещё не отмеченные
    async dueToday() {
      const d = await load(), now = new Date(), key = VOS.dateKey(now).slice(0, 7);
      const last = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
      return d.reminders.filter(r => r.enabled && Math.min(r.day, last) === now.getDate() && r.doneMonth !== key);
    },
    async markDone(id) {
      const d = await load(), r = d.reminders.find(x => x.id === id);
      if (r) { r.doneMonth = VOS.dateKey(new Date()).slice(0, 7); await save(d); }
    }
  };

  VOS.registerApp({
    id: 'meters', title: 'Счётчики и платежи', desktop: false, width: 960, height: 680,
    words: ['счётчики', 'счетчики', 'показания', 'квартплата', 'платежи', 'коммуналка'],
    async open(w) {
      let data = await load();
      const list = el('div.list'), rem = el('div.list');
      const fmt = v => VOS.fmtNum(v, 3);
      function render() {
        list.textContent = ''; rem.textContent = '';
        data.meters.forEach(m => {
          const r = m.readings.slice().sort((a, b) => a.date.localeCompare(b.date));
          const lastR = r[r.length - 1], prev = r[r.length - 2];
          const diff = lastR && prev ? lastR.value - prev.value : null;
          list.append(el('div.list-row.meter', null,
            el('span.meter-ic', { html: VOS.glyph('gauge') }),
            el('div.grow', null, el('b', { text: m.name }),
              el('div.muted', { text: lastR ? 'Последние: ' + fmt(lastR.value) + ' ' + m.unit + ' (' + new Date(lastR.date).toLocaleDateString('ru-RU') + ')' + (diff !== null ? ' · израсходовано ' + fmt(diff) + ' ' + m.unit : '') : 'Показаний ещё нет' })),
            el('button.btn.primary', { text: '➕ Записать', onclick: async () => {
              const v = await VOS.ui.prompt({ title: m.name, text: 'Цифры со счётчика' + (lastR ? ' (в прошлый раз ' + fmt(lastR.value) + ')' : ''), type: 'number' });
              if (v == null || v === '' || !isFinite(Number(v))) return;
              if (lastR && Number(v) < lastR.value && !(await VOS.ui.confirm({ title: 'Меньше, чем в прошлый раз', text: 'Обычно показания только растут. Записать всё равно?', yes: 'Записать' }))) return;
              m.readings.push({ date: VOS.dateKey(new Date()), value: Number(v) });
              await save(data); render();
              VOS.ui.toast('Записано: ' + m.name + ' — ' + fmt(Number(v)));
            } }),
            el('button.btn.small', { text: '📝', title: 'История', onclick: () => VOS.ui.dialog({ title: m.name, body: el('div.list', null,
              r.length ? r.slice().reverse().map((x, i, arr) => el('div.list-row', null, el('span.grow', { text: new Date(x.date).toLocaleDateString('ru-RU') }), el('b', { text: fmt(x.value) + ' ' + m.unit }),
                arr[i + 1] ? el('span.muted', { text: '+' + fmt(x.value - arr[i + 1].value) }) : null)) : el('div.empty', { text: 'Пусто' })) }) }),
            el('button.btn.small', { text: '🗑', title: 'Удалить счётчик', onclick: async () => { if (await VOS.ui.confirm({ title: 'Удалить «' + m.name + '»?', yes: 'Удалить', danger: true })) { data.meters = data.meters.filter(x => x !== m); await save(data); render(); } } })));
        });
        data.reminders.forEach(r => rem.append(el('div.list-row', null,
          el('span.rem-day', { text: r.day }),
          el('div.grow', null, el('b', { text: r.title }), el('div.muted', { text: 'каждый месяц ' + r.day + '-го числа' + (r.doneMonth === VOS.dateKey(new Date()).slice(0, 7) ? ' · в этом месяце сделано' : '') })),
          el('label.check', null, el('input', { type: 'checkbox', checked: r.enabled, onchange: async e => { r.enabled = e.target.checked; await save(data); } }), ' напоминать'),
          el('button.btn.small', { text: '🗑', onclick: async () => { data.reminders = data.reminders.filter(x => x !== r); await save(data); render(); } }))));
      }
      w.body.append(el('div.app-pad', null,
        el('div.toolbar', null, el('h2', { text: 'Счётчики' }), el('span.spacer'),
          el('button.btn', { text: '➕ Другой счётчик', onclick: async () => {
            const n = await VOS.ui.prompt({ title: 'Название счётчика', placeholder: 'Например: Газ' });
            if (!n) return;
            data.meters.push({ id: VOS.uid(), name: n.trim(), unit: /газ/i.test(n) ? 'м³' : /свет|электр/i.test(n) ? 'кВт·ч' : 'м³', readings: [] });
            await save(data); render();
          } })),
        list,
        el('div.toolbar', { style: { marginTop: '1.2rem' } }, el('h2', { text: 'Напоминания каждый месяц' }), el('span.spacer'),
          el('button.btn', { text: '➕ Напоминание', onclick: async () => {
            const t = el('input.big-input', { placeholder: 'Например: Оплатить телефон' });
            const d = el('input.big-input.num', { type: 'number', min: 1, max: 31, value: 15 });
            const ok = await VOS.ui.dialog({ icon: '⏰', title: 'Новое напоминание', body: el('div.form', null, t, el('label', { text: 'Какого числа' }), d), buttons: [{ label: 'Отмена', value: false }, { label: 'Сохранить', value: true, primary: true }] });
            if (!ok || !t.value.trim()) return;
            data.reminders.push({ id: VOS.uid(), title: t.value.trim(), day: Math.min(31, Math.max(1, +d.value || 1)), enabled: true });
            await save(data); render();
          } })),
        rem));
      render();
    }
  });
})();
