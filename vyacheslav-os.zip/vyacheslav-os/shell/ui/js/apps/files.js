/*
 * «Мои файлы» — проводник для дедушки.
 *  • слева: Документы, Загрузки, Фото, Голосовые заметки, Корзина и флешки;
 *  • файлы — крупными плитками; нажатие выделяет, двойное нажатие открывает;
 *  • внизу кнопки для выделенного: Открыть, На флешку / В компьютер,
 *    Копировать, Вставить, Переименовать, Удалить;
 *  • «Создать»: папку, текст (Word), таблицу (Excel), презентацию;
 *  • флешка: сколько свободно, «Извлечь» (после этого можно вынимать).
 * Плюс программы «Текст», «Таблицы», «Презентации» — создать новый
 * документ или открыть недавний, и просмотр фото, музыки и видео.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const err = e => String((e && e.message) || e).replace(/^Error invoking remote method 'vos': (Error: )?/, '');
  const fmtSize = b => !b ? '0 КБ' : b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' ГБ' : b >= 1e6 ? (b / 1e6).toFixed(b >= 1e7 ? 0 : 1).replace('.', ',') + ' МБ' : Math.max(1, Math.round(b / 1e3)) + ' КБ';
  const fileUrl = p => 'file://' + String(p).split('/').map(encodeURIComponent).join('/');
  const KIND_ICON = { folder: ['files', null], doc: ['doc', null], sheet: ['sheet', null], slides: ['slides', null], pdf: ['doc', 'PDF'], image: ['photos', null], audio: ['radio', null], video: ['video', null], archive: ['files', 'ZIP'], file: ['notes', null] };
  const KIND_NAME = { doc: 'Документ', sheet: 'Таблица', slides: 'Презентация', pdf: 'PDF', image: 'Фото', audio: 'Музыка', video: 'Видео', archive: 'Архив', file: 'Файл', folder: 'Папка' };
  const DOC_KINDS = { doc: ['Текст (Word)', 'Новый документ'], sheet: ['Таблица (Excel)', 'Новая таблица'], slides: ['Презентация (PowerPoint)', 'Новая презентация'] };

  let clipboard = null;            // { paths, move }
  let dirs = null;
  const getDirs = async () => (dirs = dirs || await B.call('fsDirs'));

  /* ---------- открыть файл ---------- */
  async function openPath(p, siblings) {
    let r;
    try { r = await B.call('fsOpen', p); } catch (e) { return VOS.ui.alert('Не открывается', err(e), '⚠️'); }
    if (r.viewer === 'image') return viewImage(p, (siblings || []).filter(x => x.kind === 'image').map(x => x.path));
    if (r.viewer === 'audio' || r.viewer === 'video') return viewMedia(p, r.viewer);
    if (r.viewer === 'folder') return VOS.wm.open('files', { path: p });
    if (r.launched) VOS.ui.toast(r.launched === 'soffice' ? 'Открываю документ… Это может занять до 20 секунд. Закрыть — крестик вверху справа.' : 'Открываю…', 6000);
    return r;
  }
  VOS.files = { open: openPath };

  function viewImage(p, list) {
    if (!list.length) list = [p];
    let i = Math.max(0, list.indexOf(p));
    const o = VOS.ui.overlay('viewer');
    const img = el('img.viewer-img');
    const cap = el('div.viewer-cap');
    const show = () => { img.src = fileUrl(list[i]); cap.textContent = list[i].split('/').pop() + (list.length > 1 ? '  ·  ' + (i + 1) + ' из ' + list.length : ''); };
    const close = () => { o.remove(); document.removeEventListener('keydown', key); };
    const key = e => { if (e.key === 'Escape') close(); if (e.key === 'ArrowRight') { i = (i + 1) % list.length; show(); } if (e.key === 'ArrowLeft') { i = (i - 1 + list.length) % list.length; show(); } };
    document.addEventListener('keydown', key);
    o.append(img, cap, el('div.viewer-btns', null,
      list.length > 1 ? el('button.btn.huge', { text: '◀ Назад', onclick: () => { i = (i - 1 + list.length) % list.length; show(); } }) : null,
      el('button.btn.huge.primary', { text: '✕ Закрыть', onclick: close }),
      list.length > 1 ? el('button.btn.huge', { text: 'Дальше ▶', onclick: () => { i = (i + 1) % list.length; show(); } }) : null));
    show();
  }
  function viewMedia(p, kind) {
    if (VOS.radioStop) VOS.radioStop();
    const o = VOS.ui.overlay('viewer');
    const m = el(kind === 'video' ? 'video.viewer-video' : 'audio.viewer-audio', { src: fileUrl(p), controls: true, autoplay: true });
    const close = () => { try { m.pause(); } catch (_) { /* */ } o.remove(); };
    o.append(kind === 'audio' ? el('div.viewer-music', { html: VOS.appIcon('radio', 140) }) : null, m, el('div.viewer-cap', { text: p.split('/').pop() }),
      el('div.viewer-btns', null, el('button.btn.huge.primary', { text: '✕ Закрыть', onclick: close })));
  }

  /* ---------- копирование с окном прогресса ---------- */
  let progressCb = null;
  B.on('fs-progress', p => { if (progressCb) progressCb(p); });
  async function doCopy(paths, dest, { move = false, toUsb = false, label = '' } = {}) {
    const o = VOS.ui.overlay('copying');
    const bar = el('div.sp-bar-fill'), txt = el('p', { text: 'Подготовка…' });
    o.append(el('div.dialog', null, el('h2', { text: (move ? 'Переношу ' : 'Копирую ') + paths.length + ' ' + VOS.plural(paths.length, 'файл', 'файла', 'файлов') + (label ? ' ' + label : '') }),
      el('div.sp-bar.in-bar', null, bar), txt, toUsb ? el('p.muted', { text: 'Не вынимайте флешку, пока не закончится.' }) : null));
    progressCb = p => { bar.style.width = p.percent + '%'; txt.textContent = p.syncing ? 'Записываю на флешку до конца…' : fmtSize(p.done) + ' из ' + fmtSize(p.total) + ' — ' + p.percent + '%'; };
    try {
      const out = await B.call('fsCopy', paths, dest, move);
      o.remove(); progressCb = null;
      VOS.sound.chime && VOS.sound.chime();
      VOS.ui.toast(toUsb ? 'Готово! Скопировано на флешку.' : 'Готово! ' + (move ? 'Перенесено.' : 'Скопировано.'), 4000);
      return out;
    } catch (e) { o.remove(); progressCb = null; VOS.ui.alert('Не получилось скопировать', err(e), '⚠️'); return null; }
  }
  // куда копировать: флешка (если одна — сразу) или папка компьютера
  async function pickTarget(roots, kind) {
    const list = kind === 'usb' ? roots.filter(r => r.kind === 'usb') : roots.filter(r => r.kind === 'home');
    if (kind === 'usb' && !list.length) { await VOS.ui.alert('Флешка не вставлена', 'Вставьте флешку и подождите 5 секунд.', '🔌'); return null; }
    if (list.length === 1) return list[0];
    const box = el('div.fm-pick');
    let chosen = null;
    const p = VOS.ui.dialog({ title: kind === 'usb' ? 'На какую флешку?' : 'Куда положить?', body: box, buttons: [{ label: 'Отмена', value: null }] });
    list.forEach(r => box.append(el('button.btn.huge', { onclick: () => { chosen = r; box.closest('.dialog').querySelector('.dialog-btns .btn').click(); } }, el('span', { html: VOS.glyph(r.kind === 'usb' ? 'usb' : 'folder') }), r.name)));
    await p;
    return chosen;
  }

  /* ---------- окно «Мои файлы» ---------- */
  VOS.registerApp({
    id: 'files', title: 'Мои файлы', width: 1180, height: 700, maximized: true,
    words: ['мои файлы', 'файлы', 'проводник', 'папки', 'документы', 'флешка', 'флешку', 'загрузки', 'скачанное', 'корзина'],
    async open(w, args) {
      await getDirs();
      let roots = [], cur = null, curRoot = null, entries = [], sel = new Set(), history = [];
      const side = el('div.fm-side'), grid = el('div.fm-grid'), crumbs = el('div.fm-crumbs'), actions = el('div.fm-actions'), info = el('div.fm-info.muted');
      const backBtn = el('button.btn', { text: '@back', title: 'Назад', onclick: () => { if (history.length) go(history.pop(), false); } });
      const upBtn = el('button.btn', { text: '@up', title: 'Наверх', onclick: () => { if (cur && curRoot && cur !== curRoot.path) go(cur.slice(0, cur.lastIndexOf('/')) || curRoot.path); } });
      const newBtn = el('button.btn.primary', { text: '@plus', onclick: () => createDialog() }, 'Создать');
      const pasteBtn = el('button.btn.hidden', { text: '@copy', onclick: () => paste() }, 'Вставить');
      const trashBtn = el('button.btn.danger.hidden', { text: '@trash', onclick: async () => { if (await VOS.ui.confirm({ title: 'Очистить корзину?', text: 'Файлы удалятся насовсем.', yes: 'Очистить', danger: true })) { await B.call('fsEmptyTrash'); refresh(); } } }, 'Очистить корзину');
      w.body.append(el('div.fm', null, side,
        el('div.fm-main', null, el('div.fm-top', null, backBtn, upBtn, crumbs, el('span.spacer'), pasteBtn, trashBtn, newBtn), grid, info, actions)));

      async function loadRoots() {
        roots = await B.call('fsRoots').catch(() => []);
        side.textContent = '';
        let usbHead = false;
        roots.forEach(r => {
          if (r.kind === 'usb' && !usbHead) { side.append(el('div.fm-side-h', { text: 'Флешки' })); usbHead = true; }
          const b = el('button.fm-root' + (curRoot && curRoot.id === r.id ? '.on' : ''), { onclick: () => { curRoot = r; go(r.path); } },
            el('span.fm-root-ic', { html: VOS.glyph(r.kind === 'usb' ? 'usb' : r.kind === 'trash' ? 'trash' : r.id === 'downloads' ? 'download' : r.id === 'photos' ? 'image' : r.id === 'voice' ? 'mic' : 'folder') }),
            el('span.grow', null, el('b', { text: r.name }), r.kind === 'usb' && r.free != null ? el('div.muted.small', { text: 'свободно ' + fmtSize(r.free) + ' из ' + fmtSize(r.total) }) : null));
          side.append(b);
          if (r.kind === 'usb') side.append(el('button.btn.small.fm-eject', { text: '@eject', onclick: () => eject(r) }, 'Извлечь'));
        });
        if (!usbHead) side.append(el('div.fm-side-h', { text: 'Флешки' }), el('div.muted.small.fm-nousb', { text: 'Вставьте флешку — она появится здесь.' }));
      }
      async function eject(r) {
        const ok = await B.call('fsEject', r.dev).catch(() => false);
        if (ok) { VOS.sound.chime && VOS.sound.chime(); await VOS.ui.alert('Флешку можно вынуть', 'Всё записано. Теперь флешку можно вынуть.', '✅'); }
        else VOS.ui.alert('Не получилось', 'Флешка ещё занята. Закройте открытые с неё документы и попробуйте снова.', '⚠️');
        if (curRoot && curRoot.id === r.id) { curRoot = roots[0]; await loadRoots(); go(curRoot.path, false); } else loadRoots();
      }
      const rootOf = p => roots.filter(r => p === r.path || p.startsWith(r.path + '/')).sort((a, b) => b.path.length - a.path.length)[0];

      async function go(p, remember = true) {
        if (remember && cur && cur !== p) history.push(cur);
        let r;
        try { r = await B.call('fsList', p); } catch (e) { VOS.ui.toast(err(e)); if (!cur) { curRoot = roots[0]; return go(roots[0].path, false); } return; }
        cur = r.path; entries = r.entries; sel.clear();
        curRoot = rootOf(cur) || curRoot;
        side.querySelectorAll('.fm-root').forEach((b, i) => b.classList.toggle('on', roots.filter(x => true)[i] === curRoot));
        paintCrumbs(); paintGrid(); paintActions();
        w.setTitle(cur === (curRoot && curRoot.path) ? curRoot.name : cur.split('/').pop());
      }
      const refresh = () => go(cur, false);

      function paintCrumbs() {
        crumbs.textContent = '';
        if (!curRoot) return;
        const rel = cur.slice(curRoot.path.length).split('/').filter(Boolean);
        let acc = curRoot.path;
        crumbs.append(el('button.fm-crumb', { text: curRoot.name, onclick: () => go(curRoot.path) }));
        rel.forEach(part => { acc += '/' + part; const to = acc; crumbs.append(el('span.muted', { text: '›' }), el('button.fm-crumb', { text: part, onclick: () => go(to) })); });
        backBtn.disabled = !history.length; upBtn.disabled = cur === curRoot.path;
        trashBtn.classList.toggle('hidden', curRoot.kind !== 'trash' || !entries.length);
        newBtn.classList.toggle('hidden', curRoot.kind === 'trash');
        pasteBtn.classList.toggle('hidden', !clipboard || curRoot.kind === 'trash');
      }
      function paintGrid() {
        grid.textContent = '';
        if (!entries.length) {
          grid.append(el('div.empty.fm-empty', { text: curRoot && curRoot.kind === 'trash' ? 'Корзина пуста.' : curRoot && curRoot.kind === 'usb' ? 'На флешке пусто. Выберите файлы в «Документах» и нажмите «На флешку».' : 'Здесь пока пусто. Нажмите «Создать», чтобы сделать документ или папку.' }));
          return;
        }
        entries.forEach(e => {
          const [ic, badge] = KIND_ICON[e.kind] || KIND_ICON.file;
          const t = el('button.fm-item' + (sel.has(e.path) ? '.sel' : ''), {
            title: e.name,
            onclick: () => { if (sel.has(e.path)) sel.delete(e.path); else sel.add(e.path); t.classList.toggle('sel'); paintActions(); },
            ondblclick: () => { sel.clear(); openEntry(e); }
          },
          el('span.fm-check', { html: VOS.glyph('check') }),
          el('span.fm-ic', { html: VOS.appIcon(ic, 64) }, badge ? el('span.fm-badge', { text: badge }) : null),
          el('span.fm-name', { text: e.name }),
          el('span.fm-meta.muted', { text: e.dir ? 'Папка' : (KIND_NAME[e.kind] || 'Файл') + ' · ' + fmtSize(e.size) }));
          grid.append(t);
        });
      }
      function openEntry(e) { if (e.dir) go(e.path); else openPath(e.path, entries); }

      function paintActions() {
        actions.textContent = '';
        const n = sel.size;
        const inTrash = curRoot && curRoot.kind === 'trash', onUsb = curRoot && curRoot.kind === 'usb';
        info.textContent = n ? 'Выбрано: ' + n + '. ' : (entries.length ? 'Нажмите на файл, чтобы выбрать его. Двойное нажатие — открыть.' : '');
        if (!n) return;
        const paths = [...sel];
        const one = n === 1 ? entries.find(e => e.path === paths[0]) : null;
        if (inTrash) {
          actions.append(el('button.btn.big.primary', { text: '@undo', onclick: async () => { await B.call('fsRestore', paths); VOS.ui.toast('Возвращено на место'); refresh(); } }, 'Вернуть'),
            el('button.btn.big.danger', { text: '@trash', onclick: async () => { if (await VOS.ui.confirm({ title: 'Удалить насовсем?', text: 'Вернуть уже не получится.', yes: 'Удалить', danger: true })) { await B.call('fsDelete', paths); refresh(); } } }, 'Удалить насовсем'));
          return;
        }
        if (one) actions.append(el('button.btn.big.primary', { text: '@eye', onclick: () => openEntry(one) }, 'Открыть'));
        if (!onUsb) actions.append(el('button.btn.big', { text: '@usb', onclick: async () => { const t = await pickTarget(roots, 'usb'); if (t) { await doCopy(paths, t.path, { toUsb: true, label: 'на флешку' }); loadRoots(); } } }, 'На флешку'));
        else actions.append(el('button.btn.big', { text: '@download', onclick: async () => {
          const allPhotos = paths.every(p => (entries.find(e => e.path === p) || {}).kind === 'image');
          const homes = roots.filter(r => r.kind === 'home');
          const t = allPhotos ? homes.find(r => r.id === 'photos') : await pickTarget(roots, 'home');
          if (t) { const out = await doCopy(paths, t.path, { label: 'в «' + t.name + '»' }); if (out) VOS.ui.toast('Скопировано в «' + t.name + '»', 4000); }
        } }, 'В компьютер'));
        actions.append(el('button.btn.big', { text: '@copy', onclick: () => { clipboard = { paths, move: false }; VOS.ui.toast('Скопировано. Откройте нужную папку и нажмите «Вставить».', 4500); paintCrumbs(); } }, 'Копировать'));
        if (one) actions.append(el('button.btn.big', { text: '@edit', onclick: async () => {
          const name = await VOS.ui.prompt({ title: 'Новое имя', value: one.name });
          if (!name || name === one.name) return;
          try { await B.call('fsRename', one.path, name); refresh(); } catch (e) { VOS.ui.alert('Не получилось', err(e), '⚠️'); }
        } }, 'Переименовать'));
        actions.append(el('button.btn.big.danger', { text: '@trash', onclick: async () => {
          const ok = await VOS.ui.confirm({ title: 'Удалить ' + (n === 1 ? '«' + one.name + '»' : n + ' ' + VOS.plural(n, 'файл', 'файла', 'файлов')) + '?',
            text: onUsb ? 'С флешки файлы удаляются насовсем.' : 'Файлы попадут в Корзину — оттуда их можно вернуть.', yes: 'Удалить', danger: true });
          if (ok) { await B.call('fsDelete', paths); refresh(); }
        } }, 'Удалить'));
      }
      async function paste() {
        if (!clipboard) return;
        const toUsb = curRoot && curRoot.kind === 'usb';
        const out = await doCopy(clipboard.paths, cur, { toUsb, move: clipboard.move });
        if (out) { clipboard = null; refresh(); loadRoots(); }
      }
      async function createDialog() {
        const box = el('div.fm-create');
        let pick = null;
        const p = VOS.ui.dialog({ title: 'Что создать?', body: box, buttons: [{ label: 'Отмена', value: null }] });
        [['folder', 'Папку', 'files'], ['doc', 'Текст (Word)', 'doc'], ['sheet', 'Таблицу (Excel)', 'sheet'], ['slides', 'Презентацию', 'slides']].forEach(([k, label, ic]) =>
          box.append(el('button.fm-create-btn', { onclick: () => { pick = k; box.closest('.dialog').querySelector('.dialog-btns .btn').click(); } }, el('span', { html: VOS.appIcon(ic, 56) }), el('b', { text: label }))));
        await p;
        if (!pick) return;
        if (pick === 'folder') {
          const name = await VOS.ui.prompt({ title: 'Название папки', value: 'Новая папка' });
          if (name) { try { await B.call('fsMkdir', cur, name); refresh(); } catch (e) { VOS.ui.alert('Не получилось', err(e), '⚠️'); } }
          return;
        }
        await createDoc(pick, cur);
        refresh();
      }

      // флешку вставили или вынули — обновляем список слева
      let lastUsb = '';
      const poll = setInterval(async () => {
        const rs = await B.call('fsRoots').catch(() => null); if (!rs) return;
        const key = rs.filter(r => r.kind === 'usb').map(r => r.id).join(',');
        if (key === lastUsb) return;
        const added = key.length > lastUsb.length;
        lastUsb = key; await loadRoots();
        if (curRoot && curRoot.kind === 'usb' && !roots.some(r => r.id === curRoot.id)) { curRoot = roots[0]; go(curRoot.path, false); VOS.ui.toast('Флешку вынули'); }
        else if (added) VOS.ui.toast('Флешка вставлена — она слева, в разделе «Флешки».', 4500);
      }, 4000);

      await loadRoots();
      lastUsb = roots.filter(r => r.kind === 'usb').map(r => r.id).join(',');
      const startAt = a => a.usb ? roots.find(r => r.kind === 'usb') : a.root ? roots.find(r => r.id === a.root) : a.path ? rootOf(a.path) : null;
      const first = startAt(args || {}) || roots[0];
      curRoot = first;
      if (args && args.usb && !roots.some(r => r.kind === 'usb')) VOS.ui.toast('Флешка не вставлена. Вставьте её — она появится слева.', 5000);
      await go(args && args.path ? args.path : first.path, false);
      w.onArgs = async a => { await loadRoots(); const r = startAt(a); if (r) { curRoot = r; go(a.path || r.path); } };
      return () => clearInterval(poll);
    }
  });

  /* ---------- новый документ ---------- */
  async function createDoc(kind, dir) {
    const d = await getDirs();
    const name = await VOS.ui.prompt({ title: 'Как назвать?', text: 'Например: «Письмо внуку» или «Расходы на дачу».', value: DOC_KINDS[kind][1] });
    if (!name) return null;
    try {
      const p = await B.call('fsNewDoc', kind, dir || d.docs, name);
      await openPath(p);
      return p;
    } catch (e) { VOS.ui.alert('Не получилось', err(e), '⚠️'); return null; }
  }
  VOS.files.createDoc = createDoc;

  /* ---------- «Текст», «Таблицы», «Презентации» ---------- */
  Object.entries({ doc: ['Текст', ['текст', 'word', 'ворд', 'документ', 'написать письмо', 'напечатать']], sheet: ['Таблицы', ['таблица', 'таблицы', 'excel', 'эксель']], slides: ['Презентации', ['презентация', 'презентацию', 'powerpoint', 'пауэрпоинт']] })
    .forEach(([kind, [title, words]]) => VOS.registerApp({
      id: kind, title, width: 900, height: 640, words, desktop: kind === 'doc',
      async open(w) {
        const list = el('div.fm-grid.small');
        const paint = async () => {
          const items = await B.call('fsRecent', kind).catch(() => []);
          list.textContent = '';
          if (!items.length) list.append(el('div.empty', { text: 'Документов этого типа пока нет. Нажмите «Создать новый».' }));
          items.forEach(e => list.append(el('button.fm-item', { title: e.name, onclick: () => openPath(e.path) },
            el('span.fm-ic', { html: VOS.appIcon(kind, 56) }), el('span.fm-name', { text: e.name }),
            el('span.fm-meta.muted', { text: new Date(e.mtime).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }) }))));
        };
        w.body.append(el('div.app-pad', null,
          el('div.doc-hero', null, el('span', { html: VOS.appIcon(kind, 72) }), el('div.grow', null, el('h2', { text: DOC_KINDS[kind][0] }),
            el('p.muted', { text: 'Файлы открываются и сохраняются в формате Microsoft Office — их можно отправить кому угодно.' })),
            el('button.btn.huge.primary', { text: '@plus', onclick: async () => { await createDoc(kind); paint(); } }, 'Создать новый')),
          el('h3', { text: 'Недавние' }), list,
          el('div.row', null, el('button.btn', { text: '@folder', onclick: () => VOS.wm.open('files', { root: 'docs' }) }, 'Все мои файлы'))));
        paint();
        w.onFocus = paint;
      }
    }));

  /* ---------- скачанные файлы ---------- */
  B.on('download', ev => {
    if (ev.state === 'started') { VOS.ui.toast('Скачиваю «' + ev.name + '»…', 2500); return; }
    if (ev.state !== 'completed') { VOS.ui.toast('Не удалось скачать «' + ev.name + '»', 4000); return; }
    const box = el('div.notice', null,
      el('span.notice-ic', { html: VOS.glyph('download') }),
      el('div.grow', null, el('b', { text: 'Файл скачан' }), el('div.muted', { text: ev.name + ' — в папке «Загрузки»' })),
      el('button.btn', { text: 'Открыть', onclick: () => { box.remove(); openPath(ev.path); } }),
      el('button.btn', { text: 'В папку', onclick: () => { box.remove(); VOS.wm.open('files', { root: 'downloads' }); } }),
      el('button.wb', { text: '@close', onclick: () => box.remove() }));
    document.body.append(box);
    setTimeout(() => box.remove(), 15000);
  });
})();
