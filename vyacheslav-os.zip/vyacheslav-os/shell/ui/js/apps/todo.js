/* Список дел: крупные галочки, можно надиктовать дело голосом. */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;

  VOS.registerApp({
    id: 'todo', title: 'Список дел', width: 780, height: 640,
    words: ['дела', 'список дел', 'задачи', 'дело', 'покупки', 'список'],
    async open(w) {
      let items = await VOS.store.get('todo', []);
      const list = el('div.list');
      const input = el('input.big-input.grow', { placeholder: 'Что нужно сделать? Например: купить хлеб' });
      const save = () => VOS.store.set('todo', items);
      function render() {
        list.textContent = '';
        const open = items.filter(i => !i.done), done = items.filter(i => i.done);
        if (!items.length) list.append(el('div.empty', { text: 'Дел нет — можно отдыхать' }));
        [...open, ...done].forEach(it => list.append(el('div.list-row.todo' + (it.done ? '.done' : ''), null,
          el('input.big-check', { type: 'checkbox', checked: it.done, onchange: e => { it.done = e.target.checked; if (it.done) VOS.sound.click(); save(); render(); } }),
          el('span.grow.todo-text', { text: it.text }),
          el('button.btn.small', { text: '🗑', title: 'Удалить', onclick: () => { items = items.filter(x => x !== it); save(); render(); } }))));
        counter.textContent = open.length ? 'Осталось: ' + open.length : (items.length ? 'Всё сделано!' : '');
      }
      const add = (text = input.value) => {
        text = String(text || '').trim(); if (!text) return;
        items.unshift({ id: VOS.uid(), text, done: false, created: Date.now() });
        input.value = ''; save(); render();
      };
      input.addEventListener('keydown', e => { if (e.key === 'Enter') add(); });
      const counter = el('b');
      w.body.append(el('div.app-pad', null,
        el('div.search-bar', null, input, el('button.btn.primary', { text: '➕ Добавить', onclick: () => add() }),
          el('button.btn', { text: '🎤', title: 'Сказать голосом', onclick: () => VOS.assistant.dictate(t => add(t)) })),
        el('div.toolbar', null, counter, el('span.spacer'), el('button.btn.small', { text: 'Убрать выполненные', onclick: () => { items = items.filter(i => !i.done); save(); render(); } })),
        list));
      render();
      setTimeout(() => input.focus(), 100);
    }
  });
})();
