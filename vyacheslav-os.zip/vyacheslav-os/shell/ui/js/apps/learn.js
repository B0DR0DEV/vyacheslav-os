/*
 * Обучение: экскурсия по экрану с подсветкой и уроки с упражнениями —
 * мышка, окна, клавиатура, голосовой помощник, безопасность.
 * Открыть: значок «Обучение» или «Василиса, научи пользоваться компьютером».
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /* ================= совет дня ================= */
  const TIPS = [
    () => 'Скажите «' + VOS.assistantName() + ', доброе утро» — и узнаете погоду, лекарства и новости на сегодня.',
    () => 'Чтобы позвонить внукам, скажите «' + VOS.assistantName() + ', позвони внуку».',
    () => 'Буквы мелкие? Настройки → Оформление → Размер текста.',
    () => 'Окно мешает? Нажмите чёрточку в его правом верхнем углу — оно спрячется вниз, на панель.',
    () => 'Никогда не говорите по телефону коды из СМС — так действуют мошенники.',
    () => 'Скажите «' + VOS.assistantName() + ', прочитай» на странице новостей — статья прозвучит вслух.',
    () => 'Если что-то не получается, скажите «' + VOS.assistantName() + ', помоги с компьютером» — родные подключатся и помогут.',
    () => 'Записать давление можно в «Дневнике давления» — там же виден график.',
    () => 'Скажите «' + VOS.assistantName() + ', сколько осталось таблеток» — я подскажу, что пора купить.',
    () => 'Чтобы найти любую программу, нажмите «Пуск» и начните печатать её название.',
    () => 'Иногда сохраняйте копию на флешку: Настройки → О системе → Резервная копия.',
    () => 'Радио играет, даже если свернуть его окно.',
    () => 'Скажите «' + VOS.assistantName() + ', включи радио Маяк».',
    () => 'Кнопка «Читать вслух» в окне сайта читает статью вашим помощником.',
    () => 'Скажите «' + VOS.assistantName() + ', разбуди меня в 7» — будильник заведётся сам.'
  ];
  VOS.tipOfDay = () => {
    const d = new Date(), day = Math.floor((d - new Date(d.getFullYear(), 0, 0)) / 864e5);
    return TIPS[day % TIPS.length]();
  };

  /* ================= экскурсия по экрану (подсветка) ================= */
  async function tour() {
    if (VOS.$('#tour')) return;
    VOS.wm.closeStart(); VOS.wm.closePopups();
    const name = VOS.assistantName();
    const steps = [
      { sel: '#desk-icons .dicon', title: 'Значки программ', text: 'Это ваши программы. Чтобы открыть — нажмите на значок один раз.' },
      { sel: '#start-btn', title: 'Кнопка «Пуск»', text: 'Здесь все программы, поиск и кнопка выключения компьютера.' },
      { sel: '#assist-btn', title: 'Помощник ' + name, text: 'Нажмите сюда или просто скажите «' + name + '» и вашу просьбу. Например: «' + name + ', какая погода?»' },
      { sel: '#task-list', title: 'Открытые окна', text: 'Здесь появляются значки открытых программ. Нажмите — и окно откроется снова.', pad: 40 },
      { sel: '#tray-wifi', title: 'Интернет', text: 'Значок интернета. Нажмите, чтобы подключиться к Wi-Fi.' },
      { sel: '#tray-vol', title: 'Громкость', text: 'Нажмите, чтобы сделать звук громче или тише.' },
      { sel: '#tray-clock', title: 'Часы', text: 'Время и дата. Нажмите — откроется календарь с праздниками.' },
      { sel: '#desk-widget', title: 'Сегодня', text: 'Большие часы, погода, ближайшее лекарство и совет дня.' },
      { sel: null, title: 'Вот и всё!', text: 'Если что-то забудете — откройте «Обучение» или скажите «' + name + ', научи пользоваться компьютером».' }
    ];
    const hole = el('div.tour-hole');
    const bubble = el('div.tour-bubble');
    const root = el('div#tour', null, hole, bubble);
    document.body.append(root);
    let i = 0, done = false;
    return new Promise(resolve => {
      const end = () => { if (done) return; done = true; VOS.stopSpeaking(); root.classList.add('closing'); setTimeout(() => root.remove(), 300); VOS.store.set('tourDone', true); resolve(); };
      function show() {
        const st = steps[i];
        const t = st.sel && VOS.$(st.sel);
        const pad = 10;
        let r = t ? t.getBoundingClientRect() : { left: innerWidth / 2, top: innerHeight / 2, width: 0, height: 0 };
        if (st.pad && t && r.width < 20) r = { left: r.left, top: r.top, width: st.pad * 4, height: r.height };
        Object.assign(hole.style, { left: (r.left - pad) + 'px', top: (r.top - pad) + 'px', width: (r.width + pad * 2) + 'px', height: (r.height + pad * 2) + 'px', borderRadius: t ? '1rem' : '50%' });
        bubble.textContent = '';
        bubble.append(el('div.tb-step', { text: (i + 1) + ' из ' + steps.length }), el('h2', { text: st.title }), el('p', { text: st.text }),
          el('div.tb-btns', null,
            i < steps.length - 1 ? el('button.btn', { text: 'Пропустить', onclick: end }) : null,
            el('button.btn.primary.big', { text: i < steps.length - 1 ? 'Дальше' : 'Понятно', onclick: () => { if (++i >= steps.length) end(); else show(); } })));
        // пузырь — над целью, если она внизу экрана, иначе под ней / рядом
        const bw = Math.min(420, innerWidth - 32);
        bubble.style.width = bw + 'px';
        requestAnimationFrame(() => {
          const bh = bubble.offsetHeight;
          let left = Math.min(Math.max(16, r.left + r.width / 2 - bw / 2), innerWidth - bw - 16);
          let top = r.top > innerHeight / 2 ? r.top - pad - bh - 18 : r.top + r.height + pad + 18;
          if (!t) { top = innerHeight / 2 - bh / 2; left = innerWidth / 2 - bw / 2; }
          if (t && st.sel === '#desk-widget') { left = r.left - bw - 24; top = r.top; }
          bubble.style.left = left + 'px'; bubble.style.top = Math.max(16, top) + 'px';
          bubble.classList.remove('in'); void bubble.offsetWidth; bubble.classList.add('in');
        });
        VOS.stopSpeaking(); VOS.speak(st.title + '. ' + st.text, { force: true });
      }
      root.addEventListener('keydown', e => { if (e.key === 'Escape') end(); });
      show();
    });
  }
  VOS.tour = tour;

  /* ================= уроки ================= */
  const LESSONS = [
    { id: 'tour', icon: 'grid', title: 'Что где на экране', desc: 'Короткая экскурсия с подсветкой', run: async () => { VOS.wm.closeAll(); await tour(); } },
    { id: 'mouse', icon: 'sparkle', title: 'Мышка и тачпад', desc: 'Упражнение: нажмите на кружки', run: (box, done) => mouseLesson(box, done) },
    { id: 'windows', icon: 'maximize', title: 'Окна', desc: 'Развернуть, свернуть и закрыть окно', run: (box, done) => windowsLesson(box, done) },
    { id: 'keys', icon: 'keyboard', title: 'Клавиатура', desc: 'Напечатайте несколько слов', run: (box, done) => keysLesson(box, done) },
    { id: 'voice', icon: 'mic', title: 'Голосовой помощник', desc: 'Что можно сказать помощнику', run: (box, done) => voiceLesson(box, done) },
    { id: 'safety', icon: 'lock', title: 'Осторожно, мошенники', desc: 'Пять правил безопасности', run: (box, done) => safetyLesson(box, done) }
  ];

  function praise() { const p = ['Отлично!', 'Молодец!', 'Здорово!', 'Хорошо получается!', 'Прекрасно!']; return p[Math.floor(Math.random() * p.length)]; }

  function mouseLesson(box, done) {
    const area = el('div.lm-area');
    const info = el('div.lm-info', { text: 'Нажмите на синий кружок' });
    box.append(el('p.ob-lead', { text: 'Двигайте пальцем по тачпаду (или мышкой) — стрелка на экране двигается. Чтобы нажать, коснитесь тачпада один раз или нажмите левую кнопку.' }), info, area);
    VOS.speak('Двигайте пальцем по тачпаду, и стрелка поедет. Наведите её на синий кружок и нажмите.', { force: true });
    let n = 0;
    const total = 6;
    function spawn() {
      area.textContent = '';
      if (n >= total) return dragPart();
      const size = Math.max(60, 120 - n * 10);
      const dot = el('button.lm-dot', { style: { width: size + 'px', height: size + 'px', left: (8 + Math.random() * 80) + '%', top: (10 + Math.random() * 70) + '%' } });
      dot.onclick = () => { n++; VOS.sound.click(); info.textContent = praise() + ' ' + n + ' из ' + total; dot.classList.add('pop'); setTimeout(spawn, 250); };
      area.append(dot);
    }
    function dragPart() {
      info.textContent = 'Теперь перетащите мяч в корзину: нажмите на мяч и, не отпуская, ведите.';
      VOS.speak('Теперь перетащим. Нажмите на мяч и, не отпуская, ведите его в корзину.', { force: true });
      const ball = el('div.lm-ball'), basket = el('div.lm-basket', { text: 'корзина' });
      area.append(basket, ball);
      let sx, sy, ox, oy, drag = false;
      ball.addEventListener('pointerdown', e => { drag = true; ball.setPointerCapture(e.pointerId); sx = e.clientX; sy = e.clientY; ox = ball.offsetLeft; oy = ball.offsetTop; });
      ball.addEventListener('pointermove', e => { if (!drag) return; ball.style.left = (ox + e.clientX - sx) + 'px'; ball.style.top = (oy + e.clientY - sy) + 'px'; });
      ball.addEventListener('pointerup', () => {
        drag = false;
        const a = ball.getBoundingClientRect(), b = basket.getBoundingClientRect();
        const cx = a.left + a.width / 2, cy = a.top + a.height / 2;
        if (cx > b.left && cx < b.right && cy > b.top && cy < b.bottom) {
          VOS.sound.win(); info.textContent = 'Урок пройден! Вы отлично управляетесь с мышкой.';
          VOS.speak('Урок пройден! Вы отлично управляетесь.', { force: true }); done();
        }
      });
    }
    spawn();
  }

  function windowsLesson(box, done) {
    const tasks = [
      { ev: 'maximize', text: 'Разверните окно «Учебное окно» на весь экран: нажмите квадратик в его правом верхнем углу.' },
      { ev: 'unmaximize', text: 'Теперь верните обычный размер — нажмите тот же значок ещё раз.' },
      { ev: 'minimize', text: 'Сверните окно: нажмите чёрточку. Окно спрячется вниз, на панель задач.' },
      { ev: 'restore', text: 'Найдите значок окна на панели внизу и нажмите на него — окно вернётся.' },
      { ev: 'close', text: 'И последнее: закройте окно крестиком.' }
    ];
    let k = 0;
    const list = el('ol.lw-list');
    tasks.forEach(t => list.append(el('li', { text: t.text })));
    const paint = () => list.querySelectorAll('li').forEach((li, i) => { li.className = i < k ? 'done' : i === k ? 'cur' : ''; });
    box.append(el('p.ob-lead', { text: 'Сейчас откроется учебное окно. Выполняйте задания по очереди — я подскажу.' }), list);
    paint();
    const pw = VOS.wm.open('practice');
    // ставим учебное окно справа внизу, чтобы задания слева были видны
    if (pw) { const A = VOS.$('#windows').getBoundingClientRect(); pw.el.style.left = Math.max(0, A.width - pw.el.offsetWidth - 24) + 'px'; pw.el.style.top = Math.max(0, A.height - pw.el.offsetHeight - 24) + 'px'; }
    const say = () => VOS.speak(tasks[k].text, { force: true });
    say();
    const h = ({ type, w }) => {
      if (k >= tasks.length || w.app.id !== 'practice' || type !== tasks[k].ev) return;
      k++; paint(); VOS.sound.click();
      if (k >= tasks.length) { VOS.sound.win(); VOS.speak('Отлично! Теперь вы умеете обращаться с окнами.', { force: true }); done(); off(); }
      else say();
    };
    VOS.on('wm', h);
    const off = () => VOS.off('wm', h);
    return () => { off(); if (pw && VOS.wm.list().includes(pw)) VOS.wm.close(pw); };
  }
  VOS.registerApp({
    id: 'practice', title: 'Учебное окно', hidden: true, desktop: false, width: 500, height: 330, single: true,
    open(w) { w.body.append(el('div.app-pad.lw-practice', null, el('div.lw-big', { html: VOS.glyph('sparkle') }), el('h2', { text: 'Это учебное окно' }), el('p.muted', { text: 'Кнопки управления окном — вверху справа: чёрточка, квадратик и крестик.' }))); }
  });

  function keysLesson(box, done) {
    const words = ['дом', 'мама', 'внук', 'чай', 'привет', 'Москва'];
    let k = 0;
    const target = el('div.lk-word');
    const input = el('input.big-input.lk-input', { autocomplete: 'off', spellcheck: false });
    const hint = el('div.muted.lk-tip');
    box.append(el('p.ob-lead', { text: 'Напечатайте слово, которое показано крупно, и нажмите большую клавишу Enter. Ошиблись — клавиша Backspace (стрелка влево вверху) стирает букву.' }),
      target, input, hint,
      el('div.lk-keys', null, el('span.kbd', { text: 'Shift' }), el('span', { text: '— большая буква (держите и нажмите букву)' }), el('span.kbd', { text: 'Alt + Shift' }), el('span', { text: '— русские / английские буквы' })));
    const show = () => { target.textContent = words[k]; input.value = ''; hint.textContent = (k + 1) + ' из ' + words.length; input.focus(); };
    input.addEventListener('input', () => {
      if (/[a-z]/i.test(input.value)) hint.textContent = 'Печатаются английские буквы. Нажмите одновременно Alt и Shift, чтобы включить русские.';
    });
    input.addEventListener('keydown', e => {
      if (e.key !== 'Enter') return;
      if (input.value.trim() === words[k]) {
        VOS.sound.click(); k++;
        if (k >= words.length) { target.textContent = '✓'; hint.textContent = 'Урок пройден!'; VOS.sound.win(); VOS.speak('Урок пройден! ' + praise(), { force: true }); done(); return; }
        hint.textContent = praise(); setTimeout(show, 500);
      } else { hint.textContent = 'Почти! Проверьте буквы. ' + (words[k] !== words[k].toLowerCase() ? 'Первая буква — большая (Shift).' : ''); VOS.sound.error(); }
    });
    VOS.speak('Напечатайте слово, которое показано крупно, и нажмите клавишу Enter.', { force: true });
    show();
  }

  function voiceLesson(box, done) {
    const name = VOS.assistantName();
    const ex = ['Который час?', 'Какая погода?', 'Доброе утро', 'Сколько осталось таблеток?', 'Расскажи новости', 'Кто такой Пушкин?'];
    box.append(el('p.ob-lead', { text: 'Помощник слушает всё время. Скажите громко и чётко его имя — «' + name + '» — и сразу вашу просьбу. Внизу экрана появится окошко с ответом.' }),
      el('div.lv-list', null, ex.map(q => el('div.lv-row', null, el('span.lv-q', { text: '«' + name + ', ' + q.charAt(0).toLowerCase() + q.slice(1) + '»' }),
        el('button.btn', { text: '@play', onclick: () => VOS.assistant.handle(q) }, 'Попробовать')))),
      el('p.muted', { text: 'Кнопка «Попробовать» показывает, что будет. А теперь скажите сами!' }),
      el('div.row', null, el('button.btn.primary.big', { text: '@mic', onclick: () => VOS.assistant.listen() }, 'Сказать сейчас'), el('button.btn.big', { text: '@check', onclick: done }, 'Понятно')));
    VOS.speak('Чтобы спросить помощника, скажите громко его имя, ' + name + ', и сразу вашу просьбу. Например: ' + name + ', который час?', { force: true });
  }

  function safetyLesson(box, done) {
    const rules = [
      ['phone', 'Никому не называйте коды из СМС', 'Ни «банку», ни «полиции», ни «Госуслугам». Настоящие сотрудники коды никогда не спрашивают.'],
      ['warning', '«Ваш родственник попал в беду»', 'Положите трубку и сами перезвоните родственнику по его обычному номеру.'],
      ['lock', 'Не переводите деньги незнакомым', 'Даже если очень торопят. Спокойно посоветуйтесь с родными.'],
      ['globe', 'Не вводите данные карты на сайтах', 'Если сайт просит номер карты или пароль — закройте его и спросите внуков.'],
      ['help', 'Сомневаетесь — спросите', 'Скажите «' + VOS.assistantName() + ', помоги с компьютером» или позвоните родным.']
    ];
    box.append(el('div.ls-list', null, rules.map(([g, t, d]) => el('div.ls-row', null, VOS.gl(g), el('div', null, el('b', { text: t }), el('div.muted', { text: d }))))),
      el('div.row', null, el('button.btn.primary.big', { text: '🔊 Прочитать вслух', onclick: () => VOS.speak(rules.map(r => r[1] + '. ' + r[2]).join(' '), { force: true }) }), el('button.btn.big', { text: '@check', onclick: done }, 'Я запомнил')));
  }

  VOS.registerApp({
    id: 'learn', title: 'Обучение', width: 980, height: 690,
    words: ['обучение', 'научи', 'как пользоваться', 'уроки', 'учиться', 'экскурсия'],
    async open(w) {
      let doneSet = new Set(await VOS.store.get('learnDone', []));
      const grid = el('div.ln-grid');
      const lessonBox = el('div.ln-lesson.hidden');
      let cleanup = null;
      const markDone = async id => { doneSet.add(id); await VOS.store.set('learnDone', [...doneSet]); };
      function list() {
        if (cleanup) { cleanup(); cleanup = null; }
        lessonBox.classList.add('hidden'); grid.classList.remove('hidden'); grid.textContent = '';
        w.setTitle('');
        LESSONS.forEach((L, i) => grid.append(el('button.ln-card' + (doneSet.has(L.id) ? '.done' : ''), { style: { animationDelay: i * 50 + 'ms' }, onclick: () => open(L) },
          el('div.ln-ic', { html: VOS.glyph(L.icon) }), el('div.ln-t', null, el('b', { text: L.title }), el('div.muted', { text: L.desc })),
          doneSet.has(L.id) ? el('span.ln-check', { html: VOS.glyph('check') }) : null)));
      }
      async function open(L) {
        if (L.id === 'tour') { VOS.wm.minimize(w); await L.run(); await markDone('tour'); VOS.wm.focus(w); list(); return; }
        grid.classList.add('hidden'); lessonBox.classList.remove('hidden'); lessonBox.textContent = '';
        w.setTitle(L.title);
        const body = el('div.ln-body');
        lessonBox.append(el('div.toolbar', null, el('button.btn', { text: '@back', onclick: list }, 'Все уроки'), el('h2', { text: L.title })), body);
        cleanup = L.run(body, () => markDone(L.id)) || null;
        if (typeof cleanup !== 'function') cleanup = null;
      }
      w.body.append(el('div.app-pad', null,
        el('div.ln-head', null, el('h1', { text: 'Учимся пользоваться компьютером' }), el('p.muted', { text: 'Выберите урок. Проходить можно сколько угодно раз.' })),
        grid, lessonBox));
      list();
      return () => { if (cleanup) cleanup(); };
    }
  });
})();
