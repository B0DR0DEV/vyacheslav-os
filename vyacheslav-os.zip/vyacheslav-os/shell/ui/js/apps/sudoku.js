/*
 * Судоку: генератор с единственным решением, три уровня сложности,
 * крупные клетки и цифры, подсветка ошибок, подсказка, сохранение партии.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;

  function solveCount(g, limit = 2) {
    let count = 0;
    const ok = (i, v) => {
      const r = Math.floor(i / 9), c = i % 9, br = r - r % 3, bc = c - c % 3;
      for (let k = 0; k < 9; k++) {
        if (g[r * 9 + k] === v || g[k * 9 + c] === v) return false;
        if (g[(br + Math.floor(k / 3)) * 9 + bc + k % 3] === v) return false;
      }
      return true;
    };
    (function rec() {
      if (count >= limit) return;
      // клетка с наименьшим числом вариантов — сильно ускоряет перебор
      let best = -1, bestOpts = null;
      for (let i = 0; i < 81; i++) if (!g[i]) {
        const opts = []; for (let v = 1; v <= 9; v++) if (ok(i, v)) opts.push(v);
        if (!bestOpts || opts.length < bestOpts.length) { best = i; bestOpts = opts; if (opts.length <= 1) break; }
      }
      if (best < 0) { count++; return; }
      for (const v of bestOpts) { g[best] = v; rec(); g[best] = 0; if (count >= limit) return; }
    })();
    return count;
  }
  function fullGrid() {
    const g = new Array(81).fill(0);
    const ok = (i, v) => {
      const r = Math.floor(i / 9), c = i % 9, br = r - r % 3, bc = c - c % 3;
      for (let k = 0; k < 9; k++) if (g[r * 9 + k] === v || g[k * 9 + c] === v || g[(br + Math.floor(k / 3)) * 9 + bc + k % 3] === v) return false;
      return true;
    };
    (function rec(i) {
      if (i === 81) return true;
      const vals = [1, 2, 3, 4, 5, 6, 7, 8, 9].sort(() => Math.random() - 0.5);
      for (const v of vals) if (ok(i, v)) { g[i] = v; if (rec(i + 1)) return true; g[i] = 0; }
      return false;
    })(0);
    return g;
  }
  function generate(holes) {
    const sol = fullGrid(), puz = sol.slice();
    const order = [...Array(81).keys()].sort(() => Math.random() - 0.5);
    let removed = 0;
    for (const i of order) {
      if (removed >= holes) break;
      const keep = puz[i]; puz[i] = 0;
      if (solveCount(puz.slice()) !== 1) puz[i] = keep; else removed++;
    }
    return { sol, puz };
  }
  const LEVELS = { easy: { name: 'Лёгкий', holes: 36 }, medium: { name: 'Средний', holes: 46 }, hard: { name: 'Сложный', holes: 52 } };

  VOS.registerApp({
    id: 'sudoku', title: 'Судоку', width: 900, height: 720, maximized: false,
    words: ['судоку', 'головоломку', 'головоломка', 'цифры'],
    async open(w) {
      let game = await VOS.store.get('sudoku', null);
      let sel = -1;
      const board = el('div.sdk-board');
      const status = el('div.sdk-status');
      const save = VOS.debounce(() => VOS.store.set('sudoku', game), 500);
      function start(level) {
        const { sol, puz } = generate(LEVELS[level].holes);
        game = { level, sol, given: puz.map(v => v > 0), cur: puz.slice(), mistakes: 0, done: false };
        sel = -1; save(); render();
      }
      function render() {
        board.textContent = '';
        const sv = sel >= 0 ? game.cur[sel] : 0;
        for (let i = 0; i < 81; i++) {
          const r = Math.floor(i / 9), c = i % 9;
          const same = sel >= 0 && (Math.floor(sel / 9) === r || sel % 9 === c || (Math.floor(Math.floor(sel / 9) / 3) === Math.floor(r / 3) && Math.floor((sel % 9) / 3) === Math.floor(c / 3)));
          const v = game.cur[i];
          const wrong = v && !game.given[i] && v !== game.sol[i];
          const cell = el('button.sdk-cell' + (game.given[i] ? '.given' : '') + (i === sel ? '.sel' : '') + (same ? '.near' : '') + (v && sv && v === sv ? '.samev' : '') + (wrong ? '.wrong' : '') +
            (c % 3 === 2 && c < 8 ? '.br' : '') + (r % 3 === 2 && r < 8 ? '.bb' : ''), { text: v || '', onclick: () => { sel = i; render(); } });
          board.append(cell);
        }
        const left = game.cur.filter((v, i) => v !== game.sol[i]).length;
        status.textContent = LEVELS[game.level].name + ' уровень · осталось клеток: ' + left + (game.mistakes ? ' · ошибок: ' + game.mistakes : '');
      }
      function put(v) {
        if (sel < 0 || game.given[sel] || game.done) return;
        game.cur[sel] = v;
        if (v && v !== game.sol[sel]) { game.mistakes++; VOS.sound.error(); }
        save(); render();
        if (game.cur.every((x, i) => x === game.sol[i])) {
          game.done = true; save(); VOS.sound.win();
          VOS.ui.dialog({ icon: '🏆', title: 'Решено!', text: 'Отличная работа! Сыграем ещё?', buttons: [{ label: 'Закрыть', value: false }, { label: 'Новая игра', value: true, primary: true }] })
            .then(y => { if (y) start(game.level); });
        }
      }
      function hint() {
        let i = sel >= 0 && !game.given[sel] && game.cur[sel] !== game.sol[sel] ? sel : -1;
        if (i < 0) { const empty = game.cur.map((v, k) => v !== game.sol[k] ? k : -1).filter(k => k >= 0); if (!empty.length) return; i = empty[Math.floor(Math.random() * empty.length)]; }
        sel = i; put(game.sol[i]);
      }
      const pad = el('div.sdk-pad');
      for (let v = 1; v <= 9; v++) pad.append(el('button.sdk-num', { text: v, onclick: () => put(v) }));
      pad.append(el('button.sdk-num.erase', { text: '⌫', title: 'Стереть', onclick: () => put(0) }));
      const onKey = e => {
        if (!w.el.classList.contains('active')) return;
        if (/^[1-9]$/.test(e.key)) put(+e.key);
        else if (e.key === 'Backspace' || e.key === 'Delete' || e.key === '0') put(0);
        else if (e.key.startsWith('Arrow') && sel >= 0) {
          const d = { ArrowUp: -9, ArrowDown: 9, ArrowLeft: -1, ArrowRight: 1 }[e.key];
          sel = (sel + d + 81) % 81; render();
        } else return;
        e.preventDefault();
      };
      document.addEventListener('keydown', onKey);
      const levelBtns = Object.entries(LEVELS).map(([k, l]) => el('button.btn', { text: l.name, onclick: async () => {
        if (game && !game.done && game.cur.some((v, i) => v && !game.given[i]) && !(await VOS.ui.confirm({ title: 'Начать новую игру?', text: 'Текущая партия пропадёт.', yes: 'Новая игра' }))) return;
        start(k);
      } }));
      w.body.append(el('div.sdk', null,
        el('div.toolbar', null, el('b', { text: 'Новая игра:' }), ...levelBtns, el('span.spacer'), el('button.btn', { text: '💡 Подсказка', onclick: hint })),
        el('div.sdk-main', null, board, el('div.sdk-side', null, pad, status,
          el('p.muted.small', { text: 'Выберите клетку, затем нажмите цифру. В каждой строке, столбце и квадрате 3×3 цифры от 1 до 9 не повторяются.' })))));
      if (!game || !game.sol) start('easy'); else render();
      return () => document.removeEventListener('keydown', onKey);
    }
  });
})();
