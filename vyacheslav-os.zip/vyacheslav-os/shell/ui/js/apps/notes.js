/* Заметки: список слева, текст справа, сохраняется сам. Можно надиктовать голосом и прослушать. */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;

  VOS.registerApp({
    id: 'notes', title: 'Заметки', width: 980, height: 640,
    words: ['заметки', 'заметку', 'записи', 'запись', 'блокнот'],
    async open(w) {
      let notes = await VOS.store.get('notes', []);
      let cur = null;
      const list = el('div.notes-list');
      const area = el('textarea.notes-text', { placeholder: 'Пишите здесь. Всё сохраняется само.' });
      const info = el('div.muted.small', { text: '' });
      const save = VOS.debounce(async () => { await VOS.store.set('notes', notes); info.textContent = 'Сохранено ✓'; }, 600);
      const titleOf = n => (n.text.trim().split('\n')[0] || 'Новая заметка').slice(0, 40);

      function render() {
        list.textContent = '';
        notes.sort((a, b) => b.updated - a.updated);
        notes.forEach(n => list.append(el('button.note-item' + (n === cur ? '.on' : ''), { onclick: () => select(n) },
          el('b', { text: titleOf(n) }), el('span.muted.small', { text: new Date(n.updated).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) }))));
        if (!notes.length) list.append(el('div.muted', { text: 'Заметок пока нет' }));
      }
      function select(n) { cur = n; area.value = n ? n.text : ''; area.disabled = !n; render(); if (n) area.focus(); }
      function add(text = '') { const n = { id: VOS.uid(), text, updated: Date.now() }; notes.unshift(n); select(n); save(); }
      area.addEventListener('input', () => { if (!cur) return; cur.text = area.value; cur.updated = Date.now(); info.textContent = 'Сохраняю…'; save(); render(); });

      const tools = el('div.toolbar', null,
        el('button.btn.primary', { text: '➕ Новая', onclick: () => add() }),
        el('button.btn', { text: '🎤 Надиктовать', onclick: () => VOS.assistant.dictate(t => {
          if (!cur) add(t); else { area.value += (area.value && !/\s$/.test(area.value) ? ' ' : '') + t; area.dispatchEvent(new Event('input')); }
        }) }),
        el('button.btn', { text: '🔊 Прочитать', onclick: () => cur && VOS.speak(cur.text, { force: true }) }),
        el('button.btn', { text: '🅰 Крупнее', onclick: () => { area.style.fontSize = (parseFloat(getComputedStyle(area).fontSize) + 3) + 'px'; } }),
        el('span.spacer'),
        el('button.btn.danger', { text: '🗑 Удалить', onclick: async () => {
          if (!cur) return;
          if (await VOS.ui.confirm({ title: 'Удалить заметку?', text: '«' + titleOf(cur) + '»', yes: 'Удалить', danger: true })) {
            notes = notes.filter(n => n !== cur); await VOS.store.set('notes', notes); select(notes[0] || null);
          }
        } }));
      w.body.append(el('div.notes', null, list, el('div.notes-main', null, tools, area, info)));
      if (notes.length) select(notes[0]); else { render(); area.disabled = true; }
    }
  });
})();
