/*
 * Лекарства: список лекарств с временем приёма. В нужное время
 * появляется большое окно со звуком, и голос говорит, что пора принять.
 * Отметки «принял» хранятся по дням — видно, что уже выпито сегодня.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;

  VOS.meds = {
    async all() { return VOS.store.get('meds', []); },
    async log() { return VOS.store.get('medlog', {}); },
    async mark(medId, time, status) {
      const log = await VOS.meds.log();
      const day = VOS.dateKey(new Date());
      log[day] = log[day] || {};
      log[day][medId + '@' + time] = { status, at: Date.now() };
      // храним только последние 60 дней
      const keys = Object.keys(log).sort(); while (keys.length > 60) delete log[keys.shift()];
      await VOS.store.set('medlog', log);
      // запас таблеток: при «Принял» уменьшаем остаток
      if (status === 'taken') {
        const meds = await VOS.meds.all();
        const m = meds.find(x => x.id === medId);
        if (m && typeof m.stock === 'number') { m.stock = Math.max(0, m.stock - (Number(m.perDose) || 1)); await VOS.store.set('meds', meds); }
      }
      VOS.emit('meds');
    },
    // на сколько дней хватит запаса
    daysLeft(m) {
      if (typeof m.stock !== 'number') return null;
      const perDay = (Number(m.perDose) || 1) * Math.max(1, m.times.length);
      return Math.floor(m.stock / perDay);
    },
    async low(limit = 5) {
      return (await VOS.meds.all()).filter(m => m.enabled !== false && VOS.meds.daysLeft(m) !== null && VOS.meds.daysLeft(m) <= limit);
    },
    async stockReply() {
      const meds = (await VOS.meds.all()).filter(m => m.enabled !== false);
      const known = meds.filter(m => VOS.meds.daysLeft(m) !== null);
      if (!meds.length) return { say: 'Лекарств в списке пока нет.' };
      if (!known.length) return { say: 'Запас лекарств пока не записан. Откройте «Лекарства» и укажите, сколько таблеток в упаковке.' };
      const parts = known.sort((a, b) => VOS.meds.daysLeft(a) - VOS.meds.daysLeft(b)).map(m => {
        const d = VOS.meds.daysLeft(m);
        return m.name + ': ' + m.stock + ' ' + VOS.plural(m.stock, 'штука', 'штуки', 'штук') + ', хватит на ' + d + ' ' + VOS.plural(d, 'день', 'дня', 'дней') + (d <= 5 ? ' — пора купить' : '');
      });
      return { say: parts.join('. ') + '.' };
    }
  };

  function timeInputs(times) {
    const box = el('div.times');
    const add = (v = '09:00') => {
      const row = el('div.time-row', null, el('input.big-input.time', { type: 'time', value: v }), el('button.btn.small', { text: '✕', onclick: () => row.remove() }));
      box.append(row);
    };
    (times.length ? times : ['09:00']).forEach(add);
    return { box, add, values: () => [...box.querySelectorAll('input')].map(i => i.value).filter(Boolean).sort() };
  }

  async function editDialog(med) {
    const m = med || { id: VOS.uid(), name: '', dose: '', times: ['09:00'], note: '', enabled: true, perDose: 1 };
    const name = el('input.big-input', { value: m.name, placeholder: 'Название, например: Аспирин' });
    const dose = el('input.big-input', { value: m.dose, placeholder: 'Сколько, например: 1 таблетка' });
    const note = el('input.big-input', { value: m.note, placeholder: 'Примечание, например: после еды' });
    const ti = timeInputs(m.times);
    const stock = el('input.big-input.num', { type: 'number', min: 0, max: 2000, value: typeof m.stock === 'number' ? m.stock : '', placeholder: '30' });
    const per = el('input.big-input.num', { type: 'number', min: 0.25, max: 20, step: 0.25, value: m.perDose || 1 });
    const body = el('div.form', null,
      el('label', { text: 'Лекарство' }), name, el('label', { text: 'Доза' }), dose,
      el('label', { text: 'Время приёма' }), ti.box, el('button.btn.small', { text: '➕ Ещё время', onclick: () => ti.add('14:00') }),
      el('label', { text: 'Примечание' }), note,
      el('label', { text: 'Запас: сколько таблеток сейчас есть и сколько за один приём' }),
      el('div.row', null, stock, el('span', { text: 'шт.,  по' }), per, el('span', { text: 'за приём' })),
      el('div.muted.small', { text: 'Если указать запас, компьютер заранее напомнит купить лекарство. Можно оставить пустым.' }));
    const ok = await VOS.ui.dialog({ icon: '💊', title: med ? 'Изменить лекарство' : 'Новое лекарство', body,
      buttons: [{ label: 'Отмена', value: false }, { label: 'Сохранить', value: true, primary: true }] });
    if (!ok) return null;
    if (!name.value.trim()) { VOS.ui.toast('Напишите название лекарства'); return null; }
    const st = stock.value === '' ? undefined : Math.max(0, Number(stock.value));
    return { ...m, name: name.value.trim(), dose: dose.value.trim(), note: note.value.trim(), times: ti.values(), stock: st, perDose: Number(per.value) || 1 };
  }

  VOS.registerApp({
    id: 'meds', title: 'Лекарства', width: 920, height: 660,
    words: ['лекарства', 'лекарство', 'таблетки', 'таблетку', 'напоминания', 'аптечка'],
    open(w) {
      const today = el('div.list');
      const all = el('div.list');
      async function render() {
        const meds = await VOS.meds.all();
        const log = (await VOS.meds.log())[VOS.dateKey(new Date())] || {};
        const now = VOS.fmtTime(new Date());
        today.textContent = ''; all.textContent = '';
        const doses = [];
        meds.filter(m => m.enabled !== false).forEach(m => m.times.forEach(t => doses.push({ m, t })));
        doses.sort((a, b) => a.t.localeCompare(b.t));
        if (!doses.length) today.append(el('div.empty', { text: 'Лекарств пока нет. Нажмите «Добавить лекарство».' }));
        doses.forEach(({ m, t }) => {
          const st = log[m.id + '@' + t];
          const status = st ? (st.status === 'taken' ? 'Принято' : 'Пропущено') : (t < now ? 'Не отмечено' : 'Ожидает');
          const stCls = st ? (st.status === 'taken' ? 'ok' : 'muted') : (t < now ? 'warn' : 'wait');
          today.append(el('div.list-row.med' + (st && st.status === 'taken' ? '.done' : ''), null,
            el('span.med-time', { text: t }),
            el('span.grow', null, el('b', { text: m.name }), ' ', el('span.muted', { text: [m.dose, m.note].filter(Boolean).join(', ') })),
            el('span.status-chip.' + stCls, { text: status }),
            !st ? el('button.btn.primary.small', { text: 'Принял', onclick: async () => { await VOS.meds.mark(m.id, t, 'taken'); render(); } }) : null));
        });
        const lowList = meds.filter(m => m.enabled !== false && VOS.meds.daysLeft(m) !== null && VOS.meds.daysLeft(m) <= 5);
        warn.textContent = '';
        if (lowList.length) warn.append(VOS.gl('warning'), el('span', { text: 'Пора купить: ' + lowList.map(m => m.name + ' (на ' + VOS.meds.daysLeft(m) + ' ' + VOS.plural(VOS.meds.daysLeft(m), 'день', 'дня', 'дней') + ')').join(', ') }));
        warn.hidden = !lowList.length;
        meds.forEach(m => all.append(el('div.list-row', null,
          el('span.grow', null, el('b', { text: m.name }), ' ', el('span.muted', { text: (m.dose || '') + ' · ' + m.times.join(', ') }),
            VOS.meds.daysLeft(m) !== null ? el('div.small' + (VOS.meds.daysLeft(m) <= 5 ? '.low' : '.muted'), { text: 'Осталось ' + m.stock + ' шт. — на ' + VOS.meds.daysLeft(m) + ' ' + VOS.plural(VOS.meds.daysLeft(m), 'день', 'дня', 'дней') }) : null),
          el('button.btn.small', { text: '➕ Купил', title: 'Добавить упаковку', onclick: async () => {
            const n = await VOS.ui.prompt({ title: 'Сколько таблеток в новой упаковке?', type: 'number', value: '30' });
            if (!n || !(Number(n) > 0)) return;
            m.stock = (typeof m.stock === 'number' ? m.stock : 0) + Number(n); await VOS.store.set('meds', meds); render();
          } }),
          el('label.check', null, el('input', { type: 'checkbox', checked: m.enabled !== false, onchange: async e => { m.enabled = e.target.checked; await VOS.store.set('meds', meds); render(); } }), ' напоминать'),
          el('button.btn.small', { text: '✏️', title: 'Изменить', onclick: async () => { const r = await editDialog(m); if (r) { Object.assign(m, r); await VOS.store.set('meds', meds); render(); } } }),
          el('button.btn.small.danger', { text: '🗑', title: 'Удалить', onclick: async () => {
            if (await VOS.ui.confirm({ title: 'Удалить «' + m.name + '»?', yes: 'Удалить', danger: true })) { await VOS.store.set('meds', meds.filter(x => x !== m)); render(); }
          } }))));
      }
      const warn = el('div.med-warn', { hidden: true });
      w.body.append(el('div.app-pad', null,
        warn,
        el('div.toolbar', null, el('h2', { text: 'Сегодня, ' + VOS.fmtDate(new Date()) }), el('span.spacer'),
          el('button.btn.primary', { text: '➕ Добавить лекарство', onclick: async () => { const r = await editDialog(); if (r) { const meds = await VOS.meds.all(); meds.push(r); await VOS.store.set('meds', meds); render(); VOS.ui.toast('Напомню в ' + r.times.join(', ')); } } })),
        today, el('h3', { text: 'Все лекарства' }), all,
        el('p.muted', { text: 'В нужное время появится большое окно со звуком и голосом. Компьютер должен быть включён.' })));
      render();
      VOS.on('meds', () => { if (document.body.contains(w.el)) render(); });
    }
  });
})();
