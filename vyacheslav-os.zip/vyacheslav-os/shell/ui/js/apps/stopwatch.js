/* Секундомер (с кругами) и таймер обратного отсчёта (например, для варки яиц). */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;
  const fmt = ms => { const t = Math.floor(ms / 10), cs = t % 100, s = Math.floor(t / 100) % 60, m = Math.floor(t / 6000) % 60, h = Math.floor(t / 360000);
    return (h ? h + ':' + VOS.pad(m) : VOS.pad(m)) + ':' + VOS.pad(s) + ',' + VOS.pad(cs); };
  const fmtS = sec => Math.floor(sec / 60) + ':' + VOS.pad(sec % 60);

  VOS.registerApp({
    id: 'stopwatch', title: 'Секундомер', desktop: false, width: 760, height: 600,
    words: ['секундомер', 'таймер', 'засеки', 'засечь'],
    open(w, args) {
      /* секундомер */
      let run = false, base = 0, startAt = 0, laps = [];
      const disp = el('div.sw-display', { text: fmt(0) });
      const lapBox = el('div.list');
      const startBtn = el('button.btn.huge.primary', { text: '▶ Старт' });
      const lapBtn = el('button.btn.huge', { text: '🏁 Круг', disabled: true });
      const elapsed = () => base + (run ? Date.now() - startAt : 0);
      startBtn.onclick = () => {
        if (run) { base = elapsed(); run = false; VOS.setBtn(startBtn, '▶ Продолжить'); VOS.setBtn(lapBtn, '↺ Сброс'); }
        else { startAt = Date.now(); run = true; VOS.setBtn(startBtn, '⏸ Стоп'); VOS.setBtn(lapBtn, '🏁 Круг'); lapBtn.disabled = false; }
      };
      lapBtn.onclick = () => {
        if (run) { laps.unshift(elapsed()); lapBox.prepend(el('div.list-row', null, el('b', { text: 'Круг ' + laps.length }), el('span.grow'), el('span.mono', { text: fmt(laps[0]) }))); }
        else { base = 0; laps = []; lapBox.textContent = ''; disp.textContent = fmt(0); lapBtn.disabled = true; VOS.setBtn(lapBtn, '🏁 Круг'); VOS.setBtn(startBtn, '▶ Старт'); }
      };
      /* таймер */
      let tLeft = 0, tEnd = 0, tRun = false, stopSound = null;
      const tDisp = el('div.sw-display', { text: '0:00' });
      const minIn = el('input.big-input.num', { type: 'number', min: 0, max: 600, value: 5 });
      const tBtn = el('button.btn.huge.primary', { text: '▶ Запустить' });
      const setT = sec => { tLeft = sec; tDisp.textContent = fmtS(sec); };
      tBtn.onclick = () => {
        if (stopSound) { stopSound(); stopSound = null; VOS.setBtn(tBtn, '▶ Запустить'); return; }
        if (tRun) { tRun = false; tLeft = Math.max(0, Math.round((tEnd - Date.now()) / 1000)); VOS.setBtn(tBtn, '▶ Продолжить'); return; }
        if (!tLeft) setT(Math.round((+minIn.value || 0) * 60));
        if (!tLeft) return;
        tEnd = Date.now() + tLeft * 1000; tRun = true; VOS.setBtn(tBtn, '⏸ Пауза');
      };
      const presets = el('div.row', null, [1, 3, 5, 10, 15, 30].map(m => el('button.btn', { text: m + ' мин', onclick: () => { tRun = false; minIn.value = m; setT(m * 60); VOS.setBtn(tBtn, '▶ Запустить'); } })));

      const iv = setInterval(() => {
        if (run) disp.textContent = fmt(elapsed());
        if (tRun) {
          const left = Math.max(0, Math.ceil((tEnd - Date.now()) / 1000)); tDisp.textContent = fmtS(left);
          if (left === 0) {
            tRun = false; tLeft = 0; VOS.setBtn(tBtn, '🔕 Выключить звонок');
            stopSound = VOS.sound.loop('alarm'); B_wake();
            VOS.speak('Время вышло!', { force: true });
            setTimeout(() => { if (stopSound) { stopSound(); stopSound = null; VOS.setBtn(tBtn, '▶ Запустить'); } }, 60000);
          }
        }
      }, 50);
      const B_wake = () => VOS.backend.call('screenWake').catch(() => {});

      const tabs = el('div.chip-bar');
      const swPane = el('div.sw-pane', null, disp, el('div.row.center', null, startBtn, lapBtn), lapBox);
      const tPane = el('div.sw-pane.hidden', null, tDisp, el('div.row.center', null, el('label', null, 'Минут: ', minIn), tBtn), presets);
      const tab = (name, pane) => el('button.chip', { text: name, onclick: e => { tabs.querySelectorAll('.chip').forEach(c => c.classList.remove('on')); e.target.classList.add('on'); swPane.classList.toggle('hidden', pane !== swPane); tPane.classList.toggle('hidden', pane !== tPane); } });
      const t1 = tab('⏱ Секундомер', swPane), t2 = tab('⏲ Таймер', tPane);
      tabs.append(t1, t2);
      w.body.append(el('div.app-pad', null, tabs, swPane, tPane));
      if (args.timer) { t2.click(); } else t1.classList.add('on');
      return () => { clearInterval(iv); if (stopSound) stopSound(); };
    }
  });
})();
