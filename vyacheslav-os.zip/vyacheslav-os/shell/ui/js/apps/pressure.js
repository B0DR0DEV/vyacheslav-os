/*
 * Дневник давления: ввод верхнего/нижнего давления и пульса, таблица
 * и график с цветными зонами. Оценка — по общепринятым порогам
 * (норма до 130/85, высокое от 140/90), это подсказка, а не диагноз.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;
  const NS = 'http://www.w3.org/2000/svg';
  const svgEl = (t, a) => { const e = document.createElementNS(NS, t); for (const k in a) e.setAttribute(k, a[k]); return e; };

  function classify(s, d) {
    if (s >= 180 || d >= 110) return { t: 'Очень высокое', c: 'bad', say: 'Давление очень высокое. Если плохо себя чувствуете, позвоните врачу или по номеру 103.' };
    if (s >= 140 || d >= 90) return { t: 'Повышенное', c: 'bad', say: 'Давление повышенное.' };
    if (s >= 130 || d >= 85) return { t: 'Выше нормы', c: 'warn', say: 'Давление немного выше нормы.' };
    if (s < 90 || d < 60) return { t: 'Пониженное', c: 'warn', say: 'Давление пониженное.' };
    return { t: 'Норма', c: 'ok', say: 'Давление в норме.' };
  }

  function chart(items, width, height) {
    const svg = svgEl('svg', { viewBox: `0 0 ${width} ${height}`, class: 'bp-chart', role: 'img' });
    const pts = items.slice(-30);
    if (pts.length < 2) { const t = svgEl('text', { x: width / 2, y: height / 2, 'text-anchor': 'middle', class: 'bp-empty' }); t.textContent = 'График появится после двух измерений'; svg.append(t); return svg; }
    const padL = 54, padR = 34, padT = 16, padB = 46;
    const vals = pts.flatMap(p => [p.sys, p.dia, p.pulse || p.dia]);
    const lo = Math.min(50, ...vals) - 5, hi = Math.max(170, ...vals) + 5;
    const x = i => padL + i * (width - padL - padR) / (pts.length - 1);
    const y = v => padT + (hi - v) * (height - padT - padB) / (hi - lo);
    // зоны
    svg.append(svgEl('rect', { x: padL, y: y(hi), width: width - padL - padR, height: y(140) - y(hi), class: 'zone-bad' }));
    svg.append(svgEl('rect', { x: padL, y: y(140), width: width - padL - padR, height: y(90) - y(140), class: 'zone-ok' }));
    for (let v = Math.ceil(lo / 20) * 20; v <= hi; v += 20) {
      svg.append(svgEl('line', { x1: padL, x2: width - padR, y1: y(v), y2: y(v), class: 'grid' }));
      const t = svgEl('text', { x: padL - 8, y: y(v) + 5, 'text-anchor': 'end', class: 'axis' }); t.textContent = v; svg.append(t);
    }
    [[140, 'lim'], [90, 'lim']].forEach(([v]) => svg.append(svgEl('line', { x1: padL, x2: width - padR, y1: y(v), y2: y(v), class: 'limit' })));
    const step = Math.ceil(pts.length / 8);
    pts.forEach((p, i) => {
      if (i % step && i !== pts.length - 1) return;
      const d = new Date(p.t); const t = svgEl('text', { x: x(i), y: height - 18, 'text-anchor': 'middle', class: 'axis' });
      t.textContent = d.getDate() + '.' + VOS.pad(d.getMonth() + 1); svg.append(t);
    });
    const line = (key, cls) => {
      const ok = pts.map((p, i) => [i, p[key]]).filter(([, v]) => v);
      svg.append(svgEl('polyline', { points: ok.map(([i, v]) => x(i) + ',' + y(v)).join(' '), class: 'line ' + cls }));
      ok.forEach(([i, v]) => svg.append(svgEl('circle', { cx: x(i), cy: y(v), r: 5, class: 'dot ' + cls })));
    };
    line('sys', 'sys'); line('dia', 'dia'); line('pulse', 'pulse');
    return svg;
  }

  VOS.registerApp({
    id: 'pressure', title: 'Дневник давления', width: 1080, height: 720,
    words: ['давление', 'дневник давления', 'тонометр', 'пульс'],
    async open(w) {
      let items = await VOS.store.get('pressure', []);
      const sys = el('input.big-input.num', { type: 'number', min: 50, max: 260, placeholder: '120' });
      const dia = el('input.big-input.num', { type: 'number', min: 30, max: 160, placeholder: '80' });
      const pulse = el('input.big-input.num', { type: 'number', min: 30, max: 220, placeholder: '70' });
      const note = el('input.big-input.grow', { placeholder: 'Самочувствие (необязательно)' });
      const chartBox = el('div.bp-chart-box'), table = el('div.list'), summary = el('div.bp-summary');

      function render() {
        items.sort((a, b) => a.t - b.t);
        chartBox.textContent = '';
        chartBox.append(chart(items, Math.max(500, chartBox.clientWidth || 900), 300));
        chartBox.append(el('div.bp-legend', null, el('span.l-sys', { text: '● Верхнее' }), el('span.l-dia', { text: '● Нижнее' }), el('span.l-pulse', { text: '● Пульс' }), el('span.muted', { text: 'Зелёная полоса — норма, красная — высокое' })));
        const last7 = items.filter(i => i.t > Date.now() - 7 * 864e5);
        summary.textContent = last7.length ? 'Среднее за неделю: ' + Math.round(last7.reduce((s, i) => s + i.sys, 0) / last7.length) + '/' + Math.round(last7.reduce((s, i) => s + i.dia, 0) / last7.length) + ' (' + last7.length + ' ' + VOS.plural(last7.length, 'измерение', 'измерения', 'измерений') + ')' : '';
        table.textContent = '';
        items.slice().reverse().slice(0, 100).forEach(it => {
          const c = classify(it.sys, it.dia), d = new Date(it.t);
          table.append(el('div.list-row', null,
            el('span.bp-date', { text: d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' }) + ' ' + VOS.fmtTime(d) }),
            el('b.bp-val', { text: it.sys + ' / ' + it.dia }),
            el('span', { text: it.pulse ? '♥ ' + it.pulse : '' }),
            el('span.bp-badge.' + c.c, { text: c.t }),
            el('span.grow.muted', { text: it.note || '' }),
            el('button.btn.small', { text: '🗑', onclick: async () => { if (await VOS.ui.confirm({ title: 'Удалить запись?', yes: 'Удалить', danger: true })) { items = items.filter(x => x !== it); await VOS.store.set('pressure', items); render(); } } })));
        });
        if (!items.length) table.append(el('div.empty', { text: 'Записей пока нет.' }));
      }
      async function add() {
        const s = +sys.value, d = +dia.value, p = +pulse.value || null;
        if (!(s >= 50 && s <= 260 && d >= 30 && d <= 160)) { VOS.ui.alert('Проверьте цифры', 'Верхнее давление обычно от 90 до 200, нижнее — от 50 до 120.', '⚠️'); return; }
        items.push({ t: Date.now(), sys: s, dia: d, pulse: p, note: note.value.trim() });
        await VOS.store.set('pressure', items);
        const c = classify(s, d);
        VOS.ui.toast('Записано: ' + s + '/' + d + ' — ' + c.t);
        VOS.speak('Записано: ' + s + ' на ' + d + '. ' + c.say);
        sys.value = dia.value = pulse.value = note.value = ''; render();
      }
      [sys, dia, pulse, note].forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') add(); }));
      w.body.append(el('div.app-pad', null,
        el('div.bp-form', null,
          el('label', null, 'Верхнее', sys), el('span.bp-slash', { text: '/' }), el('label', null, 'Нижнее', dia), el('label', null, 'Пульс', pulse),
          note, el('button.btn.primary.big', { text: '💾 Записать', onclick: add })),
        summary, chartBox, el('h3', { text: 'Все измерения' }), table,
        el('p.muted.small', { text: 'Оценка давления — подсказка, а не диагноз. Обсуждайте результаты с врачом.' })));
      render();
      w.onResize = render;
    }
  });
})();
