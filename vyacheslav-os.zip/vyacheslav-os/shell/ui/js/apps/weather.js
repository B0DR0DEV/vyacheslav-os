/*
 * Погода на неделю. Источник — Open-Meteo (бесплатно, без ключа).
 * Город берётся из Настроек; его можно поменять прямо здесь.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const WMO = {
    0: ['☀️', 'Ясно'], 1: ['🌤', 'Почти ясно'], 2: ['⛅', 'Переменная облачность'], 3: ['☁️', 'Пасмурно'],
    45: ['🌫', 'Туман'], 48: ['🌫', 'Изморозь'], 51: ['🌦', 'Слабая морось'], 53: ['🌦', 'Морось'], 55: ['🌧', 'Сильная морось'],
    56: ['🌧', 'Ледяная морось'], 57: ['🌧', 'Ледяная морось'], 61: ['🌦', 'Небольшой дождь'], 63: ['🌧', 'Дождь'], 65: ['🌧', 'Сильный дождь'],
    66: ['🌧', 'Ледяной дождь'], 67: ['🌧', 'Ледяной дождь'], 71: ['🌨', 'Небольшой снег'], 73: ['🌨', 'Снег'], 75: ['❄️', 'Сильный снег'],
    77: ['🌨', 'Снежная крупа'], 80: ['🌦', 'Ливень'], 81: ['🌧', 'Ливень'], 82: ['⛈', 'Сильный ливень'],
    85: ['🌨', 'Снегопад'], 86: ['❄️', 'Сильный снегопад'], 95: ['⛈', 'Гроза'], 96: ['⛈', 'Гроза с градом'], 99: ['⛈', 'Гроза с градом']
  };
  const wmo = c => WMO[c] || ['🌡', 'Погода'];
  const deg = t => (t > 0 ? '+' : t < 0 ? '−' : '') + Math.abs(Math.round(t)) + '°';

  async function geocode(city) {
    const r = await B.call('httpGetJson', 'https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&format=json&name=' + encodeURIComponent(city));
    if (!r.results || !r.results.length) throw new Error('Город «' + city + '» не найден');
    return r.results[0];
  }
  VOS.weather = {
    async get(city) {
      const cache = await VOS.store.get('geo', {});
      let g = cache[city];
      if (!g) { const res = await geocode(city); g = { lat: res.latitude, lon: res.longitude, name: res.name, region: res.admin1 || '' }; cache[city] = g; await VOS.store.set('geo', cache); }
      const url = 'https://api.open-meteo.com/v1/forecast?latitude=' + g.lat + '&longitude=' + g.lon +
        '&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m,surface_pressure' +
        '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max' +
        '&timezone=auto&forecast_days=7&wind_speed_unit=ms';
      const f = await B.call('httpGetJson', url);
      return { place: g, f };
    },
    summary({ place, f }) {
      const c = f.current, d = f.daily;
      return 'Сейчас в городе ' + place.name + ' ' + deg(c.temperature_2m).replace('+', 'плюс ').replace('−', 'минус ').replace('°', ' ' + VOS.plural(Math.abs(Math.round(c.temperature_2m)), 'градус', 'градуса', 'градусов')) + ', ' + wmo(c.weather_code)[1].toLowerCase() +
        '. Днём до ' + Math.round(d.temperature_2m_max[0]) + ', ночью до ' + Math.round(d.temperature_2m_min[0]) + '.' +
        (d.precipitation_probability_max[0] >= 50 ? ' Возможны осадки, возьмите зонт.' : '');
    }
  };

  VOS.registerApp({
    id: 'weather', title: 'Погода', width: 1040, height: 640,
    words: ['погода', 'погоду', 'прогноз', 'температура'],
    open(w) {
      const box = el('div.weather');
      const cityIn = el('input.big-input', { value: VOS.settings.city });
      let last = null;
      async function load() {
        box.textContent = ''; box.append(el('div.empty', { text: 'Загружаю прогноз…' }));
        try { last = await VOS.weather.get(cityIn.value.trim() || VOS.settings.city); }
        catch (e) { box.textContent = ''; box.append(el('div.empty', { text: /не найден/.test(e.message) ? e.message : 'Нет связи с интернетом. Проверьте подключение.' })); return; }
        const { place, f } = last, c = f.current, d = f.daily;
        w.setTitle(place.name);
        box.textContent = '';
        box.append(el('div.w-now', null,
          el('div.w-big', { html: VOS.weatherIcon(c.weather_code, 110) }),
          el('div', null, el('div.w-temp', { text: deg(c.temperature_2m) }), el('div.w-desc', { text: wmo(c.weather_code)[1] }),
            el('div.muted', { text: 'Ощущается как ' + deg(c.apparent_temperature) + ' · ветер ' + Math.round(c.wind_speed_10m) + ' м/с · влажность ' + c.relative_humidity_2m + '% · давление ' + Math.round(c.surface_pressure * 0.750062) + ' мм рт. ст.' })),
          el('div.w-place', null, el('b', { text: place.name }), el('div.muted', { text: place.region }))));
        const days = el('div.w-days');
        d.time.forEach((t, i) => {
          const dt = new Date(t + 'T12:00');
          days.append(el('div.w-day' + (i === 0 ? '.today' : ''), null,
            el('b', { text: i === 0 ? 'Сегодня' : i === 1 ? 'Завтра' : VOS.WEEKDAYS[dt.getDay()].replace(/^./, s => s.toUpperCase()) }),
            el('div.muted.small', { text: dt.getDate() + ' ' + VOS.MONTHS[dt.getMonth()] }),
            el('div.w-icon', { html: VOS.weatherIcon(d.weather_code[i], 56) }),
            el('div.w-max', { text: deg(d.temperature_2m_max[i]) }), el('div.w-min', { text: deg(d.temperature_2m_min[i]) }),
            el('div.small', { text: wmo(d.weather_code[i])[1] }),
            el('div.small.muted', { text: 'осадки ' + (d.precipitation_probability_max[i] ?? 0) + '% · ветер ' + Math.round(d.wind_speed_10m_max[i]) + ' м/с' })));
        });
        box.append(days);
      }
      cityIn.addEventListener('keydown', e => { if (e.key === 'Enter') load(); });
      w.body.append(el('div.app-pad', null,
        el('div.toolbar', null, el('label', { text: 'Город:' }), cityIn, el('button.btn', { text: 'Показать', onclick: load }),
          el('button.btn', { text: '⭐ Сделать основным', onclick: async () => { await VOS.saveSettings({ city: cityIn.value.trim() }); VOS.ui.toast('Город сохранён'); } }),
          el('span.spacer'), el('button.btn.primary', { text: '🔊 Озвучить', onclick: () => last && VOS.speak(VOS.weather.summary(last), { force: true }) })),
        box));
      load();
    }
  });
})();
