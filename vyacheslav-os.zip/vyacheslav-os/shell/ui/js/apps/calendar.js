/*
 * Календарь с праздниками России (государственные, православные — Пасха
 * считается по формуле, памятные дни) и своими событиями (дни рождения и т.п.).
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;

  // Православная Пасха: юлианский расчёт + 13 дней (верно для 1900–2099 гг.)
  function orthodoxEaster(y) {
    const a = y % 4, b = y % 7, c = y % 19;
    const d = (19 * c + 15) % 30, e = (2 * a + 4 * b - d + 34) % 7;
    const month = Math.floor((d + e + 114) / 31), day = ((d + e + 114) % 31) + 1;
    const dt = new Date(y, month - 1, day); dt.setDate(dt.getDate() + 13); return dt;
  }
  function nthWeekday(y, m, wd, n) {   // n-е воскресенье и т.п.; n<0 — с конца месяца
    if (n > 0) { const d = new Date(y, m, 1); d.setDate(1 + ((wd - d.getDay() + 7) % 7) + (n - 1) * 7); return d; }
    const d = new Date(y, m + 1, 0); d.setDate(d.getDate() - ((d.getDay() - wd + 7) % 7)); return d;
  }
  const FIXED = [
    ['01-01', 'Новый год', true], ['01-02', 'Новогодние каникулы', true], ['01-03', 'Новогодние каникулы', true],
    ['01-04', 'Новогодние каникулы', true], ['01-05', 'Новогодние каникулы', true], ['01-06', 'Новогодние каникулы', true],
    ['01-07', 'Рождество Христово', true], ['01-08', 'Новогодние каникулы', true],
    ['01-14', 'Старый Новый год'], ['01-19', 'Крещение Господне'], ['01-25', 'Татьянин день'],
    ['02-14', 'День святого Валентина'], ['02-23', 'День защитника Отечества', true],
    ['03-08', 'Международный женский день', true], ['04-12', 'День космонавтики'],
    ['05-01', 'Праздник Весны и Труда', true], ['05-09', 'День Победы', true],
    ['06-12', 'День России', true], ['06-22', 'День памяти и скорби'], ['07-08', 'День семьи, любви и верности'],
    ['08-19', 'Яблочный Спас (Преображение)'], ['08-22', 'День Государственного флага'],
    ['09-01', 'День знаний'], ['10-01', 'День пожилых людей'], ['10-05', 'День учителя'],
    ['10-14', 'Покров Пресвятой Богородицы'], ['11-04', 'День народного единства', true], ['12-31', 'Канун Нового года']
  ];
  VOS.holidays = function (y) {
    const out = {};
    const add = (d, name, off = false) => { const k = VOS.dateKey(d); (out[k] = out[k] || []).push({ name, off }); };
    FIXED.forEach(([md, name, off]) => add(new Date(y, +md.slice(0, 2) - 1, +md.slice(3)), name, !!off));
    const e = orthodoxEaster(y), shift = n => { const d = new Date(e); d.setDate(d.getDate() + n); return d; };
    add(e, 'Пасха (Светлое Христово Воскресение)');
    add(shift(-7), 'Вербное воскресенье');
    add(shift(-49), 'Прощёное воскресенье (конец Масленицы)');
    add(shift(-55), 'Начало Масленицы');
    add(shift(9), 'Радоница');
    add(shift(49), 'Троица');
    add(nthWeekday(y, 10, 0, -1), 'День матери');
    add(nthWeekday(y, 9, 0, 3), 'День отца');
    return out;
  };
  VOS.todayHoliday = () => { const h = VOS.holidays(new Date().getFullYear())[VOS.dateKey(new Date())]; return h ? h.map(x => x.name).join(', ') : ''; };

  VOS.registerApp({
    id: 'calendar', title: 'Календарь', width: 1040, height: 700,
    words: ['календарь', 'праздники', 'праздник', 'число', 'дата'],
    async open(w) {
      let events = await VOS.store.get('events', []);
      const view = new Date(); view.setDate(1);
      let selected = new Date();
      const grid = el('div.cal-grid'), side = el('div.cal-side'), title = el('h2.cal-title');
      const bdays = (await VOS.store.get('contacts', [])).filter(c => c.birthday).map(c => ({ id: 'b-' + c.id, date: c.birthday, title: 'День рождения: ' + c.name, yearly: true, contact: true }));
      const eventsOn = d => events.concat(bdays).filter(ev => ev.yearly ? ev.date.slice(5) === VOS.dateKey(d).slice(5) : ev.date === VOS.dateKey(d));

      function render() {
        const y = view.getFullYear(), m = view.getMonth();
        const hol = VOS.holidays(y);
        title.textContent = VOS.MONTHS_NOM[m] + ' ' + y;
        grid.textContent = '';
        ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].forEach((d, i) => grid.append(el('div.cal-wd' + (i > 4 ? '.weekend' : ''), { text: d })));
        const first = new Date(y, m, 1); const lead = (first.getDay() + 6) % 7;
        const start = new Date(y, m, 1 - lead);
        const todayK = VOS.dateKey(new Date()), selK = VOS.dateKey(selected);
        for (let i = 0; i < 42; i++) {
          const d = new Date(start); d.setDate(start.getDate() + i);
          const k = VOS.dateKey(d), h = hol[k], evs = eventsOn(d);
          const wd = d.getDay();
          const cell = el('button.cal-day' + (d.getMonth() !== m ? '.other' : '') + (k === todayK ? '.today' : '') + (k === selK ? '.sel' : '') + ((wd === 0 || wd === 6 || (h && h.some(x => x.off))) ? '.weekend' : ''),
            { onclick: () => { selected = d; render(); } },
            el('span.cal-num', { text: d.getDate() }),
            h ? el('span.cal-hol', { text: h[0].name }) : null,
            evs.length ? el('span.cal-ev', { text: '● ' + evs[0].title }) : null);
          grid.append(cell);
        }
        renderSide(hol);
      }
      function renderSide(hol) {
        side.textContent = '';
        const k = VOS.dateKey(selected), h = (VOS.holidays(selected.getFullYear())[k]) || [];
        side.append(el('h3', { text: VOS.fmtDateLong(selected) + ' ' + selected.getFullYear() }));
        h.forEach(x => side.append(el('div.cal-item.hol', { text: x.name + (x.off ? ' (выходной)' : '') })));
        eventsOn(selected).forEach(ev => side.append(el('div.cal-item', null, el('span.grow', { text: ev.title + (ev.yearly ? ' (каждый год)' : '') }),
          ev.contact ? null : el('button.btn.small', { text: '🗑', onclick: async () => { events = events.filter(x => x !== ev); await VOS.store.set('events', events); render(); } }))));
        if (!h.length && !eventsOn(selected).length) side.append(el('p.muted', { text: 'Ничего не запланировано.' }));
        side.append(el('button.btn.primary', { text: '➕ Добавить событие', onclick: addEvent }));
        // праздники месяца
        side.append(el('h3', { text: 'Праздники в этом месяце' }));
        const y = view.getFullYear(), m = view.getMonth(), all = VOS.holidays(y);
        Object.keys(all).filter(x => +x.slice(5, 7) === m + 1).sort().forEach(x => {
          const names = [...new Set(all[x].map(i => i.name))].filter(n => n !== 'Новогодние каникулы' || x.endsWith('-02'));
          if (names.length) side.append(el('div.small', { text: +x.slice(8) + ' — ' + names.join(', ') }));
        });
      }
      async function addEvent() {
        const t = el('input.big-input', { placeholder: 'Например: День рождения внука' });
        const yearly = el('input', { type: 'checkbox', checked: true });
        const ok = await VOS.ui.dialog({ icon: '📅', title: 'Событие на ' + VOS.fmtDate(selected),
          body: el('div.form', null, t, el('label.check', null, yearly, ' Повторять каждый год')),
          buttons: [{ label: 'Отмена', value: false }, { label: 'Сохранить', value: true, primary: true }] });
        if (!ok || !t.value.trim()) return;
        events.push({ id: VOS.uid(), date: VOS.dateKey(selected), title: t.value.trim(), yearly: yearly.checked });
        await VOS.store.set('events', events); render();
      }
      const nav = el('div.toolbar', null,
        el('button.btn', { text: '@back', onclick: () => { view.setMonth(view.getMonth() - 1); render(); } }),
        title,
        el('button.btn', { text: '@forward', onclick: () => { view.setMonth(view.getMonth() + 1); render(); } }),
        el('button.btn', { text: 'Сегодня', onclick: () => { selected = new Date(); view.setTime(new Date().getTime()); view.setDate(1); render(); } }));
      w.body.append(el('div.cal', null, el('div.cal-main', null, nav, grid), side));
      render();
    }
  });
})();
