/*
 * «Доброе утро» — сводка на день одной фразой или кнопкой:
 * приветствие и дата, праздник, погода, лекарства на сегодня, какие
 * таблетки заканчиваются, дни рождения родных, напоминания (счётчики,
 * квартплата) и три главные новости. Сводка показывается карточками и
 * читается голосом. Утром при первом входе запускается сама
 * (Настройки → Голосовой помощник → «Утренняя сводка»).
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend, L = window.VOS_LINKS;
  let newsCache = null;

  async function headlines(n = 3) {
    if (newsCache && Date.now() - newsCache.t < 30 * 60e3) return newsCache.items.slice(0, n);
    for (const src of L.newsRss || []) {
      try {
        const xml = await B.call('httpGetText', src.url);
        const doc = new DOMParser().parseFromString(xml, 'text/xml');
        const items = [...doc.querySelectorAll('item > title')].map(t => t.textContent.trim().replace(/\s+/g, ' ')).filter(Boolean);
        if (items.length) { newsCache = { t: Date.now(), items, src: src.name }; return items.slice(0, n); }
      } catch (_) { /* следующий источник */ }
    }
    return [];
  }

  async function compose() {
    const s = VOS.settings, d = new Date(), cards = [], say = [];
    say.push(VOS.greeting(d) + ', ' + s.name + '! Сегодня ' + VOS.WEEKDAYS[d.getDay()] + ', ' + d.getDate() + ' ' + VOS.MONTHS[d.getMonth()] + '.');
    const hol = VOS.todayHoliday();
    if (hol) { say.push('Праздник: ' + hol + '.'); cards.push({ icon: 'star', title: 'Праздник', text: hol }); }
    // погода
    try {
      const wth = await VOS.weather.get(s.city);
      const c = wth.f.current, dd = wth.f.daily;
      let tip = '';
      if (dd.temperature_2m_max[0] <= -10) tip = ' Очень холодно — одевайтесь потеплее.';
      else if (dd.temperature_2m_max[0] >= 28) tip = ' Будет жарко — пейте больше воды.';
      say.push(VOS.weather.summary(wth) + tip);
      cards.push({ icon: 'sun', title: 'Погода — ' + wth.place.name, text: Math.round(c.temperature_2m) + '°, днём до ' + Math.round(dd.temperature_2m_max[0]) + '°, ночью ' + Math.round(dd.temperature_2m_min[0]) + '°' + (dd.precipitation_probability_max[0] >= 50 ? ', возможны осадки' : ''), wx: c.weather_code });
    } catch (_) { cards.push({ icon: 'wifi-off', title: 'Погода', text: 'Нет интернета' }); }
    // лекарства
    const meds = (await VOS.store.get('meds', [])).filter(m => m.enabled !== false);
    const log = (await VOS.store.get('medlog', {}))[VOS.dateKey(d)] || {};
    const now = VOS.fmtTime(d);
    const left = meds.flatMap(m => m.times.map(t => ({ m, t }))).filter(x => !log[x.m.id + '@' + x.t] && x.t >= now).sort((a, b) => a.t.localeCompare(b.t));
    if (left.length) {
      say.push('Лекарства сегодня: ' + left.map(x => x.m.name + ' в ' + x.t.replace(/^0/, '')).join(', ') + '.');
      cards.push({ icon: 'pill', title: 'Лекарства', text: left.map(x => x.t + ' — ' + x.m.name).join('\n') });
    }
    if (VOS.meds && VOS.meds.low) {
      const low = await VOS.meds.low(5);
      if (low.length) {
        say.push('Пора купить: ' + low.map(m => m.name).join(', ') + '.');
        cards.push({ icon: 'warning', title: 'Заканчиваются', text: low.map(m => m.name + ' — на ' + VOS.meds.daysLeft(m) + ' ' + VOS.plural(VOS.meds.daysLeft(m), 'день', 'дня', 'дней')).join('\n'), warn: true });
      }
    }
    // дни рождения
    if (VOS.contacts) {
      const b = (await VOS.contacts.birthdays(1));
      b.forEach(x => {
        const when = x.days === 0 ? 'Сегодня' : 'Завтра';
        say.push(when + ' день рождения празднует ' + (x.c.relation ? x.c.relation + ' ' : '') + x.c.name + '.' + (x.days === 0 ? ' Можно позвонить и поздравить.' : ''));
        cards.push({ icon: 'heart', title: when + ' день рождения', text: x.c.name + (x.age ? ', ' + x.age : ''), call: x.days === 0 ? x.c : null });
      });
    }
    // напоминания
    if (VOS.metersApi) {
      const due = await VOS.metersApi.dueToday();
      if (due.length) { say.push('Не забудьте: ' + due.map(r => r.title.toLowerCase()).join(', ') + '.'); cards.push({ icon: 'bell', title: 'Не забыть', text: due.map(r => r.title).join('\n') }); }
    }
    // будильники и события календаря
    const events = (await VOS.store.get('events', [])).filter(ev => ev.yearly ? ev.date.slice(5) === VOS.dateKey(d).slice(5) : ev.date === VOS.dateKey(d));
    if (events.length) { say.push('В календаре: ' + events.map(e => e.title).join(', ') + '.'); cards.push({ icon: 'calendar', title: 'Календарь', text: events.map(e => e.title).join('\n') }); }
    // новости
    const news = await headlines(3);
    if (news.length) {
      say.push('Главные новости. ' + news.map(n => n.replace(/[.!?]?$/, '.')).join(' '));
      cards.push({ icon: 'news', title: 'Новости — ' + (newsCache ? newsCache.src : ''), text: news.join('\n'), news: true });
    }
    say.push('Хорошего дня!');
    return { cards, text: say.join(' ') };
  }

  VOS.briefing = {
    compose, headlines,
    async run({ open = true, speak = false } = {}) {
      const r = await compose();
      if (open) VOS.wm.open('briefing', { data: r });
      if (speak) VOS.assistant.announce(r.text, { title: 'Доброе утро' });
      return { say: r.text };
    },
    async headlinesReply() {
      const n = await headlines(5);
      if (!n.length) return { say: 'Не получилось загрузить новости. Проверьте интернет.' };
      return { say: 'Главные новости. ' + n.map(x => x.replace(/[.!?]?$/, '.')).join(' ') };
    }
  };

  VOS.registerApp({
    id: 'briefing', title: 'Доброе утро', width: 1000, height: 680,
    words: ['доброе утро', 'сводка', 'что нового', 'утро'],
    open(w, args) {
      const box = el('div.brief');
      const head = el('div.brief-head', null,
        el('div', null, el('h1', { text: VOS.greeting() + ', ' + VOS.settings.name + '!' }), el('div.muted.big', { text: VOS.fmtDateLong(new Date()) })),
        el('span.spacer'),
        el('button.btn.primary.big', { text: '🔊 Прочитать вслух', onclick: async () => { const r = last || await compose(); VOS.assistant.announce(r.text, { title: 'Доброе утро' }); } }),
        el('button.btn.big', { text: '🔄 Обновить', onclick: () => load() }));
      let last = null;
      function draw(r) {
        last = r; box.textContent = '';
        r.cards.forEach((c, i) => {
          const card = el('div.brief-card' + (c.warn ? '.warn' : '') + (c.news ? '.wide' : ''), { style: { animationDelay: i * 60 + 'ms' } },
            el('div.bc-title', null, VOS.gl(c.icon), el('span', { text: c.title })),
            c.wx !== undefined ? el('div.bc-wx', { html: VOS.weatherIcon(c.wx, 56) }) : null,
            el('div.bc-text', { text: c.text }),
            c.call ? el('button.btn.primary', { text: '@video', onclick: () => VOS.wm.open('call', { id: c.call.id }) }, 'Позвонить и поздравить') : null);
          box.append(card);
        });
        if (!r.cards.length) box.append(el('div.empty', { text: 'Сегодня ничего особенного. Хорошего дня!' }));
      }
      async function load() { box.textContent = ''; box.append(el('div.empty', { text: 'Собираю сводку…' })); draw(await compose()); }
      w.body.append(el('div.app-pad', null, head, box));
      if (args.data) draw(args.data); else load();
      w.onArgs = a => { if (a.data) draw(a.data); };
    }
  });
})();
