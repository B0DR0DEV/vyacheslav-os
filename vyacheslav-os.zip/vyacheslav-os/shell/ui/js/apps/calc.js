/* Калькулятор с крупными кнопками. Работает и с клавиатуры. Без eval — своя простая логика. */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;

  VOS.registerApp({
    id: 'calc', title: 'Калькулятор', width: 480, height: 660,
    words: ['калькулятор', 'посчитать', 'счёты', 'считать'],
    open(w) {
      let acc = null, op = null, input = '0', fresh = true, history = '';
      const disp = el('div.calc-display', { text: '0' });
      const hist = el('div.calc-history', { text: '' });
      const OPS = { '+': (a, b) => a + b, '−': (a, b) => a - b, '×': (a, b) => a * b, '÷': (a, b) => b === 0 ? NaN : a / b };
      const num = () => parseFloat(input.replace(',', '.'));
      const show = () => {
        const n = num();
        disp.textContent = input.endsWith(',') ? VOS.fmtNum(n) + ',' : (/,\d*0$/.test(input) ? input : VOS.fmtNum(n));
        hist.textContent = history;
        disp.classList.toggle('long', disp.textContent.length > 11);
      };
      function digit(d) {
        if (fresh) { input = d === ',' ? '0,' : d; fresh = false; }
        else if (d === ',' ? !input.includes(',') : input.replace(/[^0-9]/g, '').length < 14) input = input === '0' && d !== ',' ? d : input + d;
        show();
      }
      function compute() { if (op && acc !== null) { acc = OPS[op](acc, num()); } else acc = num(); }
      function setOp(o) {
        if (!fresh || acc === null) compute();
        op = o; history = VOS.fmtNum(acc) + ' ' + o; input = String(acc).replace('.', ','); fresh = true; show(); disp.textContent = VOS.fmtNum(acc);
      }
      function equals() {
        if (!op) return;
        const b = num(); history = VOS.fmtNum(acc) + ' ' + op + ' ' + VOS.fmtNum(b) + ' =';
        acc = OPS[op](acc, b); op = null;
        input = isFinite(acc) ? String(acc).replace('.', ',') : '0';
        disp.textContent = isFinite(acc) ? VOS.fmtNum(acc) : 'На ноль делить нельзя';
        hist.textContent = history; fresh = true; acc = null;
      }
      const clear = () => { acc = null; op = null; input = '0'; fresh = true; history = ''; show(); };
      const back = () => { if (fresh) return; input = input.length > 1 ? input.slice(0, -1) : '0'; show(); };
      const percent = () => { const v = num(); input = String(acc !== null ? acc * v / 100 : v / 100).replace('.', ','); fresh = false; show(); };
      const neg = () => { if (input !== '0') { input = input.startsWith('-') ? input.slice(1) : '-' + input; show(); } };

      const keys = [
        ['C', clear, 'fn'], ['⌫', back, 'fn'], ['%', percent, 'fn'], ['÷', () => setOp('÷'), 'op'],
        ['7'], ['8'], ['9'], ['×', () => setOp('×'), 'op'],
        ['4'], ['5'], ['6'], ['−', () => setOp('−'), 'op'],
        ['1'], ['2'], ['3'], ['+', () => setOp('+'), 'op'],
        ['±', neg, 'fn'], ['0'], [',', () => digit(',')], ['=', equals, 'eq']
      ];
      const pad = el('div.calc-pad');
      keys.forEach(([t, fn, cls]) => pad.append(el('button.calc-key' + (cls ? '.' + cls : ''), { text: t, onclick: () => { VOS.sound.click(); (fn || (() => digit(t)))(); } })));
      const onKey = e => {
        if (!w.el.classList.contains('active')) return;
        const k = e.key;
        if (/^[0-9]$/.test(k)) digit(k);
        else if (k === ',' || k === '.') digit(',');
        else if (k === '+') setOp('+'); else if (k === '-') setOp('−'); else if (k === '*') setOp('×'); else if (k === '/') setOp('÷');
        else if (k === 'Enter' || k === '=') equals(); else if (k === 'Backspace') back(); else if (k === 'Escape' || k === 'Delete') clear();
        else return;
        e.preventDefault();
      };
      document.addEventListener('keydown', onKey);
      w.body.append(el('div.calc', null, hist, disp, pad));
      return () => document.removeEventListener('keydown', onKey);
    }
  });
})();
