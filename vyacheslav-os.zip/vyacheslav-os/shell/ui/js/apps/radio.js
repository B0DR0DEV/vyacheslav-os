/*
 * Радио: потоковое аудио. Адрес потока ищется по названию станции
 * в открытом каталоге radio-browser.info (без ключей и регистрации).
 * Окно можно свернуть — радио продолжит играть.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend, L = window.VOS_LINKS;

  async function apiGet(pathQ) {
    let lastErr;
    for (const host of L.radioApi) {
      try { return await B.call('httpGetJson', host + pathQ); } catch (e) { lastErr = e; }
    }
    throw lastErr || new Error('нет связи');
  }
  async function findStations(q, limit = 10) {
    const p = '/json/stations/search?name=' + encodeURIComponent(q) + '&hidebroken=true&order=clickcount&reverse=true&limit=' + limit;
    const list = await apiGet(p);
    // сначала российские станции, без HLS (его воспроизведение сложнее)
    return list.filter(s => s.url_resolved && !s.hls).sort((a, b) => ((b.countrycode === 'RU') - (a.countrycode === 'RU')) || (b.clickcount - a.clickcount));
  }

  VOS.registerApp({
    id: 'radio', title: 'Радио', width: 860, height: 640,
    words: ['радио', 'радиоприёмник', 'приёмник', 'музыку', 'музыка'],
    open(w, args) {
      const audio = new Audio();
      audio.preload = 'none';
      const now = el('div.radio-now', { text: 'Выберите радиостанцию' });
      const state = el('div.radio-state.muted', { text: '' });
      const playBtn = el('button.btn.huge.primary', { text: '▶ Играть', disabled: true });
      const setBtn = on => { playBtn.innerHTML = ''; playBtn.append(VOS.gl(on ? 'pause' : 'play'), on ? 'Пауза' : 'Играть'); const p = playBtn.closest('.radio-player'); if (p) p.classList.toggle('playing', on); };
      let current = null, candidates = [], ci = 0;

      let trying = false;
      async function tryPlay() {
        trying = true;
        try {
          while (ci < candidates.length) {
            const s = candidates[ci];
            audio.src = s.url_resolved;
            state.textContent = 'Подключаюсь…';
            try { await audio.play(); state.textContent = 'В эфире'; setBtn(true); playBtn.disabled = false; return true; }
            catch (_) { ci++; }
          }
          state.textContent = 'Эта станция сейчас не отвечает. Попробуйте другую.';
          playBtn.disabled = true; return false;
        } finally { trying = false; }
      }
      async function play(st) {
        current = st; now.textContent = st.name; state.textContent = 'Ищу станцию…';
        w.setTitle(st.name);
        try { candidates = await findStations(st.query || st.name); ci = 0; }
        catch (_) { state.textContent = 'Нет интернета. Проверьте подключение (значок Wi-Fi внизу справа).'; return; }
        if (!candidates.length) { state.textContent = 'Станция не найдена.'; return; }
        tryPlay();
      }
      audio.addEventListener('error', () => { if (!trying && current && audio.src && ci < candidates.length) { ci++; tryPlay(); } });
      audio.addEventListener('waiting', () => { state.textContent = 'Загружается…'; });
      audio.addEventListener('playing', () => { state.textContent = 'В эфире'; });
      playBtn.onclick = () => {
        if (audio.paused) { audio.play().catch(() => {}); setBtn(true); }
        else { audio.pause(); setBtn(false); state.textContent = 'Пауза'; }
      };

      const grid = el('div.tile-grid.small');
      L.radio.forEach((st, i) => grid.append(el('button.tile', { onclick: () => play(st) }, el('span.tile-badge', { text: st.name.replace(/^Радио /, '').split(/\s+/).map(x => x[0]).join('').slice(0, 2).toUpperCase(), style: { '--h': (i * 47 + 20) % 360 } }), el('span', { text: st.name }))));
      const search = el('input.big-input.grow', { placeholder: 'Найти другую станцию по названию' });
      const results = el('div.list');
      const doSearch = async () => {
        const q = search.value.trim(); if (!q) return;
        results.textContent = 'Ищу…';
        try {
          const list = await findStations(q, 25);
          results.textContent = '';
          if (!list.length) results.textContent = 'Ничего не найдено.';
          const seen = new Set();
          list.forEach(s => {
            if (seen.has(s.name)) return; seen.add(s.name);
            results.append(el('button.list-row', { onclick: () => { current = { name: s.name }; now.textContent = s.name; candidates = [s]; ci = 0; w.setTitle(s.name); tryPlay(); } },
              el('span', { text: s.name }), el('span.muted', { text: [s.country, s.bitrate ? s.bitrate + ' кбит/с' : ''].filter(Boolean).join(' · ') })));
          });
        } catch (_) { results.textContent = 'Нет интернета.'; }
      };
      search.addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });

      w.body.append(el('div.app-pad', null,
        el('div.radio-player', null, now, state, el('div.row', null, playBtn, el('button.btn.huge', { text: '🔊 Громкость', onclick: () => VOS.$('#tray-vol').click() }), el('div.radio-eq', null, el('i'), el('i'), el('i'), el('i')))),
        el('h3', { text: 'Станции' }), grid,
        el('div.search-bar', null, search, el('button.btn.primary', { text: '🔍 Найти', onclick: doSearch })),
        results));

      w.onArgs = a => { if (a.query) { const st = L.radio.find(s => s.name.toLowerCase().includes(a.query.toLowerCase()) || s.query.toLowerCase().includes(a.query.toLowerCase())) || { name: a.query, query: a.query }; play(st); } };
      if (args.query) w.onArgs(args);
      VOS.radioStop = () => { audio.pause(); };
      return () => { audio.pause(); audio.src = ''; VOS.radioStop = null; };
    }
  });
})();
