/*
 * Фото: просмотр фотографий из папки «Фото» и с флешки, слайд-шоу на весь экран.
 * С флешки фото можно скопировать в папку «Фото» одной кнопкой.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const url = p => 'file://' + p.split('/').map(encodeURIComponent).join('/');

  function slideshow(photos, start = 0) {
    let i = start, paused = false, timer = null;
    const img = el('img.ss-img');
    const cap = el('div.ss-cap');
    const o = VOS.ui.overlay('slideshow');
    const show = () => { img.classList.remove('in'); img.src = url(photos[i].path); cap.textContent = (i + 1) + ' из ' + photos.length + ' · ' + photos[i].name; requestAnimationFrame(() => img.classList.add('in')); };
    const next = d => { i = (i + d + photos.length) % photos.length; show(); };
    const plan = () => { clearInterval(timer); if (!paused) timer = setInterval(() => next(1), (VOS.settings.slideSec || 5) * 1000); };
    const pauseBtn = el('button.btn.huge', { text: '⏸ Пауза', onclick: () => { paused = !paused; VOS.setBtn(pauseBtn, paused ? '▶ Дальше' : '⏸ Пауза'); plan(); } });
    const end = () => { clearInterval(timer); document.removeEventListener('keydown', key); o.remove(); };
    const key = e => { if (e.key === 'Escape') end(); else if (e.key === 'ArrowRight') { next(1); plan(); } else if (e.key === 'ArrowLeft') { next(-1); plan(); } else if (e.key === ' ') pauseBtn.click(); };
    document.addEventListener('keydown', key);
    o.append(img, cap, el('div.ss-ctrl', null,
      el('button.btn.huge', { text: '@back', onclick: () => { next(-1); plan(); } }), pauseBtn,
      el('button.btn.huge', { text: '@forward', onclick: () => { next(1); plan(); } }),
      el('button.btn.huge.danger', { text: '✕ Закрыть', onclick: end })));
    show(); plan();
  }

  VOS.registerApp({
    id: 'photos', title: 'Фото', width: 1080, height: 700,
    words: ['фото', 'фотографии', 'фотки', 'снимки', 'слайд-шоу', 'картинки'],
    open(w) {
      let photos = [], source = null;
      const grid = el('div.ph-grid');
      const srcBar = el('div.chip-bar');
      const actions = el('div.toolbar');
      async function load(dir, label) {
        source = dir; grid.textContent = ''; grid.append(el('div.empty', { text: 'Ищу фотографии…' }));
        try { photos = await B.call('photosList', dir || null); } catch (e) { photos = []; }
        grid.textContent = '';
        w.setTitle(label);
        actions.textContent = '';
        actions.append(el('b', { text: label + ': ' + photos.length + ' ' + VOS.plural(photos.length, 'фото', 'фото', 'фото') }), el('span.spacer'));
        if (photos.length) actions.append(el('button.btn.primary', { text: '▶ Слайд-шоу', onclick: () => slideshow(photos) }));
        if (dir && photos.length) actions.append(el('button.btn', { text: '📥 Скопировать в «Фото»', onclick: async () => { const n = await B.call('photosImport', photos.map(p => p.path)); VOS.ui.toast('Скопировано: ' + n); } }));
        if (!photos.length) {
          grid.append(el('div.empty', { text: dir ? 'На флешке фотографий не найдено.' : 'В папке «Фото» пока пусто. Вставьте флешку с фотографиями и нажмите «Флешка».' }));
          return;
        }
        photos.slice(0, 600).forEach((p, i) => grid.append(el('button.ph-item', { title: p.name, onclick: () => slideshow(photos, i) }, el('img', { src: url(p.path), loading: 'lazy', alt: p.name }))));
      }
      async function usb() {
        const devs = await B.call('usbList').catch(() => []);
        if (!devs.length) return VOS.ui.alert('Флешка не найдена', 'Вставьте флешку в любой USB-разъём и подождите 5 секунд.', '🔌');
        for (const d of devs) {
          const mp = d.mountpoint || await B.call('usbMount', d.path).catch(() => null);
          if (mp) { load(mp, 'Флешка ' + (d.label || '')); return; }
        }
        VOS.ui.alert('Не получилось открыть флешку', 'Попробуйте вынуть её и вставить снова.', '⚠️');
      }
      srcBar.append(
        el('button.chip.on', { text: '🖼 Папка «Фото»', onclick: e => { mark(e); load(null, 'Папка «Фото»'); } }),
        el('button.chip', { text: '🔌 Флешка', onclick: e => { mark(e); usb(); } }));
      function mark(e) { srcBar.querySelectorAll('.chip').forEach(c => c.classList.remove('on')); e.target.classList.add('on'); }
      w.body.append(el('div.app-pad', null, srcBar, actions, grid));
      load(null, 'Папка «Фото»');
    }
  });
})();
