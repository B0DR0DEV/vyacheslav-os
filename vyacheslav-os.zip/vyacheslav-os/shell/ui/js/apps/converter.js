/* Конвертер единиц: длина, вес, объём, площадь, температура, скорость, давление, время, валюта (курс ЦБ РФ). */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const CATS = {
    length: { name: 'Длина', units: { 'миллиметр': 0.001, 'сантиметр': 0.01, 'метр': 1, 'километр': 1000, 'дюйм': 0.0254, 'фут': 0.3048, 'миля': 1609.344, 'верста': 1066.8, 'аршин': 0.7112, 'сажень': 2.1336 } },
    mass: { name: 'Вес', units: { 'грамм': 0.001, 'килограмм': 1, 'центнер': 100, 'тонна': 1000, 'фунт': 0.45359237, 'унция': 0.0283495, 'пуд': 16.3805 } },
    volume: { name: 'Объём', units: { 'миллилитр': 0.001, 'литр': 1, 'кубометр': 1000, 'стакан (250 мл)': 0.25, 'столовая ложка': 0.015, 'чайная ложка': 0.005, 'ведро (10 л)': 10, 'галлон (США)': 3.78541 } },
    area: { name: 'Площадь', units: { 'кв. метр': 1, 'сотка': 100, 'ар': 100, 'гектар': 10000, 'кв. километр': 1e6, 'акр': 4046.86 } },
    temp: { name: 'Температура', units: { 'Цельсий': 'c', 'Фаренгейт': 'f', 'Кельвин': 'k' } },
    speed: { name: 'Скорость', units: { 'км/ч': 1 / 3.6, 'м/с': 1, 'миль/ч': 0.44704, 'узел': 0.514444 } },
    pressure: { name: 'Давление', units: { 'мм рт. ст.': 133.322, 'гектопаскаль': 100, 'килопаскаль': 1000, 'атмосфера': 101325, 'бар': 100000 } },
    time: { name: 'Время', units: { 'секунда': 1, 'минута': 60, 'час': 3600, 'сутки': 86400, 'неделя': 604800, 'год': 31557600 } },
    money: { name: 'Валюта', units: null }
  };
  const toC = (v, u) => u === 'c' ? v : u === 'f' ? (v - 32) * 5 / 9 : v - 273.15;
  const fromC = (v, u) => u === 'c' ? v : u === 'f' ? v * 9 / 5 + 32 : v + 273.15;

  async function rates() {
    const cache = await VOS.store.get('rates', null);
    if (cache && Date.now() - cache.t < 6 * 3600e3) return cache;
    try {
      const r = await B.call('httpGetJson', 'https://www.cbr-xml-daily.ru/daily_json.js');
      const units = { 'Рубль': 1 };
      const names = { USD: 'Доллар США', EUR: 'Евро', CNY: 'Китайский юань', BYN: 'Белорусский рубль', KZT: 'Казахстанский тенге', TRY: 'Турецкая лира', AMD: 'Армянский драм', UZS: 'Узбекский сум', GBP: 'Фунт стерлингов', JPY: 'Японская иена' };
      for (const [code, v] of Object.entries(r.Valute || {})) if (names[code]) units[names[code]] = v.Value / v.Nominal;
      const data = { t: Date.now(), date: r.Date, units };
      await VOS.store.set('rates', data); return data;
    } catch (e) { if (cache) return cache; throw e; }
  }

  VOS.registerApp({
    id: 'converter', title: 'Конвертер', desktop: false, width: 860, height: 560,
    words: ['конвертер', 'перевести единицы', 'единицы', 'курс', 'валюта', 'курс доллара'],
    open(w, args) {
      let cat = args.cat || 'length';
      const tabs = el('div.chip-bar');
      const inp = el('input.big-input.num.grow', { type: 'number', value: 1 });
      const from = el('select.big-select'), to = el('select.big-select');
      const out = el('div.conv-out');
      const note = el('div.muted.small');
      let units = {};
      async function setCat(c) {
        cat = c;
        tabs.querySelectorAll('.chip').forEach(x => x.classList.toggle('on', x.dataset.c === c));
        note.textContent = '';
        if (c === 'money') {
          out.textContent = 'Загружаю курс…';
          try { const r = await rates(); units = r.units; note.textContent = 'Курс Центрального банка России на ' + new Date(r.date).toLocaleDateString('ru-RU'); }
          catch (_) { out.textContent = 'Нет интернета — курс недоступен.'; return; }
        } else units = CATS[c].units;
        const names = Object.keys(units);
        from.textContent = ''; to.textContent = '';
        names.forEach(n => { from.append(el('option', { text: n, value: n })); to.append(el('option', { text: n, value: n })); });
        to.selectedIndex = Math.min(1, names.length - 1);
        if (c === 'money') { from.value = 'Доллар США'; to.value = 'Рубль'; }
        if (c === 'length') { from.value = 'километр'; to.value = 'метр'; }
        calc();
      }
      function calc() {
        const v = parseFloat(inp.value);
        if (!isFinite(v)) { out.textContent = '—'; return; }
        let r;
        if (cat === 'temp') r = fromC(toC(v, units[from.value]), units[to.value]);
        else r = v * units[from.value] / units[to.value];
        out.textContent = '';
        out.append(el('small', { text: from.value + ': ' + VOS.fmtNum(v, 6) + '  →  ' + to.value + ':' }), VOS.fmtNum(r, cat === 'money' ? 2 : 6));
      }
      Object.entries(CATS).forEach(([k, c]) => tabs.append(el('button.chip', { text: c.name, 'data-c': k, onclick: () => setCat(k) })));
      [inp, from, to].forEach(x => x.addEventListener('input', calc));
      const swap = el('button.btn.round', { text: '⇄', title: 'Поменять местами', onclick: () => { const a = from.value; from.value = to.value; to.value = a; calc(); } });
      w.body.append(el('div.app-pad', null, tabs, el('div.conv-row', null, inp, from, swap, to), out, note));
      setCat(cat);
      w.onArgs = a => { if (a.cat) setCat(a.cat); };
    }
  });
})();
