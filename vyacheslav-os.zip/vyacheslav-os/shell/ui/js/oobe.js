/*
 * oobe.js — первоначальная настройка при первом включении после установки
 * (как в Windows). Шаги:
 *   приветствие → город и время → интернет (можно пропустить) →
 *   перенос данных с флешки → как к вам обращаться → имя компьютера →
 *   пароль (или вход без пароля) → голосовой помощник → размер текста и
 *   тема → готово (и экскурсия по экрану).
 * Каждый шаг помощник произносит вслух. Всё сохраняется сразу, поэтому
 * если выключить компьютер посреди настройки — продолжим с теми же
 * ответами. Пройти заново: Настройки → О системе.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const TZ = [
    ['Europe/Kaliningrad', 'Калининград (МСК−1)'], ['Europe/Moscow', 'Москва (МСК)'], ['Europe/Samara', 'Самара (МСК+1)'],
    ['Asia/Yekaterinburg', 'Екатеринбург (МСК+2)'], ['Asia/Omsk', 'Омск (МСК+3)'], ['Asia/Novosibirsk', 'Новосибирск (МСК+4)'],
    ['Asia/Krasnoyarsk', 'Красноярск (МСК+4)'], ['Asia/Irkutsk', 'Иркутск (МСК+5)'], ['Asia/Yakutsk', 'Якутск (МСК+6)'],
    ['Asia/Vladivostok', 'Владивосток (МСК+7)'], ['Asia/Magadan', 'Магадан (МСК+8)'], ['Asia/Kamchatka', 'Камчатка (МСК+9)']
  ];
  // «Вячеслав» → «Вячеслава», «Илья» → «Ильи», «Мария» → «Марии»
  function genitive(name) {
    const n = String(name || '').trim();
    if (!n) return n;
    if (/ия$/i.test(n)) return n.slice(0, -1) + 'и';
    if (/[гкхжчшщ]а$/i.test(n)) return n.slice(0, -1) + 'и';
    if (/а$/i.test(n)) return n.slice(0, -1) + 'ы';
    if (/я$/i.test(n)) return n.slice(0, -1) + 'и';
    if (/[йь]$/i.test(n)) return n.slice(0, -1) + 'я';
    if (/[бвгджзклмнпрстфхцчшщ]$/i.test(n)) return n + 'а';
    return n;
  }
  VOS.genitive = genitive;

  function start({ again = false } = {}) {
    if (VOS.$('#oobe')) return;
    const s = VOS.settings;
    const draft = { name: s.name, city: s.city, timezone: s.timezone, device: '', fontScale: s.fontScale, theme: s.theme };
    const root = el('div#oobe');
    const prog = el('div.ob-progress-fill');
    const side = el('div.ob-side');
    const main = el('div.ob-main');
    const card = el('div.ob-card', null, el('div.ob-progress', null, prog), el('div.ob-cols', null, side, main));
    root.append(el('div.ob-brand', { html: VOS.logoSVG(40) + '<span>ВячеславOS</span>' }), card);
    document.body.append(root);
    let idx = 0, said = '';

    const say = text => { said = text; VOS.stopSpeaking(); VOS.speak(text, { force: true }); };
    const sideArt = (glyph, title, hint) => {
      side.textContent = '';
      side.append(el('div.ob-art', { html: glyph.startsWith('<') ? glyph : VOS.glyph(glyph) }), el('div.ob-side-title', { text: title }));
      if (hint) side.append(el('div.ob-side-hint', { text: hint }));
    };
    const btns = (...b) => el('div.ob-btns', null, el('button.ob-say', { title: 'Прочитать ещё раз', html: VOS.glyph('volume'), onclick: () => say(said) }), el('span.spacer'), ...b.filter(Boolean));
    const next = (label = 'Далее', fn) => el('button.btn.huge.primary.ob-next', { text: label, onclick: async () => { if (fn && (await fn()) === false) return; go(idx + 1); } });
    const back = () => idx > 0 ? el('button.btn.huge', { text: 'Назад', onclick: () => go(idx - 1) }) : null;
    const skip = (label = 'Пропустить') => el('button.btn.huge.ob-skip', { text: label, onclick: () => go(idx + 1) });

    const STEPS = [
      /* 0. приветствие */
      () => {
        sideArt(VOS.logoSVG(150, true), 'Добро пожаловать', '');
        main.append(el('h1', { text: again ? 'Настроим ещё раз' : 'Здравствуйте!' }),
          el('p.ob-lead', { text: 'Сейчас мы вместе настроим компьютер: интернет, ваше имя, пароль и помощника. Это займёт около пяти минут.' }),
          el('p.muted', { text: 'Читать не обязательно — я буду говорить вслух. Нажимайте большую синюю кнопку внизу.' }),
          btns(next('Начать')));
        say('Здравствуйте! Сейчас мы вместе настроим компьютер. Это займёт около пяти минут. Нажмите синюю кнопку «Начать».');
      },
      /* 1. город и время */
      () => {
        sideArt('globe', 'Где вы живёте', 'Нужно для погоды и правильного времени');
        const city = el('input.big-input.ob-input', { value: draft.city, placeholder: 'Например: Тверь' });
        const tz = el('select.big-select.ob-input');
        TZ.forEach(([v, n]) => tz.append(el('option', { value: v, text: n, selected: v === draft.timezone })));
        const found = el('div.muted.ob-found');
        const look = VOS.debounce(async () => {
          const q = city.value.trim(); if (q.length < 2) return;
          try {
            const r = await B.call('httpGetJson', 'https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&format=json&name=' + encodeURIComponent(q));
            const g = r.results && r.results[0];
            if (!g) { found.textContent = 'Такой город не найден — проверьте написание.'; return; }
            found.textContent = 'Нашли: ' + g.name + (g.admin1 ? ', ' + g.admin1 : '');
            if (g.timezone && TZ.some(t => t[0] === g.timezone)) tz.value = g.timezone;
          } catch (_) { found.textContent = ''; }
        }, 700);
        city.addEventListener('input', look);
        main.append(el('h1', { text: 'В каком городе вы живёте?' }),
          el('label.ob-label', { text: 'Город' }), city, found,
          el('label.ob-label', { text: 'Часовой пояс' }), tz,
          btns(back(), next('Далее', async () => {
            draft.city = city.value.trim() || 'Москва'; draft.timezone = tz.value;
            await VOS.saveSettings({ city: draft.city, timezone: draft.timezone });
            B.call('setTimezone', draft.timezone).catch(() => {});
          })));
        say('В каком городе вы живёте? Это нужно для погоды и точного времени.');
        setTimeout(() => city.focus(), 300);
      },
      /* 2. интернет */
      () => {
        sideArt('wifi', 'Интернет', 'Нужен для новостей, видео, погоды и помощника');
        const panel = VOS.wifiPanel();
        const ok = el('div.ob-ok.hidden', null, VOS.gl('check'), el('span', { text: 'Интернет работает!' }));
        const iv = setInterval(async () => { const st = await B.call('wifiStatus').catch(() => ({})); ok.classList.toggle('hidden', !(st.wired || st.ssid)); }, 2500);
        main.append(el('h1', { text: 'Подключимся к интернету' }),
          el('p.muted', { text: 'Выберите свою сеть Wi-Fi и введите пароль — обычно он написан на наклейке снизу роутера. Если подключён кабель, интернет уже работает.' }),
          ok, el('div.ob-wifi', null, panel),
          btns(back(), skip('Подключусь позже'), next('Далее')));
        main._cleanup = () => clearInterval(iv);
        say('Подключимся к интернету. Выберите свою сеть и введите пароль. Если сейчас не получается — нажмите «Подключусь позже».');
      },
      /* 3. перенос данных */
      () => {
        sideArt('usb', 'Перенос данных', 'Если раньше уже пользовались ВячеславOS');
        const area = el('div.ob-restore');
        const find = async () => {
          area.textContent = ''; area.append(el('div.muted', { text: 'Ищу копию на флешке…' }));
          const devs = await B.call('usbList').catch(() => []);
          let copies = [];
          for (const d of devs) {
            const mp = d.mountpoint || await B.call('usbMount', d.path).catch(() => null);
            if (mp) copies = copies.concat(await B.call('backupList', mp).catch(() => []));
          }
          area.textContent = '';
          if (!devs.length) { area.append(el('div.muted', { text: 'Флешка не найдена. Вставьте её и нажмите «Найти» ещё раз.' })); return; }
          if (!copies.length) { area.append(el('div.muted', { text: 'На флешке нет копии ВячеславOS.' })); return; }
          copies.forEach(c => area.append(el('button.list-row.ob-copy', { onclick: async () => {
            if (!(await VOS.ui.confirm({ title: 'Восстановить эту копию?', text: 'Вернутся заметки, лекарства, родные, фото и настройки из копии от ' + new Date(c.mtime).toLocaleDateString('ru-RU') + '.', yes: 'Восстановить' }))) return;
            area.textContent = ''; area.append(el('div.muted', { text: 'Восстанавливаю…' }));
            try {
              await B.call('backupRestore', c.file);
              const st = (await B.call('storeGet', 'settings', {})) || {};
              st.setupDone = true;
              await B.call('storeSet', 'settings', st);
              VOS.speak('Готово! Ваши данные восстановлены.', { force: true });
              await VOS.ui.alert('Данные восстановлены', 'Сейчас компьютер перезапустит рабочий стол.', 'ℹ️');
              B.call('reloadShell');
            } catch (e) { area.textContent = ''; area.append(el('div.muted', { text: 'Не получилось: ' + String(e.message || e) })); }
          } }, VOS.gl('download'), el('span.grow', { text: 'Копия от ' + new Date(c.mtime).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }) }), el('span.muted', { text: VOS.fmtSize(c.size) }))));
        };
        main.append(el('h1', { text: 'Перенести ваши записи?' }),
          el('p.ob-lead', { text: 'Если у вас есть резервная копия ВячеславOS на флешке — вставьте флешку, и мы вернём заметки, лекарства, родных и фото.' }),
          el('button.btn.big', { text: '@usb', onclick: find }, 'Найти копию на флешке'), area,
          btns(back(), next('Нет, начать с чистого листа')));
        say('Если у вас есть резервная копия на флешке, её можно восстановить. Если нет — нажмите «Начать с чистого листа».');
      },
      /* 4. имя */
      () => {
        sideArt('user', 'Знакомство', 'Так помощник будет к вам обращаться');
        const name = el('input.big-input.ob-input.ob-name', { value: draft.name, placeholder: 'Ваше имя' });
        main.append(el('h1', { text: 'Как к вам обращаться?' }), name,
          el('div.muted', { text: 'Это имя будет на экране входа, и так к вам будет обращаться помощник.' }),
          btns(back(), next('Далее', async () => {
            if (!name.value.trim()) { name.focus(); VOS.ui.toast('Напишите имя'); return false; }
            draft.name = name.value.trim(); await VOS.saveSettings({ name: draft.name });
          })));
        name.addEventListener('keydown', e => { if (e.key === 'Enter') main.querySelector('.ob-next').click(); });
        say('Как к вам обращаться? Напишите имя и нажмите «Далее».');
        setTimeout(() => { name.focus(); name.select(); }, 300);
      },
      /* 5. имя компьютера */
      () => {
        sideArt('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="5" width="16" height="11" rx="1.5"/><path d="M2 19h20"/></svg>', 'Имя компьютера', 'Его увидят родные при удалённой помощи и в сообщениях');
        const first = draft.name.split(/\s+/)[0];
        const sug = ['Ноутбук ' + genitive(first), 'Компьютер ' + genitive(first), 'Домашний ноутбук', 'Дача'];
        const inp = el('input.big-input.ob-input', { value: draft.device || sug[0] });
        const chips = el('div.chip-bar', null, sug.map(x => el('button.chip', { text: x, onclick: () => { inp.value = x; } })));
        main.append(el('h1', { text: 'Как назовём компьютер?' }), inp, chips,
          btns(back(), next('Далее', async () => {
            draft.device = inp.value.trim() || sug[0];
            const r = await B.call('setHostname', draft.device).catch(() => ({}));
            await VOS.saveSettings({ deviceName: draft.device });
            if (r && r.ok === false) console.warn('hostname', r.error);
          })));
        say('Как назовём компьютер? Можно оставить как есть.');
      },
      /* 6. пароль */
      () => {
        sideArt('lock', 'Вход в компьютер', 'Пароль защищает ваши записи от чужих');
        let mode = s.noPassword ? 'none' : 'pin';
        const p1 = el('input.big-input.ob-input.ob-pin', { type: 'password', inputmode: 'numeric', placeholder: 'Придумайте пароль, например 4 цифры', maxlength: 32 });
        const p2 = el('input.big-input.ob-input.ob-pin', { type: 'password', inputmode: 'numeric', placeholder: 'Повторите пароль', maxlength: 32 });
        const show = el('label.check', null, el('input', { type: 'checkbox', onchange: e => { p1.type = p2.type = e.target.checked ? 'text' : 'password'; } }), ' Показать пароль');
        const pinBox = el('div.ob-pinbox', null, p1, p2, show, el('div.muted.small', { text: 'Запишите пароль на бумажке и отдайте родным на хранение.' }));
        const optPin = el('button.ob-opt', { onclick: () => pick('pin') }, VOS.gl('lock'), el('div', null, el('b', { text: 'С паролем' }), el('div.muted', { text: 'При включении нужно ввести цифры' })));
        const optNone = el('button.ob-opt', { onclick: () => pick('none') }, VOS.gl('arrow'), el('div', null, el('b', { text: 'Без пароля' }), el('div.muted', { text: 'Входить одним нажатием. Удобно, если компьютер только у вас дома.' })));
        function pick(m) { mode = m; optPin.classList.toggle('on', m === 'pin'); optNone.classList.toggle('on', m === 'none'); pinBox.classList.toggle('hidden', m !== 'pin'); if (m === 'pin') setTimeout(() => p1.focus(), 50); }
        main.append(el('h1', { text: 'Нужен ли пароль?' }), el('div.ob-opts', null, optPin, optNone), pinBox,
          btns(back(), next('Далее', async () => {
            if (mode === 'none') { await VOS.saveSettings({ noPassword: true }); return; }
            if (p1.value.length < 4) { VOS.ui.alert('Короткий пароль', 'Пароль должен быть хотя бы из 4 знаков.', '⚠️'); return false; }
            if (p1.value !== p2.value) { VOS.ui.alert('Пароли не совпадают', 'Введите один и тот же пароль два раза.', '⚠️'); return false; }
            await VOS.saveSettings({ noPassword: false, password: await B.call('hashPassword', p1.value) });
          })));
        pick(mode);
        say('Нужен ли пароль при включении? Если компьютером пользуетесь только вы, можно выбрать «Без пароля».');
      },
      /* 7. помощник */
      () => {
        sideArt('mic', 'Голосовой помощник', 'Говорите — компьютер ответит');
        const names = el('div.ob-opts.four');
        const paint = () => names.querySelectorAll('.ob-opt').forEach(b => b.classList.toggle('on', b.dataset.k === VOS.settings.wakeWord));
        Object.entries(VOS.WAKE_WORDS).forEach(([k, v]) => names.append(el('button.ob-opt.small', { 'data-k': k, onclick: async () => { await VOS.saveSettings({ wakeWord: k, voice: v.female ? femaleVoice : maleVoice }); paint(); say('Теперь меня зовут ' + v.name + '. Так звучит мой голос.'); } }, el('b', { text: v.name }))));
        let femaleVoice = 'anna', maleVoice = 'aleksandr';
        B.call('listVoices').then(vs => {
          const ids = vs.map(v => v.id);
          femaleVoice = ['anna', 'elena', 'irina', 'tatiana', 'arina', 'victoria'].find(x => ids.includes(x)) || ids[0] || 'anna';
          maleVoice = ['aleksandr', 'aleksandr-hq', 'mikhail', 'pavel', 'yuriy', 'vitaliy'].find(x => ids.includes(x)) || ids[0] || 'aleksandr';
        }).catch(() => {});
        const key = el('input.big-input.ob-input', { type: 'password', value: VOS.settings.groqKey, placeholder: 'Ключ Groq (gsk_…) — можно ввести позже' });
        const lead = el('p.ob-lead');
        const paintLead = () => { lead.textContent = 'Скажите имя помощника, а потом просьбу: «' + VOS.assistantName() + ', какая погода?», «' + VOS.assistantName() + ', позвони внуку». Выберите имя, которое вам нравится:'; };
        paintLead(); VOS.on('settings', paintLead); main._cleanup = () => VOS.off('settings', paintLead);
        main.append(el('h1', { text: 'Знакомьтесь — ваш помощник' }), lead,
          names,
          el('label.ob-label', { text: 'На вопросы я отвечаю через поиск Яндекса. Ключ Groq — необязательно (из России без VPN не работает)' }),
          el('div.ob-keyrow', null, key, VOS.usbKeyButton ? VOS.usbKeyButton(key, 'groq') : null),
          btns(back(), next('Далее', async () => { await VOS.saveSettings({ groqKey: key.value.trim(), wakeEnabled: true }); })));
        paint();
        say('Знакомьтесь, я ваш голосовой помощник. Чтобы спросить меня, скажите моё имя, а потом вопрос. Выберите имя, которое вам нравится.');
      },
      /* 8. внешний вид */
      () => {
        sideArt('text_size', 'Удобно читать', 'Всё можно поменять потом в Настройках');
        const sizes = el('div.ob-opts.four');
        [[1, 'Обычный'], [1.15, 'Крупный'], [1.3, 'Очень крупный'], [1.5, 'Огромный']].forEach(([v, n]) => sizes.append(el('button.ob-opt.small' + (VOS.settings.fontScale === v ? '.on' : ''), { onclick: async e => {
          await VOS.saveSettings({ fontScale: v }); sizes.querySelectorAll('.ob-opt').forEach(b => b.classList.remove('on')); e.currentTarget.classList.add('on');
        } }, el('b', { text: n, style: { fontSize: (v * 0.95) + 'em' } }))));
        const themes = el('div.ob-opts');
        [['light', 'Светлая', 'sun'], ['dark', 'Тёмная', 'moon']].forEach(([v, n, g]) => themes.append(el('button.ob-opt' + (VOS.settings.theme === v ? '.on' : ''), { onclick: async e => {
          await VOS.saveSettings({ theme: v }); themes.querySelectorAll('.ob-opt').forEach(b => b.classList.remove('on')); e.currentTarget.classList.add('on');
        } }, VOS.gl(g), el('b', { text: n }))));
        main.append(el('h1', { text: 'Размер текста' }), el('p.muted', { text: 'Выберите, как вам удобнее читать. Текст меняется сразу.' }), sizes,
          el('h2.ob-h2', { text: 'Оформление' }), themes, btns(back(), next('Далее')));
        say('Выберите размер текста — так, чтобы было удобно читать без очков.');
      },
      /* 9. готово */
      () => {
        sideArt('check', 'Всё готово', '');
        const st = VOS.settings;
        const li = (g, t) => el('li', null, VOS.gl(g), el('span', { text: t }));
        main.append(el('h1', { text: 'Всё готово, ' + st.name + '!' }),
          el('ul.ob-sum', null,
            li('globe', 'Город: ' + st.city),
            li('user', 'Имя: ' + st.name),
            li(st.noPassword ? 'arrow' : 'lock', st.noPassword ? 'Вход без пароля' : 'Вход по паролю'),
            li('mic', 'Помощник: ' + VOS.assistantName()),
            st.deviceName ? li('info', 'Компьютер: ' + st.deviceName) : null),
          el('p.ob-lead', { text: 'Хотите, я покажу, где что находится на экране? Это одна минута.' }),
          btns(back(), el('button.btn.huge', { text: 'Сразу начать', onclick: () => finish(false) }), el('button.btn.huge.primary', { text: '@sparkle', onclick: () => finish(true) }, 'Покажи мне')));
        VOS.sound.win();
        say('Всё готово, ' + st.name + '! Хотите, я покажу, где что находится на экране?');
      }
    ];

    function go(i) {
      if (main._cleanup) { main._cleanup(); main._cleanup = null; }
      idx = Math.max(0, Math.min(STEPS.length - 1, i));
      prog.style.width = (idx / (STEPS.length - 1) * 100) + '%';
      main.textContent = '';
      main.classList.remove('in'); void main.offsetWidth; main.classList.add('in');
      side.classList.remove('in'); void side.offsetWidth; side.classList.add('in');
      STEPS[idx]();
    }
    async function finish(tour) {
      VOS.stopSpeaking();
      await VOS.saveSettings({ setupDone: true });
      root.classList.add('closing');
      setTimeout(() => root.remove(), 600);
      await VOS.screens.greet();
      if (tour && VOS.tour) setTimeout(() => VOS.tour(), 500);
    }
    root.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'BUTTON') { const n = main.querySelector('.ob-next'); if (n) n.click(); } });
    go(0);
  }

  VOS.oobe = { start, genitive };
})();
