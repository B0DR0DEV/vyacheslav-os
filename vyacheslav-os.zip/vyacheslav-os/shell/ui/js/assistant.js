/*
 * assistant.js — голосовой помощник «без рук».
 *
 * Как это работает:
 *  1. Служба vos-voiced (Python + Vosk) всё время слушает микрофон и ждёт
 *     имя помощника (по умолчанию «Василиса»). Имя распознаётся на самом
 *     ноутбуке, без интернета.
 *  2. Услышав имя, служба записывает фразу до паузы и отдаёт WAV-файл.
 *     Внизу экрана появляется голосовое окошко «Слушаю…».
 *  3. Фраза распознаётся через Groq Whisper (точно), а без интернета —
 *     текстом, который служба распознала сама.
 *  4. Простые команды выполняются сразу: «позвони внуку», «доброе утро»,
 *     «включи радио Маяк», «какая погода», «громче», «прочитай»…
 *     Всё остальное — вопрос или разговор — уходит языковой модели Groq.
 *  5. Ответ виден крупным текстом и звучит голосом. Если помощник задал
 *     вопрос, он слушает ответ сам — имя повторять не нужно.
 *
 * Без службы (например, при проверке в браузере) работает кнопка
 * «Спросить помощника» и запись через микрофон браузера.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const cleanErr = e => String((e && e.message) || e).replace(/^Error invoking remote method 'vos': (Error: )?/, '');

  /* ================= имя помощника ================= */
  VOS.WAKE_WORDS = {
    'василиса': { name: 'Василиса', female: true, words: ['василиса'] },
    'компьютер': { name: 'Компьютер', female: false, words: ['компьютер'] },
    'звёздочка': { name: 'Звёздочка', female: true, words: ['звёздочка', 'звездочка'] },
    'ассистент': { name: 'Ассистент', female: false, words: ['ассистент'] }
  };
  const wake = () => VOS.WAKE_WORDS[VOS.settings.wakeWord] || { name: VOS.settings.wakeWord || 'Василиса', female: true, words: [String(VOS.settings.wakeWord || 'василиса').toLowerCase()] };
  VOS.assistantName = () => wake().name;
  VOS.gx = (f, m) => (wake().female ? f : m);   // «отправила» / «отправил»
  // «Василиса, какая погода» → «какая погода»
  function stripWake(text) {
    const stems = wake().words.map(w => w.replace(/ё/g, 'е').slice(0, Math.max(4, w.length - 2)));
    let t = String(text || '').trim();
    for (let k = 0; k < 2; k++) {
      const low = t.toLowerCase().replace(/ё/g, 'е');
      const m = low.match(/^(?:эй|привет|слушай|ну)?[\s,]*([а-яa-z-]+)[\s,.!?:;—-]*/);
      if (m && stems.some(s => m[1].startsWith(s))) t = t.slice(m[0].length).trim();
      else break;
    }
    return t.replace(/^[,.!?:;—\s-]+/, '');
  }
  VOS.stripWake = stripWake;

  /* ================= служба голоса ================= */
  const voice = VOS.voice = { state: 'off', reason: '', holds: 0 };
  voice.ready = () => voice.state === 'on';
  voice.config = () => {
    const s = VOS.settings;
    B.call('voiceCtl', { cmd: 'config', words: wake().words, sensitivity: s.wakeSens, enabled: !!s.wakeEnabled }).catch(() => {});
  };
  // освободить микрофон (видеозвонок, голосовая заметка) — возвращает функцию «вернуть»
  voice.hold = () => {
    voice.holds++;
    if (voice.holds === 1) B.call('voiceCtl', { cmd: 'pause' }).catch(() => {});
    let done = false;
    return () => { if (done) return; done = true; voice.holds = Math.max(0, voice.holds - 1); if (!voice.holds) B.call('voiceCtl', { cmd: 'resume' }).catch(() => {}); };
  };
  VOS.on('speaking', on => B.call('voiceCtl', { cmd: 'speaking', on }).catch(() => {}));
  VOS.on('settings', () => voice.config());

  /* ================= запись через микрофон браузера (запасной путь) ================= */
  VOS.recordAudio = async function ({ maxMs = 15000, vad = false, onLevel } = {}) {
    const release = voice.hold();
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
    catch (e) { release(); throw e; }
    const mime = window.MediaRecorder && MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : '';
    const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
    const chunks = [];
    rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    let resolveStop; const done = new Promise(r => { resolveStop = r; });
    rec.onstop = () => { stream.getTracks().forEach(t => t.stop()); release(); resolveStop(new Blob(chunks, { type: 'audio/webm' })); };
    rec.start(250);
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const an = ctx.createAnalyser(); an.fftSize = 1024;
    ctx.createMediaStreamSource(stream).connect(an);
    const buf = new Float32Array(an.fftSize);
    const t0 = Date.now();
    let noise = 0, noiseN = 0, spoke = false, lastVoice = Date.now(), stopped = false;
    const iv = setInterval(() => {
      an.getFloatTimeDomainData(buf);
      let s = 0; for (let i = 0; i < buf.length; i++) s += buf[i] * buf[i];
      const rms = Math.sqrt(s / buf.length);
      if (Date.now() - t0 < 400) { noise += rms; noiseN++; }       // первые 0,4 с — фоновый шум
      const thr = Math.max(0.015, (noiseN ? noise / noiseN : 0.01) * 3);
      if (onLevel) onLevel(Math.min(1, rms / (thr * 4)));
      if (rms > thr) { spoke = true; lastVoice = Date.now(); }
      if (vad && spoke && Date.now() - lastVoice > 1400) stop();
      if (vad && !spoke && Date.now() - t0 > 8000) stop();
      if (Date.now() - t0 > maxMs) stop();
    }, 100);
    function stop() {
      if (stopped) return done; stopped = true;
      clearInterval(iv); ctx.close().catch(() => {});
      if (rec.state !== 'inactive') rec.stop();
      return done;
    }
    return { stop, done, spoke: () => spoke };
  };

  async function contactNames() {
    const c = await VOS.store.get('contacts', []);
    return c.map(x => x.name).filter(Boolean);
  }
  async function whisperPrompt() {
    return wake().name + ', позвони ' + (await contactNames()).join(', ') + '. Какая погода? Включи радио.';
  }
  async function transcribeBlob(blob) {
    const buf = await blob.arrayBuffer();
    const r = await B.call('aiTranscribe', { key: VOS.settings.groqKey, data: buf, mime: 'audio/webm', prompt: await whisperPrompt() });
    return (r.text || '').trim();
  }
  // команда от службы: сначала Groq Whisper, без него — текст самой службы
  async function transcribeCommand(ev) {
    let text = '';
    if (VOS.settings.groqKey && ev.wav && ev.wav !== 'mock') {
      try { text = (await B.call('aiTranscribe', { key: VOS.settings.groqKey, filePath: ev.wav, prompt: await whisperPrompt() })).text || ''; }
      catch (_) { text = ''; }
    }
    if (!text.trim()) text = ev.text || '';
    if (ev.wav) B.call('voiceCleanup', ev.wav).catch(() => {});
    return text.trim();
  }

  /* ================= разбор простых команд ================= */
  const norm = t => t.toLowerCase().replace(/ё/g, 'е').replace(/[.,!?;:«»"()]/g, ' ').replace(/\s+/g, ' ').trim();
  function findApp(phrase) {
    const p = norm(phrase);
    let best = null, bestLen = 0;
    for (const a of VOS.apps) {
      for (const wd of [a.title, ...(a.words || [])]) {
        const w = norm(wd);
        if (p.includes(w) && w.length > bestLen) { best = a; bestLen = w.length; }
      }
    }
    return best;
  }
  const NUMS = { 'один': 1, 'одну': 1, 'два': 2, 'две': 2, 'три': 3, 'четыре': 4, 'пять': 5, 'шесть': 6, 'семь': 7, 'восемь': 8, 'девять': 9, 'десять': 10, 'одиннадцать': 11, 'двенадцать': 12, 'пятнадцать': 15, 'двадцать': 20, 'тридцать': 30, 'сорок': 40, 'полчаса': 30 };
  const num = s => /^\d+$/.test(s) ? +s : NUMS[s];

  async function localCommand(text) {
    const t = norm(text);
    let m;
    // окно будильника или напоминания на экране — ответить голосом
    const alarmBox = VOS.$('.alarm-overlay');
    if (alarmBox) {
      if (/(отлож|через|попозже|позже|напомни)/.test(t)) { const b = alarmBox.querySelector('.btn:not(.primary)'); if (b) b.click(); return { say: 'Хорошо, напомню попозже.' }; }
      if (/(принял|выпил|выключи|хорошо|стоп|спасибо|понял|сделал|да)/.test(t)) { const b = alarmBox.querySelector('.btn.primary'); if (b) b.click(); return { say: 'Хорошо, ' + VOS.gx('отметила', 'отметил') + '.' }; }
    }
    if (/^(стоп|хватит|замолчи|молчи|тихо|спасибо|ничего|отбой|все спасибо)$/.test(t)) { VOS.stopSpeaking(); return { say: '', quiet: true }; }
    if (/(научи|обучени|как пользоваться|что где на экране|экскурси|покажи как)/.test(t)) { VOS.wm.open('learn'); return { say: 'Открываю обучение. Выберите урок.' }; }
    if ((m = t.match(/(?:позвони|набери|вызови|звони|свяжи(?:сь)? с|видеозвонок|видео звонок|позвонить)\s+(.+)/)) && VOS.contacts) return VOS.contacts.callByPhrase(m[1]);
    if (/(помоги|помогите|помощь|не получается|не работает|не могу|сломал|завис).*(компьютер|ноутбук|интернет|экран|программ)|позови.*помо|удаленн[а-яё]* помощ/.test(t) && VOS.help) return VOS.help.request();
    if (/^(доброе утро|что нового|утренн[а-яё]* сводк[а-яё]*|сводк[а-яё]*|что у меня сегодня|какие планы на сегодня|расскажи что сегодня|что сегодня)(\s|$)/.test(t) && VOS.briefing) return VOS.briefing.run({ open: true });
    if (/(расскажи|прочитай|какие|что в|главные|последние)\s+([а-яё]+\s+)?новост/.test(t) && VOS.briefing) return VOS.briefing.headlinesReply();
    if (/(сколько|хватит|заканчива|кончаются|кончились).*(таблет|лекарств)|(таблет|лекарств).*(заканчива|осталось|кончаются)/.test(t) && VOS.meds && VOS.meds.stockReply) return VOS.meds.stockReply();
    if (/(у кого|когда|скоро ли).*(день рождени|днюх)|дни рождени/.test(t) && VOS.contacts) return VOS.contacts.birthdaysReply();
    if (/^(прочитай|прочти|читай|почитай)( вслух)?( (это|страницу|статью|текст|мне))*$/.test(t) && VOS.readAloud) return VOS.readAloud();
    if (/(показани|счетчик)/.test(t)) { VOS.wm.open('meters'); return { say: 'Открываю счётчики.' }; }
    if (/(выключи|выключить|отключи) (компьютер|ноутбук|систему)/.test(t)) { setTimeout(() => VOS.wm.askPower('poweroff'), 300); return { say: 'Хорошо. Подтвердите выключение на экране.' }; }
    if (/перезагрузи/.test(t)) { setTimeout(() => VOS.wm.askPower('reboot'), 300); return { say: 'Подтвердите перезагрузку на экране.' }; }
    if (/(громче|погромче|прибавь звук|сделай громче)/.test(t)) { const v = await B.call('getVolume'); await B.call('setVolume', Math.min(100, v.volume + 15)); VOS.wm.updateTray(); return { say: 'Прибавляю звук.' }; }
    if (/(тише|потише|убавь звук|сделай тише)/.test(t)) { const v = await B.call('getVolume'); await B.call('setVolume', Math.max(10, v.volume - 15)); VOS.wm.updateTray(); return { say: 'Убавляю звук.' }; }
    if (/(который час|сколько времени|сколько время|какое время)/.test(t)) return { say: 'Сейчас ' + VOS.timeWords(new Date()) + '.' };
    if (/(какое сегодня число|какой сегодня день|какое число|какая сегодня дата|какой день недели)/.test(t)) {
      const d = new Date(), h = VOS.todayHoliday();
      return { say: 'Сегодня ' + VOS.WEEKDAYS[d.getDay()] + ', ' + d.getDate() + ' ' + VOS.MONTHS[d.getMonth()] + ' ' + d.getFullYear() + ' года.' + (h ? ' Праздник: ' + h + '.' : '') };
    }
    if (/погод/.test(t) && !/(почему|отчего|как устроен)/.test(t)) {
      VOS.wm.open('weather');
      try { return { say: VOS.weather.summary(await VOS.weather.get(VOS.settings.city)) }; }
      catch (_) { return { say: 'Открываю погоду. Похоже, нет интернета.' }; }
    }
    if ((m = t.match(/(разбуди|поставь будильник|заведи будильник|будильник)( меня)?( завтра)? (в|на) (\d{1,2}|[а-я]+)(?:[ :](\d{2}))?/))) {
      const h = num(m[5]), mm = m[6] ? +m[6] : 0;
      if (h != null && h < 24) {
        const time = VOS.pad(h) + ':' + VOS.pad(mm);
        const alarms = await VOS.store.get('alarms', []);
        alarms.push({ id: VOS.uid(), time, label: 'Будильник', days: [], enabled: true });
        await VOS.store.set('alarms', alarms);
        return { say: 'Будильник заведён на ' + h + ' ' + VOS.plural(h, 'час', 'часа', 'часов') + (mm ? ' ' + mm + ' минут' : '') + '.' };
      }
    }
    if ((m = t.match(/таймер( на)? (\d+|[а-я]+)( минут[уы]?)?/))) { VOS.wm.open('stopwatch', { timer: true }); return { say: 'Открываю таймер. Выберите время и нажмите «Запустить».' }; }
    if ((m = t.match(/^(?:включи|поставь|открой|запусти|давай)? ?радио ?(.*)$/))) {
      const q = m[1].replace(/^(станцию|волну)\s*/, '').trim();
      VOS.wm.open('radio', q ? { query: q } : {});
      return { say: q ? 'Включаю радио ' + q + '.' : 'Открываю радио. Выберите станцию.' };
    }
    if ((m = t.match(/(?:найди|покажи|включи|поставь|хочу посмотреть)\s+(?:мне\s+)?(?:видео|фильм|ролик|кино)\s*(?:про|о|об|с|со)?\s*(.*)$/))) {
      VOS.wm.open('video', m[1] ? { query: m[1] } : {});
      return { say: m[1] ? 'Ищу видео: ' + m[1] + '.' : 'Открываю видео.' };
    }
    if ((m = t.match(/(?:найди|поищи|загугли)\s+(?:в интернете|в яндексе|в поиске)\s+(.+)$/))) { VOS.wm.open('search', { query: m[1] }); return { say: 'Ищу в интернете.' }; }
    if ((m = t.match(/(?:включи|покажи|открой)\s+(?:канал\s+)?(первый канал|россия 1|россия 24|россию 24|россию|культур|нтв|звезд|тв центр|пятый канал|мир|отр)/))) {
      VOS.wm.open('tv', { query: m[1].replace('россию', 'россия').replace('культур', 'культура').replace('звезд', 'звезда') });
      return { say: 'Включаю телевизор.' };
    }
    if (/закрой (все|всё)( окна| программы)?/.test(t)) { VOS.wm.closeAll(); return { say: 'Все окна закрыты.' }; }
    if (/^закрой( окно| это| программу)?$/.test(t)) { const w = VOS.wm.top(); if (w) VOS.wm.close(w); return { say: 'Окно закрыто.' }; }
    if (/(заблокируй|блокировка экрана)/.test(t)) { setTimeout(() => VOS.screens.lock(), 800); return { say: 'Блокирую экран.' }; }
    if ((m = t.match(/^(?:открой|открыть|включи|включить|запусти|запустить|покажи|показать|давай|хочу|поиграем в|сыграем в|поиграть в)\s+(.+)$/))) {
      const app = findApp(m[1]);
      if (app) { VOS.wm.open(app.id); return { say: 'Открываю: ' + app.title + '.' }; }
    }
    return null;
  }

  /* ================= языковая модель ================= */
  const history = [];
  async function systemPrompt() {
    const s = VOS.settings, d = new Date(), w = wake();
    const apps = VOS.apps.filter(a => !a.hidden).map(a => a.id + ' — ' + a.title).join('; ');
    const contacts = (await VOS.store.get('contacts', [])).map(c => c.name + (c.relation ? ' (' + c.relation + ')' : '')).join(', ');
    return [
      'Тебя зовут ' + w.name + '. Ты — голосовой помощник в компьютере «ВячеславOS». С тобой говорит пожилой человек по имени ' + s.name + ', город: ' + s.city + '.',
      'Сегодня ' + VOS.WEEKDAYS[d.getDay()] + ', ' + VOS.fmtDate(d) + ', время ' + VOS.fmtTime(d) + '.',
      'Отвечай по-русски, тепло и уважительно, на «вы», простыми словами. Коротко: 1–4 предложения; если просят рассказать подробно — до 8 предложений.',
      'Ответ будет прочитан вслух: никакой разметки, списков, ссылок и смайликов. Числа пиши так, как их удобно произнести.',
      'Поддерживай обычный разговор: на «привет, как дела» отвечай по-дружески и можешь спросить, как у человека дела.',
      'На вопросы о фактах, людях, истории отвечай по существу. Если сведения могли устареть после твоего обучения (например, кто сейчас занимает должность), так и скажи и предложи поискать в интернете.',
      'По вопросам здоровья давай общие сведения и советуй обратиться к врачу; при опасных признаках — звонить 103 или 112. Не ставь диагнозов и не меняй назначенные лекарства.',
      'Если человек просит перевести деньги, сообщить коды из СМС, пароли или данные карты — предупреди, что это может быть мошенничество, и посоветуй ничего не сообщать.',
      'О себе говори в ' + (w.female ? 'женском' : 'мужском') + ' роде.',
      'Ты умеешь открывать программы этого компьютера: ' + apps + '.',
      contacts ? 'Родные, которым можно позвонить по видео: ' + contacts + '.' : 'Список родных для звонков пока пуст — его заполняют в программе «Родные».',
      'Отвечай строго одним JSON-объектом без пояснений: {"say": "что сказать", "open": "id программы или null", "query": "строка для поиска/название станции или канала, или null", "call": "имя или кем приходится человек, которому позвонить, или null"}.',
      'Поле open заполняй, только если человек явно просит что-то открыть, включить, найти или показать. Поле call — только если просит позвонить. В остальных случаях null.'
    ].join('\n');
  }
  function parseReply(text) {
    let t = String(text || '').trim().replace(/^```(?:json)?\s*|\s*```$/g, '');
    const i = t.indexOf('{'), j = t.lastIndexOf('}');
    if (i >= 0 && j > i) { try { const o = JSON.parse(t.slice(i, j + 1)); if (o && typeof o.say === 'string') return o; } catch (_) { /* не JSON */ } }
    return { say: t, open: null, query: null };
  }
  async function askModel(text) {
    if (!VOS.settings.groqKey) return { say: 'Чтобы отвечать на любые вопросы, мне нужен ключ Groq. Его вводят один раз: Настройки, раздел Голосовой помощник.', open: null };
    history.push({ role: 'user', content: text });
    while (history.length > 12) history.shift();
    const r = await B.call('aiChat', { key: VOS.settings.groqKey, model: VOS.settings.groqModel, json: true, messages: [{ role: 'system', content: await systemPrompt() }, ...history] });
    const o = parseReply(r.text);
    history.push({ role: 'assistant', content: o.say });
    if (o.call && VOS.contacts) {
      const c = await VOS.contacts.callByPhrase(String(o.call));
      return c.pending ? c : { ...c, say: c.say || o.say };
    }
    if (o.open && VOS.app(o.open)) VOS.wm.open(o.open, o.query ? { query: o.query } : {});
    return o;
  }

  /* ================= голосовое окошко (внизу экрана) ================= */
  let hud = null, hudOrb, hudStatus, hudYou, hudAnswer, hudTimer = null;
  function buildHud() {
    hudOrb = el('div.vh-orb', null, el('i'), el('i'), el('i'));
    hudStatus = el('div.vh-status');
    hudYou = el('div.vh-you');
    hudAnswer = el('div.vh-answer');
    hud = el('div#voice-hud', null, hudOrb, el('div.vh-text', null, hudStatus, hudYou, hudAnswer),
      el('button.wb.vh-close', { text: '@close', title: 'Закрыть', onclick: e => { e.stopPropagation(); hudHide(true); } }));
    hud.addEventListener('click', () => show(false));
    document.body.append(hud);
  }
  function hudShow(state, { status, you, answer } = {}) {
    if (!hud) buildHud();
    clearTimeout(hudTimer);
    hud.className = 'show ' + state;
    if (status !== undefined) hudStatus.textContent = status;
    if (you !== undefined) hudYou.textContent = you ? '«' + you + '»' : '';
    if (answer !== undefined) hudAnswer.textContent = answer || '';
  }
  function hudLevel(v) { if (hudOrb) hudOrb.style.setProperty('--lvl', (1 + v * 0.6).toFixed(2)); }
  function hudHide(stopAll) {
    clearTimeout(hudTimer);
    if (hud) hud.className = '';
    if (stopAll) { VOS.stopSpeaking(); B.call('voiceCtl', { cmd: 'cancel' }).catch(() => {}); pending = null; }
  }
  function hudHideLater(ms = 7000) { clearTimeout(hudTimer); hudTimer = setTimeout(() => hudHide(false), ms); }

  /* ================= панель с историей разговора ================= */
  const log = [];
  let panel = null, chat, micBtn, input, level;
  function addLog(who, text) {
    log.push({ who, text }); if (log.length > 60) log.shift();
    if (chat) { chat.append(el('div.bubble.' + who, { text })); chat.scrollTop = chat.scrollHeight; }
  }
  function buildPanel() {
    chat = el('div.as-chat');
    level = el('div.as-level');
    micBtn = el('button.as-mic', { title: 'Нажмите и говорите' }, el('span', { html: VOS.glyph('mic') }), level);
    input = el('input.big-input.grow', { placeholder: 'Или напишите вопрос здесь…' });
    const ask = () => { if (input.value.trim()) { const t = input.value; input.value = ''; handle(t, { typed: true }); } };
    input.addEventListener('keydown', e => { if (e.key === 'Enter') ask(); });
    micBtn.onclick = () => listen();
    const hint = el('span.muted.small');
    const updHint = () => { hint.textContent = voice.ready() && VOS.settings.wakeEnabled ? 'Скажите «' + wake().name + '» и вопрос — или нажмите на микрофон' : 'Нажмите на микрофон и скажите, например: «включи радио Маяк»'; };
    updHint(); VOS.on('settings', updHint); VOS.on('voice-state', updHint);
    panel = el('div.assistant.hidden', null,
      el('div.as-head', null, el('span.as-logo', { html: VOS.logoSVG(30) }), el('b', { text: wake().name }), hint, el('span.spacer'),
        el('button.wb.wb-close', { text: '@close', title: 'Закрыть', onclick: hide })),
      chat,
      el('div.as-input', null, micBtn, input, el('button.btn.primary', { text: 'Спросить', onclick: ask })));
    document.body.append(panel);
    if (!log.length) addLog('bot', VOS.greeting() + ', ' + VOS.settings.name + '! Я ' + wake().name + '. Спросите что угодно или попросите открыть программу.');
    else log.forEach(x => chat.append(el('div.bubble.' + x.who, { text: x.text })));
  }
  function show(autoListen) {
    if (!panel) buildPanel();
    panel.classList.remove('hidden');
    VOS.wm.closeStart(); VOS.wm.closePopups();
    hudHide(false);
    if (autoListen) listen();
  }
  function hide() { if (panel) panel.classList.add('hidden'); VOS.stopSpeaking(); }

  /* ================= разговор ================= */
  let pending = null;             // уточняющий вопрос («Кому позвонить: Саше или Мише?»)
  let busy = false;
  let dictateCb = null;
  let retriedEmpty = false;

  function setMic(on) { if (micBtn) micBtn.classList.toggle('on', on); }

  // кнопка микрофона: через службу, а если её нет — через браузер
  async function listen() {
    VOS.stopSpeaking();
    if (voice.ready()) {
      B.call('voiceCtl', { cmd: 'listen', reason: 'button', timeout: 8 }).catch(() => {});
      hudShow('listening', { status: 'Слушаю…', you: '', answer: '' });
      setMic(true);
      return;
    }
    if (!VOS.settings.groqKey) { addLog('bot', 'Для распознавания голоса нужен ключ Groq (Настройки → Голосовой помощник). Пока можно писать вопросы в строке внизу.'); if (!panel || panel.classList.contains('hidden')) show(false); return; }
    if (busy) return;
    busy = true; setMic(true);
    hudShow('listening', { status: 'Слушаю…', you: '', answer: '' });
    try {
      const rec = await VOS.recordAudio({ vad: true, maxMs: 20000, onLevel: v => { hudLevel(v); if (level) level.style.transform = 'scale(' + (1 + v * 0.8) + ')'; } });
      const blob = await rec.done;
      setMic(false);
      if (!rec.spoke()) { hudShow('answer', { status: '', answer: 'Ничего не слышно. Попробуйте погромче.' }); hudHideLater(4000); return; }
      hudShow('thinking', { status: 'Распознаю…' });
      const text = stripWake(await transcribeBlob(blob));
      if (!text) { hudShow('answer', { status: '', answer: 'Слова не разобрать. Попробуйте ещё раз.' }); hudHideLater(4000); return; }
      busy = false;
      await handle(text, { voice: true });
    } catch (e) {
      hudShow('answer', { status: '', answer: /Permission|NotAllowed|NotFound|device/i.test(String(e)) ? 'Микрофон недоступен. Проверьте, что он включён.' : cleanErr(e) });
      hudHideLater(5000);
    } finally { busy = false; setMic(false); }
  }

  async function handle(text, { voice: byVoice = false, typed = false } = {}) {
    if (byVoice && VOS.screens.isLocked && VOS.screens.isLocked()) {
      if (!VOS.settings.voiceOnLock) return;
      VOS.screens.unlockQuiet();
    }
    addLog('me', text);
    hudShow('thinking', { status: 'Думаю…', you: text, answer: '' });
    let res = null;
    try {
      if (pending) { const p = pending; pending = null; res = await p(text); }
      if (!res) res = (await localCommand(text)) || (await askModel(text));
    } catch (e) { res = { say: cleanErr(e) }; }
    if (!res || res.quiet) { hudHide(false); return; }
    pending = res.pending || null;
    const say = res.say || '';
    if (say) addLog('bot', say);
    hudShow('answer', { status: wake().name, answer: say || 'Готово.' });
    if (typed && panel && !panel.classList.contains('hidden')) hudHide(false);
    if (say) await VOS.speak(say, { force: true });
    // продолжить разговор без имени: если задан вопрос
    const askBack = pending || /\?\s*$/.test(say);
    if (byVoice && voice.ready() && VOS.settings.followUp && askBack) {
      B.call('voiceCtl', { cmd: 'listen', reason: 'followup', timeout: pending ? 8 : 6 }).catch(() => {});
      hudShow('listening followup', { status: 'Слушаю ответ…' });
    } else hudHideLater(say.length > 200 ? 12000 : 7000);
  }

  /* ================= события службы ================= */
  B.on('voice', async ev => {
    switch (ev.type) {
      case 'ready':
        voice.state = 'on'; voice.reason = ''; voice.config(); VOS.emit('voice-state', voice);
        break;
      case 'state':
        voice.state = ev.state; voice.reason = ev.reason || ''; VOS.emit('voice-state', voice);
        break;
      case 'wake':
        if (!VOS.settings.wakeEnabled) return;
        if (VOS.screens.isLocked && VOS.screens.isLocked() && !VOS.settings.voiceOnLock) return;
        VOS.stopSpeaking();
        B.call('screenWake').catch(() => {});
        retriedEmpty = false;
        hudShow('listening', { status: 'Слушаю…', you: '', answer: '' });
        if (!ev.early) VOS.sound.click();
        break;
      case 'wake_cancel':
        if (hud && hud.classList.contains('listening')) hudHide(false);
        break;
      case 'listening':
        hudShow('listening' + (ev.reason === 'followup' ? ' followup' : ''), { status: ev.reason === 'followup' ? 'Слушаю ответ…' : ev.reason === 'dictate' ? 'Говорите, я записываю…' : 'Слушаю…' });
        break;
      case 'level':
        hudLevel(ev.value || 0);
        break;
      case 'timeout':
        setMic(false);
        if (ev.reason === 'dictate' && dictateCb) { const cb = dictateCb; dictateCb = null; cb(null); return; }
        if (ev.reason === 'followup') { pending = null; hudHide(false); return; }
        hudShow('answer', { status: '', you: '', answer: 'Я вас не ' + VOS.gx('расслышала', 'расслышал') + '. Скажите ещё раз.' });
        hudHideLater(3500);
        break;
      case 'command': {
        setMic(false);
        if (ev.reason === 'dictate') {
          const cb = dictateCb; dictateCb = null;
          const t = await transcribeCommand(ev);
          if (cb) cb(t);
          return;
        }
        hudShow('thinking', { status: 'Распознаю…' });
        const raw = await transcribeCommand(ev);
        const text = stripWake(raw);
        if (!text) {
          // сказали только имя — ждём саму просьбу один раз
          if (!retriedEmpty) { retriedEmpty = true; B.call('voiceCtl', { cmd: 'listen', reason: 'wake2', timeout: 7 }).catch(() => {}); hudShow('listening', { status: 'Слушаю…' }); }
          else hudHide(false);
          return;
        }
        handle(text, { voice: true });
        break;
      }
      case 'error':
        if (ev.fatal) { voice.state = 'unavailable'; voice.reason = ev.text; VOS.emit('voice-state', voice); }
        break;
    }
  });

  /* ================= диктовка для полей ввода (заметки, поиск, дела) ================= */
  async function dictate(cb) {
    if (voice.ready()) {
      VOS.stopSpeaking();
      const o = VOS.ui.overlay('dictate');
      const done = t => { o.remove(); if (t) cb(stripWake(t)); else VOS.ui.toast('Ничего не слышно'); };
      dictateCb = done;
      o.append(el('div.dialog', null, el('div.as-mic.on', null, el('span', { html: VOS.glyph('mic') })), el('h2', { text: 'Говорите…' }), el('p.muted', { text: 'Запись остановится сама, когда вы замолчите.' }),
        el('div.dialog-btns', null, el('button.btn.huge', { text: 'Отмена', onclick: () => { dictateCb = null; o.remove(); B.call('voiceCtl', { cmd: 'cancel' }).catch(() => {}); } }))));
      B.call('voiceCtl', { cmd: 'listen', reason: 'dictate', timeout: 8 }).catch(() => {});
      return;
    }
    if (!VOS.settings.groqKey) return VOS.ui.alert('Нужен ключ помощника', 'Для распознавания голоса введите ключ Groq: Настройки → Голосовой помощник.', '🎤');
    const o = VOS.ui.overlay('dictate');
    const lvl = el('div.as-level');
    const stopBtn = el('button.btn.huge.primary', { text: '⏹ Готово' });
    o.append(el('div.dialog', null, el('div.as-mic.on', null, el('span', { html: VOS.glyph('mic') }), lvl), el('h2', { text: 'Говорите…' }), el('p.muted', { text: 'Запись остановится сама, когда вы замолчите.' }), el('div.dialog-btns', null, stopBtn)));
    try {
      const rec = await VOS.recordAudio({ vad: true, maxMs: 60000, onLevel: v => { lvl.style.transform = 'scale(' + (1 + v * 0.8) + ')'; } });
      stopBtn.onclick = () => rec.stop();
      const blob = await rec.done;
      o.querySelector('h2').textContent = 'Распознаю…';
      const t = rec.spoke() ? await transcribeBlob(blob) : '';
      o.remove();
      if (t) cb(t); else VOS.ui.toast('Ничего не слышно');
    } catch (e) { o.remove(); VOS.ui.alert('Не получилось', cleanErr(e), '🎤'); }
  }

  /* ================= сказать и показать (для сводки, напоминаний) ================= */
  async function announce(text, { title } = {}) {
    if (!text) return;
    addLog('bot', text);
    hudShow('answer', { status: title || wake().name, you: '', answer: text });
    await VOS.speak(text, { force: true });
    hudHideLater(text.length > 200 ? 10000 : 6000);
  }

  VOS.assistant = { show, hide, handle, dictate, localCommand, parseReply, stripWake, announce, listen };

  document.addEventListener('DOMContentLoaded', () => {
    VOS.$('#assist-btn').onclick = () => { if (panel && !panel.classList.contains('hidden')) hide(); else show(true); };
    document.addEventListener('keydown', e => { if (e.key === 'F12' || (e.ctrlKey && e.code === 'Space')) { e.preventDefault(); show(true); } });
    B.call('voiceCtl', { cmd: 'status' }).then(st => { if (st && st.state) { voice.state = st.state; voice.reason = st.reason || ''; if (voice.ready()) voice.config(); VOS.emit('voice-state', voice); } }).catch(() => {});
  });
})();
