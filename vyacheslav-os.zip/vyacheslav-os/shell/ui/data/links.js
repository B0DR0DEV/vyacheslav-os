/*
 * links.js — сайты, каналы и радиостанции. Этот файл можно спокойно
 * править: добавить свой любимый сайт или канал. Адреса сайтов иногда
 * меняются — если какой-то канал перестал открываться, поправьте ссылку здесь.
 * В установленной системе файл лежит в /opt/vos/shell/ui/data/links.js
 */
window.VOS_LINKS = {
  news: [
    { name: 'РИА Новости', url: 'https://ria.ru/' },
    { name: 'ТАСС', url: 'https://tass.ru/' },
    { name: 'Российская газета', url: 'https://rg.ru/' },
    { name: 'Лента.ру', url: 'https://lenta.ru/' },
    { name: 'РБК', url: 'https://www.rbc.ru/' },
    { name: 'Аргументы и факты', url: 'https://aif.ru/' },
    { name: 'Известия', url: 'https://iz.ru/' }
  ],
  tv: [
    { name: 'Первый канал', url: 'https://www.1tv.ru/live' },
    { name: 'Россия 1', url: 'https://smotrim.ru/channel/1' },
    { name: 'Россия 24', url: 'https://smotrim.ru/channel/3' },
    { name: 'Россия К (Культура)', url: 'https://smotrim.ru/channel/4' },
    { name: 'НТВ', url: 'https://www.ntv.ru/air/' },
    { name: 'Звезда', url: 'https://tvzvezda.ru/video/' },
    { name: 'ТВ Центр', url: 'https://www.tvc.ru/air' },
    { name: 'Пятый канал', url: 'https://www.5-tv.ru/live/' },
    { name: 'Мир', url: 'https://mirtv.ru/live/' },
    { name: 'ОТР', url: 'https://otr-online.ru/online/' }
  ],
  // заголовки для утренней сводки («Василиса, расскажи новости»)
  newsRss: [
    { name: 'РИА Новости', url: 'https://ria.ru/export/rss2/archive/index.xml' },
    { name: 'Лента.ру', url: 'https://lenta.ru/rss/news' },
    { name: 'ТАСС', url: 'https://tass.ru/rss/v2.xml' }
  ],
  video: {
    rutube: 'https://rutube.ru/search/?query={q}',
    rutubeHome: 'https://rutube.ru/',
    vk: 'https://vkvideo.ru/?q={q}',
    vkHome: 'https://vkvideo.ru/'
  },
  search: {
    engines: [
      { name: 'Яндекс', url: 'https://ya.ru/search/?text={q}', home: 'https://ya.ru/' },
      { name: 'Mail.ru', url: 'https://go.mail.ru/search?q={q}', home: 'https://go.mail.ru/' },
      { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q={q}', home: 'https://duckduckgo.com/' }
    ]
  },
  // Радио: адреса потоков ищутся в открытом каталоге radio-browser.info по названию,
  // поэтому даже если станция сменит адрес потока, она продолжит играть.
  radio: [
    { name: 'Радио России', query: 'Радио России', icon: '🇷🇺' },
    { name: 'Маяк', query: 'Маяк', icon: '⚓' },
    { name: 'Ретро FM', query: 'Ретро FM', icon: '🎙' },
    { name: 'Русское Радио', query: 'Русское Радио', icon: '🎵' },
    { name: 'Радио Шансон', query: 'Шансон', icon: '🎸' },
    { name: 'Авторадио', query: 'Авторадио', icon: '🚗' },
    { name: 'Радио Дача', query: 'Радио Дача', icon: '🏡' },
    { name: 'Вести FM', query: 'Вести ФМ', icon: '📰' },
    { name: 'Орфей (классика)', query: 'Орфей', icon: '🎻' },
    { name: 'Европа Плюс', query: 'Европа Плюс', icon: '🌍' },
    { name: 'Юмор FM', query: 'Юмор FM', icon: '😄' },
    { name: 'Радио Звезда', query: 'Радио Звезда', icon: '⭐' }
  ],
  radioApi: ['https://de1.api.radio-browser.info', 'https://nl1.api.radio-browser.info', 'https://fi1.api.radio-browser.info', 'https://at1.api.radio-browser.info']
};
