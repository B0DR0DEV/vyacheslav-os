'use strict';
/*
 * fsops.js — «Мои файлы»: папки, флешки, копирование, корзина, новые
 * документы, открытие файлов нужной программой, батарея.
 *
 * Безопасность: оболочка может работать ТОЛЬКО с папками пользователя
 * (Документы, Загрузки, Фото, Голосовые заметки, Корзина) и с флешками
 * в /media и /run/media. Системные файлы и настройки недоступны.
 */
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const path = require('path');
const { spawn, execFile } = require('child_process');

const HOME = os.homedir();
const DIRS = {
  docs: path.join(HOME, 'Документы'),
  downloads: path.join(HOME, 'Загрузки'),
  photos: path.join(HOME, 'Фото'),
  voice: path.join(HOME, 'Голосовые заметки')
};
const TRASH = path.join(HOME, '.local', 'share', 'vos-trash');
const TRASH_INDEX = path.join(TRASH, '.index.json');
const TEMPLATES = path.join(__dirname, 'templates');
for (const d of [...Object.values(DIRS), TRASH]) { try { fs.mkdirSync(d, { recursive: true }); } catch (_) { /* */ } }

const ROOT_NAMES = { docs: 'Документы', downloads: 'Загрузки', photos: 'Фото', voice: 'Голосовые заметки' };
const MEDIA_ROOTS = ['/media', '/run/media'];

/* ---------- проверка путей ---------- */
function within(p, root) { return p === root || p.startsWith(root + path.sep); }
function allowedRoots() { return [...Object.values(DIRS), TRASH, ...MEDIA_ROOTS]; }
// Путь должен лежать внутри разрешённых папок (с учётом ссылок)
async function safe(p, { mustExist = true } = {}) {
  if (typeof p !== 'string' || !p.startsWith('/') || p.includes('\0')) throw new Error('Неверный путь');
  let real;
  try { real = await fsp.realpath(p); }
  catch (e) {
    if (mustExist) throw new Error('Файл не найден');
    real = path.join(await fsp.realpath(path.dirname(p)), path.basename(p));
  }
  if (!allowedRoots().some(r => within(real, r))) throw new Error('Сюда нельзя');
  return real;
}
function cleanName(n) {
  n = String(n || '').replace(/[\/\0]/g, '').replace(/^\.+/, '').trim().slice(0, 200);
  if (!n) throw new Error('Пустое имя');
  return n;
}
async function exists(p) { try { await fsp.lstat(p); return true; } catch (_) { return false; } }
// «Письмо.docx» → «Письмо (2).docx», если такое уже есть
async function uniquePath(dir, name) {
  const ext = path.extname(name), base = name.slice(0, name.length - ext.length);
  let p = path.join(dir, name), i = 2;
  while (await exists(p)) p = path.join(dir, base + ' (' + (i++) + ')' + ext);
  return p;
}

/* ---------- флешки ---------- */
let sys = null;   // system.js (usbList/usbMount/usbUnmount) — подключается из main.js
function attach(system) { sys = system; }
async function usbRoots() {
  if (!sys) return [];
  const out = [];
  for (const d of await sys.usbList().catch(() => [])) {
    const mp = d.mountpoint || await sys.usbMount(d.path).catch(() => null);
    if (!mp) continue;
    let free = null, total = null;
    try { const st = await fsp.statfs(mp); free = st.bavail * st.bsize; total = st.blocks * st.bsize; } catch (_) { /* */ }
    out.push({ id: 'usb:' + d.path, kind: 'usb', dev: d.path, name: d.label || 'Флешка', path: mp, free, total });
  }
  return out;
}
async function roots() {
  const home = Object.entries(ROOT_NAMES).map(([id, name]) => ({ id, kind: 'home', name, path: DIRS[id] }));
  home.push({ id: 'trash', kind: 'trash', name: 'Корзина', path: TRASH });
  return [...home, ...(await usbRoots())];
}
async function eject(dev) {
  if (!sys) return false;
  await new Promise(r => execFile('sync', [], () => r()));
  return sys.usbUnmount(dev);
}

/* ---------- список файлов ---------- */
const KINDS = [
  ['doc', /\.(docx?|odt|rtf|txt)$/i], ['sheet', /\.(xlsx?|ods|csv)$/i], ['slides', /\.(pptx?|odp|ppsx?)$/i],
  ['pdf', /\.pdf$/i], ['image', /\.(jpe?g|png|gif|webp|bmp|heic)$/i], ['audio', /\.(mp3|m4a|ogg|oga|opus|wav|flac|aac)$/i],
  ['video', /\.(mp4|m4v|webm|mkv|avi|mov|3gp)$/i], ['archive', /\.(zip|rar|7z|tar|gz)$/i]
];
const kindOf = n => (KINDS.find(([, re]) => re.test(n)) || ['file'])[0];
async function list(dir) {
  const real = await safe(dir);
  const names = await fsp.readdir(real).catch(e => { throw new Error(e.code === 'EACCES' ? 'Нет доступа к папке' : 'Папка не открывается'); });
  const out = [];
  for (const n of names) {
    if (n.startsWith('.') || n === 'System Volume Information' || n === '$RECYCLE.BIN') continue;
    try {
      const st = await fsp.stat(path.join(real, n));
      out.push({ name: n, path: path.join(real, n), dir: st.isDirectory(), size: st.size, mtime: st.mtimeMs, kind: st.isDirectory() ? 'folder' : kindOf(n) });
    } catch (_) { /* сломанная ссылка */ }
  }
  out.sort((a, b) => (b.dir - a.dir) || a.name.localeCompare(b.name, 'ru', { numeric: true }));
  let trash = null;
  if (within(real, TRASH)) trash = await readTrashIndex();
  return { path: real, entries: out.map(e => trash && trash[e.name] ? { ...e, from: trash[e.name].from, deleted: trash[e.name].at } : e) };
}
// недавние документы определённого типа (для «Текст», «Таблицы», «Презентации»)
async function recent(kind, limit = 30) {
  const found = [];
  async function walk(dir, depth) {
    let names = [];
    try { names = await fsp.readdir(dir, { withFileTypes: true }); } catch (_) { return; }
    for (const d of names) {
      if (d.name.startsWith('.')) continue;
      const p = path.join(dir, d.name);
      if (d.isDirectory()) { if (depth < 3) await walk(p, depth + 1); }
      else if (kindOf(d.name) === kind) { try { const st = await fsp.stat(p); found.push({ name: d.name, path: p, mtime: st.mtimeMs, size: st.size, kind }); } catch (_) { /* */ } }
    }
  }
  await walk(DIRS.docs, 0); await walk(DIRS.downloads, 0);
  return found.sort((a, b) => b.mtime - a.mtime).slice(0, limit);
}

/* ---------- копирование с прогрессом ---------- */
async function sizeOf(p) {
  const st = await fsp.lstat(p);
  if (!st.isDirectory()) return st.size;
  let n = 0;
  for (const c of await fsp.readdir(p)) n += await sizeOf(path.join(p, c)).catch(() => 0);
  return n;
}
async function copyFile(src, dst, onBytes) {
  await new Promise((resolve, reject) => {
    const rs = fs.createReadStream(src), ws = fs.createWriteStream(dst, { flags: 'wx' });
    rs.on('data', ch => onBytes(ch.length));
    rs.on('error', reject); ws.on('error', reject); ws.on('finish', resolve);
    rs.pipe(ws);
  });
}
async function copyAny(src, dst, onBytes) {
  const st = await fsp.lstat(src);
  if (st.isSymbolicLink()) return;                                   // ссылки не копируем
  if (st.isDirectory()) {
    await fsp.mkdir(dst, { recursive: true });
    for (const c of await fsp.readdir(src)) await copyAny(path.join(src, c), path.join(dst, c), onBytes);
  } else await copyFile(src, dst, onBytes);
}
let busy = false;
async function copy(srcs, destDir, onProgress = () => {}, { move = false } = {}) {
  if (busy) throw new Error('Уже идёт копирование. Подождите.');
  busy = true;
  try {
    const dest = await safe(destDir);
    const items = [];
    for (const s of srcs) {
      const real = await safe(s);
      if (within(dest, real)) throw new Error('Нельзя скопировать папку внутрь неё самой');
      items.push(real);
    }
    let total = 0, done = 0, last = 0;
    for (const s of items) total += await sizeOf(s).catch(() => 0);
    try { const st = await fsp.statfs(dest); if (st.bavail * st.bsize < total) throw new Error('Не хватает места: нужно ' + fmt(total) + ', свободно ' + fmt(st.bavail * st.bsize)); }
    catch (e) { if (/Не хватает/.test(e.message)) throw e; }
    const tick = n => { done += n; const now = Date.now(); if (now - last > 250) { last = now; onProgress({ done, total, percent: total ? Math.round(done / total * 100) : 100 }); } };
    const out = [];
    for (const s of items) {
      const target = await uniquePath(dest, path.basename(s));
      if (move) {
        try { await fsp.rename(s, target); out.push(target); tick(await sizeOf(target).catch(() => 0)); continue; } catch (_) { /* другой диск — копируем и удаляем */ }
      }
      await copyAny(s, target, tick);
      if (move) await fsp.rm(s, { recursive: true, force: true });
      out.push(target);
    }
    onProgress({ done: total, total, percent: 100, syncing: true });
    await new Promise(r => execFile('sync', [], () => r()));        // всё дописано — флешку можно вынимать
    onProgress({ done: total, total, percent: 100, finished: true });
    return out;
  } finally { busy = false; }
}
const fmt = b => b >= 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' ГБ' : b >= 1e6 ? Math.round(b / 1e6) + ' МБ' : Math.max(1, Math.round(b / 1e3)) + ' КБ';

/* ---------- папки, имена, корзина ---------- */
async function mkdir(dir, name) {
  const real = await safe(dir);
  const p = await uniquePath(real, cleanName(name));
  await fsp.mkdir(p);
  return p;
}
async function rename(p, newName) {
  const real = await safe(p);
  if (Object.values(DIRS).includes(real) || real === TRASH) throw new Error('Эту папку переименовать нельзя');
  const target = path.join(path.dirname(real), cleanName(newName));
  if (target === real) return real;
  if (await exists(target)) throw new Error('Такое имя уже есть');
  await fsp.rename(real, target);
  return target;
}
async function readTrashIndex() { try { return JSON.parse(await fsp.readFile(TRASH_INDEX, 'utf8')); } catch (_) { return {}; } }
async function writeTrashIndex(ix) { await fsp.writeFile(TRASH_INDEX, JSON.stringify(ix)); }
// с компьютера — в корзину (можно вернуть); с флешки — удаляется насовсем
async function remove(paths) {
  const ix = await readTrashIndex();
  let n = 0;
  for (const p of paths) {
    const real = await safe(p);
    if (Object.values(DIRS).includes(real) || real === TRASH || MEDIA_ROOTS.includes(real)) continue;
    if (within(real, TRASH) || MEDIA_ROOTS.some(r => within(real, r))) await fsp.rm(real, { recursive: true, force: true });
    else {
      const t = await uniquePath(TRASH, path.basename(real));
      try { await fsp.rename(real, t); } catch (_) { await copyAny(real, t, () => {}); await fsp.rm(real, { recursive: true, force: true }); }
      ix[path.basename(t)] = { from: real, at: Date.now() };
    }
    n++;
  }
  await writeTrashIndex(ix);
  return n;
}
async function restore(paths) {
  const ix = await readTrashIndex();
  let n = 0;
  for (const p of paths) {
    const real = await safe(p);
    if (!within(real, TRASH) || real === TRASH) continue;
    const rec = ix[path.basename(real)];
    let dest = rec && rec.from ? path.dirname(rec.from) : DIRS.docs;
    if (!(await exists(dest))) dest = DIRS.docs;
    await fsp.rename(real, await uniquePath(dest, rec && rec.from ? path.basename(rec.from) : path.basename(real)));
    delete ix[path.basename(real)]; n++;
  }
  await writeTrashIndex(ix);
  return n;
}
async function emptyTrash() {
  for (const n of await fsp.readdir(TRASH)) await fsp.rm(path.join(TRASH, n), { recursive: true, force: true });
  await writeTrashIndex({});
  return true;
}

/* ---------- новые документы ---------- */
const NEW_DOCS = { doc: ['Новый документ', ['new.docx', 'new.odt']], sheet: ['Новая таблица', ['new.xlsx', 'new.ods']], slides: ['Новая презентация', ['new.pptx', 'new.odp']] };
async function newDoc(kind, dir, name) {
  const spec = NEW_DOCS[kind]; if (!spec) throw new Error('bad kind');
  const real = await safe(dir || DIRS.docs);
  let tpl = null;
  for (const t of spec[1]) if (await exists(path.join(TEMPLATES, t))) { tpl = t; break; }
  if (!tpl) throw new Error('Нет шаблона документа');
  const ext = path.extname(tpl);
  const base = cleanName(name || spec[0]).replace(/\.(docx?|odt|xlsx?|ods|pptx?|odp)$/i, '');
  const p = await uniquePath(real, base + ext);
  await fsp.copyFile(path.join(TEMPLATES, tpl), p);
  return p;
}

/* ---------- открыть файл ---------- */
// Документы — LibreOffice (Word/Excel/PowerPoint), PDF — MuPDF.
// Фото, музыку и видео показывает сама оболочка.
let has = null;
async function which(cmd) { return new Promise(r => execFile('sh', ['-c', 'command -v "$1"', 'sh', cmd], e => r(!e))); }
function launch(cmd, args) {
  const p = spawn(cmd, args, { detached: true, stdio: 'ignore', env: { ...process.env } });
  p.on('error', () => {});
  p.unref();
  return true;
}
async function open(p) {
  const real = await safe(p);
  const st = await fsp.stat(real);
  if (st.isDirectory()) return { viewer: 'folder', path: real };
  const kind = kindOf(real);
  if (['image', 'audio', 'video'].includes(kind)) return { viewer: kind, path: real };
  if (!has) has = { soffice: await which('soffice') || await which('libreoffice'), mupdf: await which('mupdf') };
  if (kind === 'pdf') {
    if (has.mupdf) { launch('mupdf', [real]); return { launched: 'mupdf' }; }
    if (has.soffice) { launch('soffice', ['--nologo', '--norestore', '--view', real]); return { launched: 'soffice' }; }
  }
  if (['doc', 'sheet', 'slides'].includes(kind) || kind === 'file') {
    if (!has.soffice) throw new Error('Программа для документов (LibreOffice) не установлена');
    if (kind === 'file' && st.size > 20e6) throw new Error('Не знаю, чем открыть этот файл');
    launch('soffice', ['--nologo', '--norestore', real]);
    return { launched: 'soffice' };
  }
  throw new Error(kind === 'archive' ? 'Архивы пока не открываются. Попросите родных помочь.' : 'Не знаю, чем открыть этот файл');
}

/* ---------- батарея ---------- */
async function battery() {
  const base = process.env.VOS_POWER_SUPPLY || '/sys/class/power_supply';
  let names = [];
  try { names = await fsp.readdir(base); } catch (_) { return { present: false }; }
  const rd = async (d, f) => { try { return (await fsp.readFile(path.join(base, d, f), 'utf8')).trim(); } catch (_) { return null; } };
  let ac = null, bat = null;
  for (const n of names) {
    const type = await rd(n, 'type');
    if (type === 'Mains') ac = (await rd(n, 'online')) === '1';
    if (type === 'Battery' && (await rd(n, 'present')) !== '0' && !bat) bat = n;
  }
  if (!bat) return { present: false, ac };
  const status = await rd(bat, 'status');                     // Charging / Discharging / Full / Not charging
  let percent = +(await rd(bat, 'capacity'));
  const num = async f => { const v = await rd(bat, f); return v == null ? null : +v; };
  const eNow = await num('energy_now') ?? await num('charge_now'), eFull = await num('energy_full') ?? await num('charge_full');
  const pNow = await num('power_now') ?? await num('current_now');
  if (!Number.isFinite(percent) && eNow && eFull) percent = Math.round(eNow / eFull * 100);
  let minutes = null;
  if (pNow && pNow > 0 && eNow != null) {
    if (status === 'Discharging') minutes = Math.round(eNow / pNow * 60);
    else if (status === 'Charging' && eFull) minutes = Math.round((eFull - eNow) / pNow * 60);
  }
  if (minutes != null && (minutes < 1 || minutes > 24 * 60)) minutes = null;
  return { present: true, percent: Math.max(0, Math.min(100, percent || 0)), status, charging: status === 'Charging', full: status === 'Full' || (status === 'Not charging' && percent >= 95), ac: ac ?? status !== 'Discharging', minutes };
}

module.exports = { DIRS, TRASH, attach, roots, list, recent, copy, mkdir, rename, remove, restore, emptyTrash, newDoc, open, eject, battery, kindOf, uniquePath, safe, fmt };
