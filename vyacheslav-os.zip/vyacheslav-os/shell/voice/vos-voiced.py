#!/usr/bin/env python3
"""
vos-voiced.py — служба голосовой активации ВячеславOS.

Постоянно слушает микрофон и ждёт имя помощника (по умолчанию «Василиса»).
Распознавание имени идёт прямо на ноутбуке (Vosk, маленькая русская модель,
без интернета) в режиме «грамматики»: модель ищет только заданные слова,
поэтому старый Core 2 Duo справляется.

Как только имя услышано:
  • если фраза сказана «на одном дыхании» («Василиса, какая погода») —
    вся фраза уже записана и сразу отдаётся оболочке;
  • если человек сказал только имя и замолчал — служба записывает
    следующую фразу до паузы.
Записанная команда сохраняется в WAV-файл; оболочка отправляет его в Groq
Whisper (точное распознавание), а если интернета нет — использует текст,
распознанный здесь же полной моделью Vosk.

Связь с оболочкой — строки JSON:
  stdin  ← {"cmd": "config"|"pause"|"resume"|"listen"|"cancel"|"speaking"|"quit", ...}
  stdout → {"type": "ready"|"wake"|"wake_cancel"|"listening"|"speech"|"level"|
                    "command"|"timeout"|"paused"|"resumed"|"error", ...}

Микрофон читается через arecord (ALSA). На время видеозвонка или записи
голосовой заметки оболочка присылает "pause" — служба освобождает микрофон.
"""
import json
import os
import selectors
import signal
import subprocess
import sys
import tempfile
import time
import wave

RATE = 16000
CHUNK = 3200                      # 0,1 с звука (16 бит, моно)
UTT_MAX = RATE * 2 * 15           # не держим в памяти больше 15 с одной фразы
SENS = {"low": 0.85, "normal": 0.68, "high": 0.5}


def emit(**ev):
    sys.stdout.write(json.dumps(ev, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def rms(chunk: bytes) -> float:
    """Громкость куска 16-битного звука, 0..1."""
    n = len(chunk) // 2
    if not n:
        return 0.0
    import array
    a = array.array("h", chunk[: n * 2])
    s = 0
    step = 4                       # каждый 4-й отсчёт — достаточно для индикатора
    for i in range(0, n, step):
        v = a[i]
        s += v * v
    return min(1.0, ((s / (n / step)) ** 0.5) / 6000.0)


class Service:
    def __init__(self, model_path: str):
        from vosk import Model, KaldiRecognizer, SetLogLevel  # импорт здесь: если упадёт — сообщим
        SetLogLevel(-1)
        self.KaldiRecognizer = KaldiRecognizer
        self.model = Model(model_path)
        self.words = ["василиса"]
        self.threshold = SENS["normal"]
        self.enabled = True
        self.paused = False
        self.speaking = False
        self.tmpdir = os.environ.get("VOS_TMP") or tempfile.gettempdir()
        self.arec = None
        self.mode = "idle"            # idle | capture
        self.utt = bytearray()        # звук текущей фразы (для режима ожидания имени)
        self.cap = bytearray()        # звук команды
        self.cap_started = 0.0
        self.cap_speech = False
        self.cap_last_voice = 0.0
        self.cap_timeout = 7.0
        self.cap_reason = "wake"
        self.partial_wake = False
        self.last_level = 0.0
        self.mic_buf = bytearray()
        self.make_wake_rec()
        self.full = None

    # ---------- распознаватели ----------
    def make_wake_rec(self):
        grammar = json.dumps(self.words + ["[unk]"], ensure_ascii=False)
        self.wake_rec = self.KaldiRecognizer(self.model, RATE, grammar)
        self.wake_rec.SetWords(True)
        self.utt = bytearray()

    def make_full_rec(self):
        self.full = self.KaldiRecognizer(self.model, RATE)
        self.full.SetWords(False)

    # ---------- микрофон ----------
    def start_mic(self, sel):
        if self.arec or self.paused:
            return
        try:
            self.arec = subprocess.Popen(
                ["arecord", "-q", "-D", os.environ.get("VOS_MIC", "default"), "-f", "S16_LE",
                 "-r", str(RATE), "-c", "1", "-t", "raw"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=0)
            os.set_blocking(self.arec.stdout.fileno(), False)
            sel.register(self.arec.stdout, selectors.EVENT_READ, "mic")
            self.mic_buf = bytearray()
        except Exception as e:  # нет arecord или микрофона
            self.arec = None
            emit(type="error", text="Микрофон недоступен: %s" % e)

    def stop_mic(self, sel):
        if not self.arec:
            return
        try:
            sel.unregister(self.arec.stdout)
        except Exception:
            pass
        try:
            self.arec.terminate()
            self.arec.wait(timeout=2)
        except Exception:
            try:
                self.arec.kill()
            except Exception:
                pass
        self.arec = None

    # ---------- захват команды ----------
    def begin_capture(self, reason, prefix=b"", timeout=7.0):
        self.mode = "capture"
        self.cap = bytearray(prefix)
        self.cap_started = time.time()
        self.cap_speech = False
        self.cap_last_voice = time.time()
        self.cap_timeout = timeout
        self.cap_reason = reason
        self.make_full_rec()           # имя в начале записи оставляем для Whisper, но не считаем речью
        emit(type="listening", reason=reason)

    def finish_capture(self, ok=True):
        text = ""
        if self.full is not None:
            try:
                text = json.loads(self.full.FinalResult()).get("text", "")
            except Exception:
                text = ""
        audio = bytes(self.cap)
        self.mode = "idle"
        self.cap = bytearray()
        self.full = None
        self.make_wake_rec()
        if not ok or not self.cap_speech:
            emit(type="timeout", reason=self.cap_reason)
            return
        path = os.path.join(self.tmpdir, "cmd-%d.wav" % int(time.time() * 1000))
        with wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(RATE)
            w.writeframes(audio)
        emit(type="command", wav=path, text=text, seconds=round(len(audio) / (RATE * 2), 1), reason=self.cap_reason)

    # ---------- обработка звука ----------
    def feed(self, chunk: bytes):
        level = rms(chunk)
        now = time.time()
        if self.mode == "capture":
            self.cap += chunk
            if now - self.last_level > 0.12:
                emit(type="level", value=round(level, 2))
                self.last_level = now
            done = self.full.AcceptWaveform(chunk)
            partial = ""
            if not done:
                try:
                    partial = json.loads(self.full.PartialResult()).get("partial", "")
                except Exception:
                    partial = ""
            if partial or level > 0.08:
                if not self.cap_speech:
                    emit(type="speech")
                self.cap_speech = True
                self.cap_last_voice = now
            if done and self.cap_speech:
                self.finish_capture(True)                       # пауза после фразы — команда готова
            elif not self.cap_speech and now - self.cap_started > self.cap_timeout:
                self.finish_capture(False)                      # так ничего и не сказали
            elif self.cap_speech and now - self.cap_last_voice > 2.5:
                self.finish_capture(True)
            elif now - self.cap_started > 20:
                self.finish_capture(True)                       # слишком длинная фраза
            return

        # режим ожидания имени
        if not self.enabled:
            return
        self.utt += chunk
        if len(self.utt) > UTT_MAX:
            del self.utt[: len(self.utt) - UTT_MAX]
        if self.wake_rec.AcceptWaveform(chunk):
            res = json.loads(self.wake_rec.Result())
            self.check_final(res)
            self.utt = bytearray()
        else:
            part = json.loads(self.wake_rec.PartialResult()).get("partial", "")
            hit = any(w in part.split() for w in self.words)
            if hit and not self.partial_wake and not self.speaking:
                self.partial_wake = True
                emit(type="wake", early=True)                   # показать «Слушаю…» сразу

    def check_final(self, res):
        words = res.get("result") or []
        thr = 0.9 if self.speaking else self.threshold
        idx = -1
        for i, w in enumerate(words):
            if w.get("word") in self.words and w.get("conf", 0) >= thr:
                idx = i
                break
        utt = bytes(self.utt)
        if idx < 0:
            if self.partial_wake:
                emit(type="wake_cancel")
            self.partial_wake = False
            return
        if not self.partial_wake:
            emit(type="wake", early=False)
        self.partial_wake = False
        after = [w for w in words[idx + 1:]]
        spoken_after = sum(max(0.0, w.get("end", 0) - w.get("start", 0)) for w in after)
        if spoken_after >= 0.35:
            # «Василиса, какая погода» — фраза целиком уже записана
            self.mode = "capture"
            self.cap = bytearray(utt)
            self.cap_speech = True
            self.cap_reason = "wake"
            self.make_full_rec()
            self.full.AcceptWaveform(utt)
            self.finish_capture(True)
        else:
            # сказали только имя — слушаем следующую фразу (имя тоже оставим в записи)
            self.begin_capture("wake", prefix=utt[-RATE * 2 * 2:], timeout=7.0)

    # ---------- команды от оболочки ----------
    def command(self, msg, sel):
        cmd = msg.get("cmd")
        if cmd == "config":
            words = [w.strip().lower() for w in msg.get("words", []) if w and w.strip()]
            if words:
                self.words = words
            self.threshold = SENS.get(msg.get("sensitivity", "normal"), SENS["normal"])
            self.enabled = bool(msg.get("enabled", True))
            if self.mode == "idle":
                self.make_wake_rec()
        elif cmd == "pause":
            if self.mode == "capture":
                self.mode = "idle"
            self.paused = True
            self.stop_mic(sel)
            emit(type="paused")
        elif cmd == "resume":
            self.paused = False
            self.make_wake_rec()
            self.start_mic(sel)
            emit(type="resumed")
        elif cmd == "listen":
            # слушать фразу без имени: кнопка микрофона или продолжение разговора
            if self.paused:
                self.paused = False
                self.start_mic(sel)
            self.begin_capture(msg.get("reason", "button"), timeout=float(msg.get("timeout", 7)))
        elif cmd == "cancel":
            if self.mode == "capture":
                self.mode = "idle"
                self.full = None
                self.make_wake_rec()
        elif cmd == "speaking":
            self.speaking = bool(msg.get("on"))
        elif cmd == "quit":
            raise SystemExit(0)

    def run(self):
        sel = selectors.DefaultSelector()
        stdin_fd = sys.stdin.fileno()
        os.set_blocking(stdin_fd, False)
        sel.register(stdin_fd, selectors.EVENT_READ, "stdin")
        dec = __import__("codecs").getincrementaldecoder("utf-8")()
        inbuf = ""
        self.start_mic(sel)
        emit(type="ready", words=self.words)
        retry_at = 0.0
        while True:
            for key, _ in sel.select(timeout=0.5):
                if key.data == "stdin":
                    try:
                        raw = os.read(stdin_fd, 65536)
                    except BlockingIOError:
                        continue
                    if raw == b"":
                        return                                   # оболочка закрылась
                    inbuf += dec.decode(raw)
                    while "\n" in inbuf:
                        line, inbuf = inbuf.split("\n", 1)
                        if line.strip():
                            try:
                                self.command(json.loads(line), sel)
                            except SystemExit:
                                raise
                            except Exception as e:
                                emit(type="error", text="Плохая команда: %s" % e)
                elif key.data == "mic":
                    try:
                        data = self.arec.stdout.read(65536)
                    except Exception:
                        data = None
                    if data == b"":                              # arecord завершился
                        self.stop_mic(sel)
                        emit(type="error", text="Микрофон отключился")
                        retry_at = time.time() + 3
                        continue
                    if data:
                        self.mic_buf += data
                        while len(self.mic_buf) >= CHUNK:
                            chunk = bytes(self.mic_buf[:CHUNK])
                            del self.mic_buf[:CHUNK]
                            self.feed(chunk)
            # таймауты захвата, даже если звук не идёт
            if self.mode == "capture" and not self.cap_speech and time.time() - self.cap_started > self.cap_timeout + 1:
                self.finish_capture(False)
            # микрофон пропал — пробуем снова
            if not self.arec and not self.paused and time.time() > retry_at:
                self.start_mic(sel)
                retry_at = time.time() + 3


def main():
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    model = sys.argv[1] if len(sys.argv) > 1 else "/opt/vos/voice/model"
    if not os.path.isdir(model):
        emit(type="error", fatal=True, text="Нет модели распознавания речи (%s)" % model)
        return 2
    try:
        svc = Service(model)
    except Exception as e:
        emit(type="error", fatal=True, text="Не удалось запустить распознавание: %s" % e)
        return 3
    try:
        svc.run()
    except SystemExit:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
