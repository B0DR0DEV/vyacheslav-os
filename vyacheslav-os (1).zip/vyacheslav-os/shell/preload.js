'use strict';
// Мост между интерфейсом и главным процессом. Интерфейс видит только
// window.vosNative.call(метод, ...аргументы) и подписку на события установщика.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('vosNative', {
  call: (method, ...args) => ipcRenderer.invoke('vos', method, ...args),
  on: (channel, fn) => {
    if (!['install-progress', 'voice', 'fs-progress', 'download'].includes(channel)) return;
    ipcRenderer.on(channel, (_e, data) => fn(data));
  }
});
