/*
 * core.js — основа интерфейса: настройки, хранилище, звуки, голос,
 * диалоги и мелкие помощники для построения экранов.
 */
(function () {
  'use strict';
  const VOS = window.VOS;
  const B = VOS.backend;

  /* ---------- построение DOM ---------- */
  VOS.el = function el(tag, attrs, ...kids) {
    // формат: 'div#id.класс1.класс2'
    const [head, ...classes] = tag.split('.');
    const [name, id] = head.split('#');
    const e = document.createElement(name || 'div');
    if (id) e.id = id;
    if (classes.length) e.className = classes.join(' ');
    if (attrs) for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k === 'style' && typeof v === 'object') { for (const [sk, sv] of Object.entries(v)) { if (sk.startsWith('--')) e.style.setProperty(sk, sv); else e.style[sk] = sv; } }
      else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2), v);
      else if (k === 'html') e.innerHTML = v;
      else if (k === 'text') e.textContent = v;
      else if (k in e && typeof v !== 'string') e[k] = v;
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const k of kids.flat()) if (k != null && k !== false) e.append(k.nodeType ? k : String(k));
    if (name === 'button') decorate(e);
    return e;
  };
  // «➕ Добавить» → [значок плюс] Добавить;  «@forward» → значок без текста
  function decorate(btn) {
    const t = btn.firstChild;
    if (!t || t.nodeType !== 3 || !VOS.glyph) return;
    let s = t.nodeValue, gname = null;
    const m = s.match(/^@([a-z_-]+)\s*/);
    if (m && VOS.hasGlyph(m[1])) { gname = m[1]; s = s.slice(m[0].length); }
    else for (const [em, g] of Object.entries(VOS.EMOJI_GLYPH)) {
      if (s.startsWith(em)) { gname = g; s = s.slice(em.length).replace(/^\uFE0F/, '').trimStart(); break; }
    }
    if (!gname) return;
    const span = document.createElement('span');
    span.className = 'gi'; span.innerHTML = VOS.glyph(gname);
    t.nodeValue = s;
    btn.insertBefore(span, t);
    if (!s) btn.classList.add('icon-only');
  }
  VOS.setBtn = (b, t) => { b.textContent = t; b.classList.remove('icon-only'); decorate(b); };
  VOS.gl = (name, cls) => { const s = document.createElement('span'); s.className = 'gi ' + (cls || ''); s.innerHTML = VOS.glyph(name); return s; };
  const el = VOS.el;
  VOS.$ = (s, r = document) => r.querySelector(s);

  /* ---------- склонения и форматы ---------- */
  VOS.plural = (n, one, few, many) => {
    n = Math.abs(n) % 100; const n1 = n % 10;
    if (n > 10 && n < 20) return many;
    if (n1 > 1 && n1 < 5) return few;
    if (n1 === 1) return one;
    return many;
  };
  VOS.MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
  VOS.MONTHS_NOM = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
  VOS.WEEKDAYS = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
  VOS.WD_SHORT = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
  const pad = n => String(n).padStart(2, '0');
  VOS.pad = pad;
  VOS.fmtTime = d => pad(d.getHours()) + ':' + pad(d.getMinutes());
  VOS.fmtDate = d => d.getDate() + ' ' + VOS.MONTHS[d.getMonth()] + ' ' + d.getFullYear();
  VOS.fmtDateLong = d => VOS.WEEKDAYS[d.getDay()][0].toUpperCase() + VOS.WEEKDAYS[d.getDay()].slice(1) + ', ' + d.getDate() + ' ' + VOS.MONTHS[d.getMonth()];
  VOS.dateKey = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  VOS.timeWords = d => {
    const h = d.getHours(), m = d.getMinutes();
    return h + ' ' + VOS.plural(h, 'час', 'часа', 'часов') + (m ? ' ' + m + ' ' + VOS.plural(m, 'минута', 'минуты', 'минут') : ' ровно');
  };
  VOS.greeting = (d = new Date()) => {
    const h = d.getHours();
    if (h >= 5 && h < 12) return 'Доброе утро';
    if (h >= 12 && h < 18) return 'Добрый день';
    if (h >= 18 && h < 23) return 'Добрый вечер';
    return 'Доброй ночи';
  };
  VOS.fmtNum = (x, digits = 10) => {
    if (!isFinite(x)) return 'Ошибка';
    let s = Number(x.toPrecision(12)).toString();
    if (/e/.test(s)) return s.replace('.', ',');
    let [i, f] = s.split('.');
    const neg = i.startsWith('-'); if (neg) i = i.slice(1);
    i = i.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    if (f) f = f.slice(0, digits);
    return (neg ? '−' : '') + i + (f ? ',' + f : '');
  };
  VOS.fmtSize = b => b >= 1e9 ? (b / 1e9).toFixed(0) + ' ГБ' : (b / 1e6).toFixed(0) + ' МБ';
  VOS.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  VOS.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  /* ---------- события ---------- */
  const listeners = {};
  VOS.on = (ev, fn) => { (listeners[ev] = listeners[ev] || []).push(fn); };
  VOS.off = (ev, fn) => { const a = listeners[ev]; if (a && a.indexOf(fn) >= 0) a.splice(a.indexOf(fn), 1); };
  VOS.emit = (ev, data) => { (listeners[ev] || []).forEach(fn => { try { fn(data); } catch (e) { console.error(e); } }); };

  /* ---------- хранилище ---------- */
  const cache = {};
  VOS.store = {
    async get(name, def) {
      if (name in cache) return cache[name];
      const v = await B.call('storeGet', name, null);
      cache[name] = v == null ? def : v;
      return cache[name];
    },
    async set(name, value) { cache[name] = value; await B.call('storeSet', name, value); return value; }
  };

  /* ---------- настройки ---------- */
  VOS.DEFAULTS = {
    name: 'Вячеслав', password: null, city: 'Москва', timezone: 'Europe/Moscow',
    theme: 'light', accent: '#1d6fd8', fontScale: 1.15, maximizeWindows: false,
    volume: 70, voice: 'anna', voiceRate: 95, voiceEnabled: true, voiceGreeting: true, speakReminders: true,
    groqKey: '', groqModel: '', hwAccel: false, wallpaper: 'sea', effects: true, lite: 'auto',
    // голосовой помощник «без рук»
    wakeEnabled: true, wakeWord: 'василиса', wakeSens: 'normal', followUp: true, voiceOnLock: true, morningBrief: true,
    // связь с родными
    tgToken: '', jitsiServer: 'meet.ffmuc.net', callRoomSeed: '',
    // Telegram: писать ТОЛЬКО этим людям. Остальные, кто напишет боту, игнорируются.
    tgTrusted: 'bodroman_17, Nadenka_Painting', tgTrustedChats: {},
    vkToken: '', vkTrusted: '', vkTrustedIds: {}, vkGroup: null
  };
  VOS.ACCENTS = [
    { name: 'Синий', c: '#1d6fd8' }, { name: 'Зелёный', c: '#1f8a4c' }, { name: 'Бордовый', c: '#a8324a' },
    { name: 'Фиолетовый', c: '#6d3fc0' }, { name: 'Оранжевый', c: '#c8640c' }, { name: 'Бирюзовый', c: '#0f7f86' }
  ];
  VOS.WALLPAPERS = { sea: 1, forest: 1, sunset: 1, calm: 1 };
  VOS.settings = { ...VOS.DEFAULTS };
  VOS.loadSettings = async () => {
    const s = await VOS.store.get('settings', {});
    VOS.settings = { ...VOS.DEFAULTS, ...(s || {}) };
    VOS.applyAppearance();
    return VOS.settings;
  };
  VOS.saveSettings = async patch => {
    Object.assign(VOS.settings, patch);
    await VOS.store.set('settings', VOS.settings);
    VOS.applyAppearance();
    VOS.emit('settings', VOS.settings);
  };
  function shade(hex, k) {
    const n = parseInt(hex.slice(1), 16);
    let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    const f = v => Math.max(0, Math.min(255, Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k)));
    return '#' + [f(r), f(g), f(b)].map(v => v.toString(16).padStart(2, '0')).join('');
  }
  // Слабый компьютер (как Core 2 Duo без AVX и с 4 ГБ): облегчённый режим —
  // без размытия, короткие анимации, простые тени. Решается само (lite: 'auto').
  VOS.weakHardware = () => {
    const hw = (VOS.mode && VOS.mode.hw) || null;
    if (!hw) return false;
    return !hw.avx || (hw.cores <= 2 && hw.memGB <= 4.5);
  };
  VOS.isLite = () => {
    const v = VOS.settings.lite;
    return v === true || (v !== false && VOS.weakHardware());
  };
  VOS.applyAppearance = () => {
    const s = VOS.settings, r = document.documentElement;
    r.dataset.theme = s.theme === 'dark' ? 'dark' : 'light';
    const lite = VOS.isLite();
    r.classList.toggle('lite', lite);
    r.classList.toggle('no-blur', s.effects === false || lite);
    r.style.setProperty('--accent', s.accent);
    r.style.setProperty('--accent-dark', shade(s.accent, -0.25));
    r.style.setProperty('--accent-soft', shade(s.accent, s.theme === 'dark' ? -0.55 : 0.85));
    r.style.fontSize = Math.round(18 * (Number(s.fontScale) || 1)) + 'px';
    r.style.setProperty('--wallpaper', VOS.wallpaperURL(s.wallpaper));
  };

  /* ---------- звуки (синтезируются, файлы не нужны) ---------- */
  let ctx = null;
  const ac = () => { if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)(); if (ctx.state === 'suspended') ctx.resume(); return ctx; };
  function tone(freq, start, dur, vol = 0.25, type = 'sine') {
    const c = ac(), o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(0, c.currentTime + start);
    g.gain.linearRampToValueAtTime(vol, c.currentTime + start + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + start + dur);
    o.connect(g).connect(c.destination);
    o.start(c.currentTime + start); o.stop(c.currentTime + start + dur + 0.05);
  }
  VOS.sound = {
    click() { try { tone(880, 0, 0.06, 0.08); } catch (_) { /* без звука */ } },
    chime() { try { [659, 784, 1047].forEach((f, i) => tone(f, i * 0.16, 0.5, 0.22)); } catch (_) { /* */ } },
    error() { try { tone(220, 0, 0.25, 0.2, 'square'); tone(180, 0.22, 0.3, 0.2, 'square'); } catch (_) { /* */ } },
    test() { try { [523, 659, 784, 1047, 784, 659, 523].forEach((f, i) => tone(f, i * 0.18, 0.3, 0.25)); } catch (_) { /* */ } },
    win() { try { [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, i * 0.12, 0.4, 0.22, 'triangle')); } catch (_) { /* */ } },
    // зацикленная мелодия будильника / напоминания, возвращает функцию «остановить»
    loop(kind = 'alarm') {
      let stopped = false;
      const pattern = kind === 'alarm' ? [[784, 0], [988, 0.2], [1175, 0.4], [988, 0.6], [784, 0.8]] : [[659, 0], [880, 0.25], [659, 0.5]];
      const playOnce = () => { if (stopped) return; try { pattern.forEach(([f, t]) => tone(f, t, 0.35, 0.3, 'triangle')); } catch (_) { /* */ } };
      playOnce();
      const iv = setInterval(playOnce, kind === 'alarm' ? 1800 : 2600);
      return () => { stopped = true; clearInterval(iv); };
    }
  };

  /* ---------- голос ----------
   * Длинный текст делится на куски по предложениям: первый кусок начинает
   * звучать быстро, пока следующие ещё синтезируются. stopSpeaking()
   * обрывает и текущую фразу, и всю очередь. */
  let speakChain = Promise.resolve();
  let currentAudio = null, speakGen = 0, active = 0;
  const setSpeaking = d => { const was = active > 0; active = Math.max(0, active + d); if (was !== active > 0) VOS.emit('speaking', active > 0); };
  VOS.isSpeaking = () => active > 0;
  VOS.stopSpeaking = () => {
    speakGen++;
    if (currentAudio) { currentAudio.pause(); currentAudio.dispatchEvent(new Event('ended')); currentAudio = null; }
    if (window.speechSynthesis) speechSynthesis.cancel();
  };
  function splitSpeech(text) {
    const parts = [], s = String(text).replace(/\s+/g, ' ').trim();
    const sentences = s.match(/[^.!?…]+[.!?…]*/g) || [s];
    let cur = '';
    for (const x of sentences) {
      if ((cur + x).length > 320 && cur) { parts.push(cur.trim()); cur = ''; }
      cur += x;
    }
    if (cur.trim()) parts.push(cur.trim());
    return parts;
  }
  VOS.speak = (text, { force = false } = {}) => {
    if (!text || (!VOS.settings.voiceEnabled && !force)) return Promise.resolve();
    const g = speakGen;
    setSpeaking(1);
    for (const part of splitSpeech(text)) speakChain = speakChain.then(() => (g === speakGen ? sayNow(part) : null)).catch(() => {});
    speakChain = speakChain.then(() => setSpeaking(-1));
    return speakChain;
  };
  async function sayNow(text) {
    const s = VOS.settings;
    let file = null;
    try { file = await B.call('tts', text, s.voice, s.voiceRate); } catch (_) { file = null; }
    if (file) {
      await new Promise(res => {
        const a = new Audio('file://' + file.split('/').map(encodeURIComponent).join('/'));
        currentAudio = a;
        a.onended = a.onerror = () => { if (currentAudio === a) currentAudio = null; res(); };
        a.play().catch(() => res());
      });
      return;
    }
    if (window.speechSynthesis && window.SpeechSynthesisUtterance) {
      await new Promise(res => {
        const u = new SpeechSynthesisUtterance(text);
        u.lang = 'ru-RU'; u.rate = (s.voiceRate || 100) / 100;
        u.onend = u.onerror = res;
        speechSynthesis.speak(u);
        setTimeout(res, 30000);
      });
    }
  }

  /* ---------- диалоги ---------- */
  function overlay(cls = '') {
    const o = el('div.overlay' + (cls ? '.' + cls : ''));
    VOS.$('#overlays').append(o);
    return o;
  }
  function dialogIcon(icon) {
    const m = VOS.DIALOG_ICON[icon] || ['info', 'var(--accent)'];
    const d = el('div.dialog-icon', { style: { '--ic': m[1] } }); d.innerHTML = VOS.glyph(m[0]); return d;
  }
  VOS.dialogIcon = dialogIcon;
  VOS.ui = {
    toast(text, ms = 3500) {
      const t = el('div.toast', { text });
      document.body.append(t);
      requestAnimationFrame(() => t.classList.add('show'));
      setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, ms);
    },
    dialog({ icon = '', title = '', text = '', body = null, buttons = [{ label: 'Хорошо', value: true, primary: true }], cls = '' }) {
      return new Promise(resolve => {
        const o = overlay(cls);
        const close = v => { o.classList.add('closing'); setTimeout(() => o.remove(), 160); resolve(v); };
        const box = el('div.dialog',
          null,
          icon ? dialogIcon(icon) : null,
          title ? el('h2', { text: title }) : null,
          text ? el('p.dialog-text', { text }) : null,
          body,
          el('div.dialog-btns', null, buttons.map(b => el('button.btn' + (b.primary ? '.primary' : '') + (b.danger ? '.danger' : ''), {
            text: b.label, onclick: () => close(typeof b.value === 'function' ? b.value() : b.value)
          })))
        );
        o.append(box);
        o.addEventListener('keydown', e => { if (e.key === 'Escape') close(null); });
        const first = box.querySelector('input,textarea') || box.querySelector('.btn.primary');
        setTimeout(() => first && first.focus(), 50);
      });
    },
    alert(title, text, icon = 'ℹ️') { return VOS.ui.dialog({ icon, title, text }); },
    confirm({ title, text, yes = 'Да', no = 'Нет', danger = false, icon = '❓' }) {
      return VOS.ui.dialog({ icon, title, text, buttons: [{ label: no, value: false }, { label: yes, value: true, primary: !danger, danger }] });
    },
    prompt({ title, text = '', value = '', placeholder = '', type = 'text', icon = '' }) {
      const input = el('input.big-input', { type, value, placeholder });
      input.addEventListener('keydown', e => { if (e.key === 'Enter') e.target.closest('.dialog').querySelector('.btn.primary').click(); });
      return VOS.ui.dialog({ icon, title, text, body: input, buttons: [{ label: 'Отмена', value: null }, { label: 'Готово', value: () => input.value, primary: true }] });
    },
    // большое окно напоминания поверх всего (в том числе поверх экрана блокировки)
    bigAlert({ icon, title, text, buttons }) {
      const o = overlay('alarm-overlay');
      let resolveFn;
      const p = new Promise(r => { resolveFn = r; });
      const box = el('div.alarm-box', null,
        dialogIcon(icon),
        el('h1', { text: title }),
        el('p', { text }),
        el('div.alarm-btns', null, buttons.map(b => el('button.btn.huge' + (b.primary ? '.primary' : ''), { text: b.label, onclick: () => { o.remove(); resolveFn(b.value); } })))
      );
      o.append(box);
      return { promise: p, close: () => { o.remove(); resolveFn(null); } };
    },
    overlay
  };

  /* ---------- реестр приложений ---------- */
  VOS.apps = [];
  VOS.registerApp = def => { VOS.apps.push(def); };
  VOS.app = id => VOS.apps.find(a => a.id === id);

  /* ---------- онлайн ли мы ---------- */
  VOS.online = () => navigator.onLine !== false;
})();
