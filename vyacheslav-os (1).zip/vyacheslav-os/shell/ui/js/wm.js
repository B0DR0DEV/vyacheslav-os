/*
 * wm.js — собственный оконный менеджер ВячеславOS:
 * окна (перетаскивание, свернуть/развернуть/закрыть, изменение размера,
 * анимации открытия, сворачивания в панель задач и закрытия),
 * панель задач, меню «Пуск» с поиском, значки и виджет рабочего стола,
 * трей (Wi-Fi, звук, часы).
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const wins = [];
  let zTop = 10, nextId = 1;
  const area = () => VOS.$('#windows');
  const EASE = 'cubic-bezier(.2,.8,.2,1)';
  const html = (tag, h) => { const e = el(tag); e.innerHTML = h; return e; };

  /* ================= окна ================= */
  function bounds() { const r = area().getBoundingClientRect(); return { w: r.width, h: r.height }; }
  function taskBtn(w) { return document.querySelector('.task[data-wid="' + w.id + '"]'); }
  function towardsTask(w) {
    const b = taskBtn(w), r = w.el.getBoundingClientRect();
    if (!b) return 'translate(0, 60vh) scale(.2)';
    const t = b.getBoundingClientRect();
    return `translate(${t.left + t.width / 2 - (r.left + r.width / 2)}px, ${t.top + t.height / 2 - (r.top + r.height / 2)}px) scale(.12)`;
  }

  function focus(w) {
    if (!w) return;
    w.el.style.zIndex = ++zTop;
    wins.forEach(x => x.el.classList.toggle('active', x === w));
    if (w.minimized) restore(w);
    renderTasks();
  }
  function minimize(w) {
    if (w.minimized) return;
    w.minimized = true;
    const a = w.el.animate([{ transform: 'none', opacity: 1 }, { transform: towardsTask(w), opacity: 0 }], { duration: 260, easing: 'cubic-bezier(.4,0,.6,1)' });
    a.onfinish = () => { if (w.minimized) w.el.classList.add('minimized'); };
    VOS.emit('wm', { type: 'minimize', w });
    const top = topWindow(); wins.forEach(x => x.el.classList.toggle('active', x === top));
    renderTasks();
  }
  function restore(w) {
    w.minimized = false;
    w.el.classList.remove('minimized');
    w.el.animate([{ transform: towardsTask(w), opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 280, easing: EASE });
    renderTasks();
    VOS.emit('wm', { type: 'restore', w });
  }
  function toggleMax(w, force) {
    const max = force !== undefined ? force : !w.maximized;
    if (max === w.maximized) return;
    if (max) w.prev = { left: w.el.style.left, top: w.el.style.top, width: w.el.style.width, height: w.el.style.height };
    w.el.classList.add('animating');
    w.maximized = max;
    w.el.classList.toggle('maximized', max);
    if (!max && w.prev) Object.assign(w.el.style, w.prev);
    w.maxBtn.innerHTML = VOS.glyph(max ? 'restore' : 'maximize');
    w.maxBtn.title = max ? 'Обычный размер' : 'Во весь экран';
    setTimeout(() => { w.el.classList.remove('animating'); w.onResize && w.onResize(); }, 260);
    VOS.emit('wm', { type: max ? 'maximize' : 'unmaximize', w });
  }
  function close(w) {
    if (w.closing) return;
    if (w.beforeClose && w.beforeClose() === false) return;
    w.closing = true;
    try { w.cleanup && w.cleanup(); } catch (e) { console.error(e); }
    wins.splice(wins.indexOf(w), 1);
    renderTasks();
    const a = w.el.animate([{ transform: 'none', opacity: 1 }, { transform: 'scale(.94) translateY(10px)', opacity: 0 }], { duration: 170, easing: 'ease-in' });
    a.onfinish = () => w.el.remove();
    VOS.emit('wm', { type: 'close', w });
    const top = topWindow(); if (top) focus(top);
  }
  function topWindow() {
    return wins.filter(w => !w.minimized).sort((a, b) => (+b.el.style.zIndex) - (+a.el.style.zIndex))[0];
  }

  function open(appId, args) {
    const app = VOS.app(appId);
    if (!app) { VOS.ui.toast('Приложение не найдено'); return null; }
    closeStart(); closePopups();
    if (app.single !== false) {
      const exist = wins.find(w => w.app.id === appId);
      if (exist) { focus(exist); if (args && exist.onArgs) exist.onArgs(args); return exist; }
    }
    const { w: AW, h: AH } = bounds();
    const k = parseFloat(getComputedStyle(document.documentElement).fontSize) / 18;
    const ww = Math.min(AW - 40, Math.round((app.width || 900) * k));
    const hh = Math.min(AH - 30, Math.round((app.height || 620) * k));
    const offset = (wins.length % 6) * 30;
    const winEl = el('div.win', { style: { width: ww + 'px', height: hh + 'px', left: Math.max(0, (AW - ww) / 2 - 60 + offset) + 'px', top: Math.max(0, (AH - hh) / 2 - 20 + offset) + 'px' } });
    const titleText = el('span.win-name', { text: app.title });
    const wbtn = (cls, title, g) => { const b = el('button.wb.' + cls, { title }); b.innerHTML = VOS.glyph(g); return b; };
    const minBtn = wbtn('wb-min', 'Свернуть', 'minimize');
    const maxBtn = wbtn('wb-max', 'Во весь экран', 'maximize');
    const closeBtn = wbtn('wb-close', 'Закрыть', 'close');
    const bar = el('div.win-title', null, html('span.win-icon', VOS.appIcon(app.id)), titleText, el('div.win-btns', null, minBtn, maxBtn, closeBtn));
    const body = el('div.win-body');
    const grip = el('div.win-resize', { title: 'Потяните, чтобы изменить размер' });
    winEl.append(bar, body, grip);
    area().append(winEl);
    const w = { id: nextId++, app, el: winEl, body, maxBtn, minimized: false, maximized: false,
      setTitle(t) { titleText.textContent = t ? app.title + ' — ' + t : app.title; } };
    wins.push(w);

    minBtn.onclick = e => { e.stopPropagation(); minimize(w); };
    maxBtn.onclick = e => { e.stopPropagation(); toggleMax(w); };
    closeBtn.onclick = e => { e.stopPropagation(); close(w); };
    winEl.addEventListener('pointerdown', () => { if (winEl.style.zIndex != zTop) focus(w); }, true);
    bar.addEventListener('dblclick', e => { if (!e.target.closest('.wb')) toggleMax(w); });
    makeDraggable(w, bar);
    makeResizable(w, grip);

    if (VOS.settings.maximizeWindows || app.maximized) { w.maximized = true; winEl.classList.add('maximized'); w.prev = { left: winEl.style.left, top: winEl.style.top, width: winEl.style.width, height: winEl.style.height }; maxBtn.innerHTML = VOS.glyph('restore'); }
    focus(w);
    winEl.animate([{ transform: 'scale(.92) translateY(14px)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 240, easing: EASE });
    try {
      const r = app.open(w, args || {});
      if (typeof r === 'function') w.cleanup = r;
      else if (r && typeof r.then === 'function') r.then(fn => { if (typeof fn === 'function') { if (w.closing) fn(); else w.cleanup = fn; } }).catch(e => { console.error(e); body.append(el('div.empty', { text: 'Ошибка в приложении: ' + e.message })); });
    } catch (e) {
      console.error(e);
      body.append(el('div.empty', { text: 'Ошибка в приложении: ' + e.message }));
    }
    return w;
  }

  function makeDraggable(w, handle) {
    let sx, sy, ox, oy, dragging = false, pid = null;
    handle.addEventListener('pointerdown', e => {
      if (e.button !== 0 || e.target.closest('.wb')) return;
      dragging = true; pid = e.pointerId; handle.setPointerCapture(pid);
      sx = e.clientX; sy = e.clientY;
      if (w.maximized) {
        const ratio = e.clientX / bounds().w;
        w.maximized = false; w.el.classList.remove('maximized');
        if (w.prev) Object.assign(w.el.style, w.prev);
        w.maxBtn.innerHTML = VOS.glyph('maximize');
        w.el.style.left = Math.max(0, e.clientX - w.el.offsetWidth * ratio) + 'px';
        w.el.style.top = '0px';
      }
      ox = w.el.offsetLeft; oy = w.el.offsetTop;
      w.el.classList.add('dragging');
    });
    handle.addEventListener('pointermove', e => {
      if (!dragging || e.pointerId !== pid) return;
      const { w: AW, h: AH } = bounds();
      let nx = ox + e.clientX - sx, ny = oy + e.clientY - sy;
      nx = Math.min(Math.max(nx, -w.el.offsetWidth + 140), AW - 140);
      ny = Math.min(Math.max(ny, 0), AH - 50);
      w.el.style.left = nx + 'px'; w.el.style.top = ny + 'px';
      VOS.$('#snap-hint').classList.toggle('show', e.clientY <= 4);
    });
    const end = e => {
      if (!dragging) return; dragging = false; w.el.classList.remove('dragging');
      VOS.$('#snap-hint').classList.remove('show');
      try { handle.releasePointerCapture(pid); } catch (_) { /* */ }
      if (e.clientY <= 4) toggleMax(w, true);   // дотянули до верха экрана — во весь экран
    };
    handle.addEventListener('pointerup', end);
    handle.addEventListener('pointercancel', end);
  }
  function makeResizable(w, grip) {
    let sx, sy, ow, oh, on = false;
    grip.addEventListener('pointerdown', e => { on = true; grip.setPointerCapture(e.pointerId); sx = e.clientX; sy = e.clientY; ow = w.el.offsetWidth; oh = w.el.offsetHeight; e.stopPropagation(); });
    grip.addEventListener('pointermove', e => {
      if (!on) return;
      w.el.style.width = Math.max(380, ow + e.clientX - sx) + 'px';
      w.el.style.height = Math.max(280, oh + e.clientY - sy) + 'px';
    });
    grip.addEventListener('pointerup', () => { on = false; w.onResize && w.onResize(); });
  }

  /* ================= панель задач ================= */
  function renderTasks() {
    const list = VOS.$('#task-list');
    const top = topWindow();
    const have = new Set();
    for (const w of wins) {
      have.add(String(w.id));
      let b = taskBtn(w);
      if (!b) {
        b = el('button.task', { 'data-wid': w.id, title: w.app.title }, html('span.task-icon', VOS.appIcon(w.app.id)), el('span.task-name', { text: w.app.title }));
        b.onclick = () => { if (w === topWindow() && !w.minimized) minimize(w); else focus(w); };
        list.append(b);
        b.animate([{ transform: 'translateY(20px)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 220, easing: EASE });
      }
      b.classList.toggle('current', w === top && !w.minimized);
      b.classList.toggle('min', w.minimized);
    }
    list.querySelectorAll('.task').forEach(b => { if (!have.has(b.dataset.wid)) b.remove(); });
  }

  /* ================= меню «Пуск» ================= */
  function buildStart() {
    const m = VOS.$('#start-menu'); m.textContent = '';
    const s = VOS.settings;
    const input = el('input', { placeholder: 'Найти программу…', type: 'text' });
    const grid = el('div.sm-grid');
    const fill = q => {
      grid.textContent = '';
      const apps = VOS.apps.filter(a => !a.hidden && (!q || (a.title + ' ' + (a.words || []).join(' ')).toLowerCase().includes(q.toLowerCase())));
      apps.forEach((a, i) => {
        const b = el('button.sm-app', { onclick: () => open(a.id) }, html('span.sm-icon', VOS.appIcon(a.id)), el('span.sm-label', { text: a.title }));
        b.style.animationDelay = Math.min(i * 12, 240) + 'ms';
        grid.append(b);
      });
      if (!apps.length) grid.append(el('div.sm-empty', { text: 'Ничего не найдено. Спросите помощника — кнопка с микрофоном внизу.' }));
    };
    input.addEventListener('input', () => fill(input.value.trim()));
    input.addEventListener('keydown', e => { if (e.key === 'Enter') { const f = grid.querySelector('.sm-app'); if (f) f.click(); } });
    const pbtn = (g, label, fn, cls = '') => { const b = el('button.sm-pbtn' + cls, { title: label, onclick: fn }, el('span.sm-plabel', { text: label })); b.prepend(VOS.gl(g)); return b; };
    m.append(
      el('div.sm-search', null, VOS.gl('search'), input),
      el('div.sm-head', null, el('span', { text: 'Все программы' })),
      grid,
      el('div.sm-foot', null,
        el('div.sm-user', null, el('div.avatar', { text: (s.name || 'В')[0].toUpperCase() }), el('div', null, el('div.sm-name', { text: s.name }), el('div.sm-sub', { text: VOS.fmtDateLong(new Date()) }))),
        el('div.sm-power', null,
          pbtn('lock', 'Блокировка', () => { closeStart(); VOS.screens.lock(); }),
          pbtn('refresh', 'Перезагрузка', () => askPower('reboot')),
          pbtn('power', 'Выключение', () => askPower('poweroff'), '.danger'))));
    fill('');
    return input;
  }
  function toggleStart() {
    const m = VOS.$('#start-menu');
    if (!m.classList.contains('open')) {
      closePopups(); const input = buildStart();
      m.classList.add('open'); VOS.$('#start-btn').classList.add('on');
      setTimeout(() => input.focus(), 120);
    } else closeStart();
  }
  function closeStart() { const m = VOS.$('#start-menu'); if (m) m.classList.remove('open'); const b = VOS.$('#start-btn'); if (b) b.classList.remove('on'); }

  async function askPower(action) {
    closeStart(); closePopups();
    const off = action === 'poweroff';
    const ok = await VOS.ui.confirm({
      icon: off ? '⏻' : '🔄', title: off ? 'Выключить компьютер?' : 'Перезагрузить компьютер?',
      text: off ? 'Все окна закроются, компьютер выключится.' : 'Компьютер выключится и сразу включится снова.',
      yes: off ? 'Выключить' : 'Перезагрузить', no: 'Отмена', danger: true
    });
    if (!ok) return;
    const sh = el('div.shutdown', null, html('div.sd-logo', VOS.logoSVG(110, true)), el('div.spinner'), el('div', { text: off ? 'Выключение…' : 'Перезагрузка…' }));
    document.body.append(sh);
    if (off) VOS.speak('До свидания, ' + VOS.settings.name + '!');
    await VOS.store.set('session', { lastShutdown: Date.now() });
    setTimeout(async () => {
      const r = await B.call('power', action).catch(() => false);
      if (!r) { sh.remove(); VOS.ui.alert('Не получилось', 'Компьютер не смог выключиться сам. Нажмите и подержите кнопку питания 5 секунд.', '⚠️'); }
    }, 1800);
  }

  /* ================= рабочий стол: значки и виджет ================= */
  function renderIcons() {
    const box = VOS.$('#desk-icons'); box.textContent = '';
    VOS.apps.filter(a => a.desktop !== false && !a.hidden).forEach((a, i) => {
      const b = el('button.dicon', { title: a.title, onclick: () => open(a.id) }, html('span.dicon-img', VOS.appIcon(a.id)), el('span.dicon-label', { text: a.title }));
      b.style.animationDelay = (120 + i * 25) + 'ms';
      box.append(b);
    });
  }
  let widgetWeather = null, widgetWeatherAt = 0;
  async function renderWidget() {
    const box = VOS.$('#desk-widget'); if (!box) return;
    const d = new Date();
    box.querySelector('.dw-time').textContent = VOS.fmtTime(d);
    box.querySelector('.dw-date').textContent = VOS.fmtDateLong(d);
    const hol = VOS.todayHoliday ? VOS.todayHoliday() : '';
    const extra = box.querySelector('.dw-extra'); extra.textContent = '';
    if (hol) extra.append(el('div.dw-row', null, VOS.gl('star'), el('span', { text: hol })));
    // ближайшее лекарство
    const meds = (await VOS.store.get('meds', [])).filter(m => m.enabled !== false);
    const log = (await VOS.store.get('medlog', {}))[VOS.dateKey(d)] || {};
    const now = VOS.fmtTime(d);
    const next = meds.flatMap(m => m.times.map(t => ({ m, t }))).filter(x => x.t >= now && !log[x.m.id + '@' + x.t]).sort((a, b) => a.t.localeCompare(b.t))[0];
    if (next) extra.append(el('div.dw-row', null, VOS.gl('bell'), el('span', { text: next.t + ' — ' + next.m.name })));
    // погода раз в 30 минут
    if (VOS.weather && Date.now() - widgetWeatherAt > 30 * 60e3) {
      widgetWeatherAt = Date.now();
      VOS.weather.get(VOS.settings.city).then(r => { widgetWeather = r; renderWidget(); }).catch(() => {});
    }
    if (VOS.tipOfDay) {
      const tip = VOS.tipOfDay();
      const row = el('button.dw-row.dw-tip', { title: 'Совет дня — нажмите, чтобы послушать', onclick: () => VOS.speak('Совет дня. ' + tip, { force: true }) }, el('span', { text: tip }));
      row.prepend(VOS.gl('bulb'));
      extra.append(row);
    }
    if (widgetWeather) {
      const c = widgetWeather.f.current, t = Math.round(c.temperature_2m);
      const row = el('button.dw-row.dw-weather', { onclick: () => open('weather') }, el('span', { text: (t > 0 ? '+' : '') + t + '°  ' + widgetWeather.place.name }));
      row.insertAdjacentHTML('afterbegin', VOS.weatherIcon(c.weather_code, 34));
      extra.append(row);
    }
  }

  /* ================= всплывающие панели трея ================= */
  function closePopups() {
    VOS.$$('#popups .popup').forEach(p => { p.classList.add('closing'); setTimeout(() => p.remove(), 160); });
    VOS.$$('.tray-btn.on').forEach(b => b.classList.remove('on'));
  }
  function popup(anchor, title, content, cls = '') {
    const p = VOS.$('#popups');
    const had = p.querySelector('.popup:not(.closing)');
    const same = had && had.dataset.anchor === anchor.id;
    closePopups(); closeStart();
    if (same) return null;
    const box = el('div.popup' + (cls ? '.' + cls : ''), { 'data-anchor': anchor.id }, el('div.popup-title', { text: title }), content);
    p.append(box);
    anchor.classList.add('on');
    const r = anchor.getBoundingClientRect();
    box.style.right = Math.max(8, window.innerWidth - r.right - 10) + 'px';
    return box;
  }

  VOS.wifiPanel = function wifiPanel() {
    const root = el('div.wifi-panel');
    const head = el('div.wifi-head');
    const list = el('div.wifi-list', null, el('div.muted', { text: 'Ищу сети…' }));
    root.append(head, list);
    async function refresh(scan = true) {
      const st = await B.call('wifiStatus').catch(() => ({ available: false }));
      head.textContent = '';
      if (!st.available) { head.append(el('div', { text: 'Сетевые настройки недоступны.' })); list.textContent = ''; return; }
      const sw = el('label.toggle', null, el('input', { type: 'checkbox', checked: !!st.enabled, onchange: async e => { await B.call('wifiSetEnabled', e.target.checked); setTimeout(() => refresh(true), 1500); } }), el('span.toggle-ui'), el('span', { text: 'Wi-Fi' }));
      const state = el('div.wifi-state');
      state.append(VOS.gl(st.wired ? 'ethernet' : st.ssid ? 'check' : 'wifi-off'), document.createTextNode(st.wired ? ' Подключено по кабелю' : st.ssid ? ' ' + st.ssid : st.enabled ? ' Нет подключения' : ' Wi-Fi выключен'));
      head.append(state, sw);
      if (!st.enabled) { list.textContent = ''; return; }
      if (!scan) return;
      list.textContent = ''; list.append(el('div.muted', { text: 'Ищу сети…' }));
      const nets = await B.call('wifiScan').catch(() => []);
      list.textContent = '';
      if (!nets.length) list.append(el('div.muted', { text: 'Сети не найдены. Нажмите «Обновить».' }));
      nets.forEach((n, i) => {
        const lvl = n.signal > 70 ? 3 : n.signal > 45 ? 2 : n.signal > 20 ? 1 : 0;
        const ic = el('span.wifi-ic.l' + lvl); ic.innerHTML = VOS.glyph('wifi');
        const row = el('div.wifi-row' + (n.connected ? '.connected' : ''), null,
          ic, el('span.wifi-name', null, el('b', { text: n.ssid }), el('small', { text: n.connected ? 'Подключено' : n.secure ? 'Защищённая сеть' : 'Открытая сеть' })),
          n.secure ? VOS.gl('lock', 'dim') : null,
          n.connected ? el('button.btn.small', { text: 'Отключить', onclick: async () => { await B.call('wifiDisconnect'); refresh(false); setTimeout(() => refresh(true), 800); } })
                      : el('button.btn.small.primary', { text: 'Подключить', onclick: () => connect(n) }));
        row.style.animationDelay = i * 40 + 'ms';
        list.append(row);
      });
    }
    async function connect(n) {
      let pw = '';
      if (n.secure) {
        const input = el('input.big-input', { type: 'password', placeholder: 'Пароль от Wi-Fi' });
        const show = el('label.check', null, el('input', { type: 'checkbox', onchange: e => { input.type = e.target.checked ? 'text' : 'password'; } }), ' Показать пароль');
        input.addEventListener('keydown', e => { if (e.key === 'Enter') e.target.closest('.dialog').querySelector('.btn.primary').click(); });
        pw = await VOS.ui.dialog({ icon: '📶', title: 'Сеть «' + n.ssid + '»', text: 'Введите пароль. Обычно он написан на наклейке снизу роутера.', body: el('div', null, input, show),
          buttons: [{ label: 'Отмена', value: null }, { label: 'Подключиться', value: () => input.value, primary: true }] });
        if (pw == null) return;
      }
      list.prepend(el('div.muted', { text: 'Подключаюсь к «' + n.ssid + '»…' }));
      const r = await B.call('wifiConnect', n.ssid, pw).catch(e => ({ ok: false, error: e.message }));
      if (r.ok) { VOS.ui.toast('Подключено к «' + n.ssid + '»'); VOS.sound.chime(); }
      else VOS.ui.alert('Не подключилось', r.error, '⚠️');
      refresh(true); updateTray();
    }
    root.append(el('div.row-right', null, el('button.btn', { text: '🔄 Обновить', onclick: () => refresh(true) })));
    refresh(true);
    return root;
  };

  VOS.volumePanel = function volumePanel() {
    const val = el('div.vol-value', { text: '…' });
    const range = el('input.vol-range', { type: 'range', min: 0, max: 100, step: 5 });
    const paint = () => range.style.setProperty('--p', range.value + '%');
    const apply = VOS.debounce(v => { B.call('setVolume', v); VOS.saveSettings({ volume: v }); }, 250);
    range.oninput = () => { val.textContent = range.value + '%'; paint(); apply(+range.value); updateVolIcon(+range.value); };
    B.call('getVolume').then(v => { range.value = v.volume; val.textContent = v.volume + '%'; paint(); });
    const step = d => { range.value = Math.max(0, Math.min(100, +range.value + d)); range.oninput(); };
    return el('div.vol-panel', null,
      el('div.vol-row', null, el('button.btn.round', { text: '@volume-low', title: 'Тише', onclick: () => step(-10) }), range, el('button.btn.round', { text: '@volume', title: 'Громче', onclick: () => step(10) })),
      val,
      el('div.row', null,
        el('button.btn', { text: '🔇 Без звука', onclick: () => { range.value = 0; range.oninput(); } }),
        el('button.btn.primary', { text: '🔔 Проверить звук', onclick: () => { VOS.sound.test(); setTimeout(() => VOS.speak('Проверка звука. Вы меня хорошо слышите?', { force: true }), 1400); } })));
  };

  function updateVolIcon(v) { VOS.$('#tray-vol').innerHTML = VOS.glyph(v === 0 ? 'mute' : v < 50 ? 'volume-low' : 'volume'); }
  async function updateTray() {
    const st = await B.call('wifiStatus').catch(() => ({}));
    const b = VOS.$('#tray-wifi');
    if (st.wired) b.innerHTML = VOS.glyph('ethernet');
    else if (st.ssid) { b.innerHTML = VOS.glyph('wifi'); b.firstChild.classList.add('l' + (st.signal > 70 ? 3 : st.signal > 45 ? 2 : 1)); }
    else b.innerHTML = VOS.glyph('wifi-off');
    b.title = st.wired ? 'Интернет по кабелю' : st.ssid ? 'Wi-Fi: ' + st.ssid : 'Нет интернета — нажмите, чтобы подключиться';
    b.classList.toggle('warn', !st.wired && !st.ssid);
    const v = await B.call('getVolume').catch(() => ({ volume: 70 }));
    updateVolIcon(v.muted ? 0 : v.volume);
  }
  function tickClock() {
    const d = new Date();
    VOS.$('#clock-time').textContent = VOS.fmtTime(d);
    VOS.$('#clock-date').textContent = VOS.pad(d.getDate()) + '.' + VOS.pad(d.getMonth() + 1) + '.' + d.getFullYear();
    renderWidget();
  }

  function initShell() {
    VOS.$$ = VOS.$$ || ((s, r = document) => [...r.querySelectorAll(s)]);
    VOS.$('#start-btn').insertAdjacentHTML('afterbegin', VOS.logoSVG(30));
    VOS.$('#assist-btn').insertAdjacentHTML('afterbegin', VOS.glyph('mic'));
    renderIcons(); renderTasks(); tickClock(); updateTray();
    setInterval(tickClock, 5000);
    setInterval(updateTray, 20000);
    VOS.$('#start-btn').onclick = toggleStart;
    VOS.$('#tray-wifi').onclick = e => popup(e.currentTarget, 'Интернет', VOS.wifiPanel(), 'wide');
    VOS.$('#tray-vol').onclick = e => popup(e.currentTarget, 'Громкость', VOS.volumePanel());
    VOS.$('#tray-clock').onclick = () => { closePopups(); open('calendar'); };
    VOS.$('#show-desktop').onclick = () => { const anyOpen = wins.some(w => !w.minimized); wins.forEach(w => anyOpen ? minimize(w) : restore(w)); };
    VOS.$('#desktop').addEventListener('pointerdown', e => { if (!e.target.closest('.popup')) { closePopups(); closeStart(); } });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') { closePopups(); closeStart(); }
      if (e.key === 'Meta' || e.key === 'OS') toggleStart();
    });
    VOS.on('settings', () => { renderIcons(); renderWidget(); });
  }

  VOS.$$ = (s, r = document) => [...r.querySelectorAll(s)];
  // перезагрузка в Windows (установка рядом с Windows)
  async function askWindows() {
    const ok = await VOS.ui.confirm({ icon: '🪟', title: 'Перезагрузить в Windows?', text: 'Сохраните открытые документы. Компьютер перезагрузится в Windows, а при следующем включении снова запустится ВячеславOS.', yes: 'Перезагрузить' });
    if (!ok) return;
    try { await B.call('rebootToWindows'); } catch (e) { VOS.ui.alert('Не получилось', String(e.message || e).replace(/^Error invoking remote method 'vos': (Error: )?/, ''), '⚠️'); }
  }
  VOS.wm = { open, close, focus, minimize, toggleMax, closeStart, closePopups, initShell, askPower, updateTray, popup, askWindows,
    list: () => wins.slice(), top: topWindow, closeAll: () => wins.slice().forEach(close) };
})();
