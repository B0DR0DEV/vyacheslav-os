/*
 * browser.js — встроенный просмотр сайтов внутри окна ВячеславOS.
 * В системе используется <webview> (движок Chromium с кодеками видео),
 * при проверке в обычном браузере — <iframe>.
 * Крупные кнопки: Назад, Вперёд, Обновить, Домой, Крупнее/Мельче.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el;

  // Текст для чтения вслух: выделенное, иначе основная статья страницы
  const GRAB = `(() => {
    const sel = String(getSelection() || '').trim();
    if (sel.length > 20) return sel;
    const root = document.querySelector('article') || document.querySelector('[itemprop=articleBody]') || document.querySelector('main') || document.body;
    const ps = [...root.querySelectorAll('h1, p')].map(p => p.innerText.trim()).filter(t => t.length > 40 || /^[А-ЯA-Z]/.test(t) && t.length > 15);
    return (ps.length ? ps.join('\n') : root.innerText).slice(0, 6000);
  })()`;
  let reading = false;
  async function readView(view) {
    if (reading || VOS.isSpeaking()) { VOS.stopSpeaking(); reading = false; return { say: '', quiet: true }; }
    let text = '';
    try { text = view.executeJavaScript ? await view.executeJavaScript(GRAB) : ''; } catch (_) { text = ''; }
    if (!text) { VOS.ui.toast('Не получилось взять текст со страницы'); return { say: 'На этой странице не нашлось текста для чтения.' }; }
    reading = true;
    VOS.ui.toast('Читаю вслух. Чтобы остановить — нажмите «Читать вслух» ещё раз или скажите «стоп».', 5000);
    VOS.speak(text, { force: true }).then(() => { reading = false; });
    return { say: '', quiet: true };
  }
  // «Василиса, прочитай» — читаем страницу в верхнем окне
  VOS.readAloud = async () => {
    const w = VOS.wm.top();
    const view = w && w.el.querySelector('.web-view');
    if (!view) return { say: 'Откройте статью на сайте, и я её прочитаю. Можно выделить нужный кусок текста мышкой.' };
    return readView(view);
  };

  VOS.makeBrowser = function ({ home, topBar = null, zoom = 1.25 }) {
    const useWebview = VOS.isNative;
    const view = useWebview
      ? el('webview', { src: home, partition: 'persist:web', allowpopups: true, class: 'web-view' })
      : el('iframe', { src: home, class: 'web-view', referrerpolicy: 'no-referrer' });
    let z = zoom;
    // строка состояния — поверх сайта в углу, места не занимает
    const status = el('span.web-status', { text: '' });
    const setZoom = v => {
      z = Math.max(0.6, Math.min(2.5, v));
      if (useWebview && view.setZoomFactor) { try { view.setZoomFactor(z); } catch (_) { /* ещё не загрузилось */ } }
      zoomLbl.textContent = Math.round(z * 100) + '%';
    };
    const zoomLbl = el('span.web-zoom', { text: Math.round(z * 100) + '%' });
    const readBtn = el('button.btn.nav.read-btn', { title: 'Прочитать вслух выделенное или всю статью', onclick: () => readView(view) }, '🔊 Читать');
    // всё в одну строку: навигация · выбор сайта/поиск (прокручивается вбок) · читать · размер
    const nav = el('div.web-nav', null,
      el('button.btn.nav.ic', { title: 'Назад', onclick: () => { try { view.goBack(); } catch (_) { /* */ } } }, '@back'),
      el('button.btn.nav.ic', { title: 'Вперёд', onclick: () => { try { view.goForward(); } catch (_) { /* */ } } }, '@forward'),
      el('button.btn.nav.ic', { title: 'Обновить', onclick: () => { try { view.reload(); } catch (_) { view.src = view.src; } } }, '@refresh'),
      el('button.btn.nav.ic', { title: 'В начало', onclick: () => api.load(home) }, '@home'),
      topBar ? el('div.web-extra', null, topBar) : el('span.spacer'),
      readBtn,
      el('button.btn.nav.ic', { title: 'Мельче', onclick: () => setZoom(z - 0.1) }, 'A−'),
      zoomLbl,
      el('button.btn.nav.ic', { title: 'Крупнее', onclick: () => setZoom(z + 0.1) }, 'A+'));
    if (useWebview) {
      view.addEventListener('dom-ready', () => setZoom(z));
      view.addEventListener('did-start-loading', () => { status.textContent = 'Загрузка…'; });
      view.addEventListener('did-stop-loading', () => { status.textContent = ''; });
      view.addEventListener('did-fail-load', e => {
        if (e.errorCode === -3 || e.isMainFrame === false) return;          // отмена или кусочек страницы — не ошибка
        // код ошибки показываем — по нему видно, что именно не так (для родных)
        status.textContent = 'Сайт не открылся (' + (e.errorDescription || 'ошибка') + ', ' + e.errorCode + '). Нажмите ⟳.';
      });
      view.addEventListener('render-process-gone', () => { status.textContent = 'Страница перестала отвечать. Нажмите ⟳, чтобы открыть заново.'; });
      view.addEventListener('unresponsive', () => { status.textContent = 'Страница долго думает — компьютер не успевает. Подождите или нажмите ⟳.'; });
      view.addEventListener('responsive', () => { status.textContent = ''; });
    }
    const root = el('div.browser', null, nav, el('div.web-wrap', null, view, status));
    // если выбор сайтов не помещается — колесо мыши листает его вбок и есть кнопки ‹ ›
    const extra = nav.querySelector('.web-extra');
    if (extra) {
      const prev = el('button.web-more.left', { title: 'Показать предыдущие', onclick: () => extra.scrollBy({ left: -extra.clientWidth * 0.7, behavior: 'smooth' }) }, '‹');
      const next = el('button.web-more.right', { title: 'Показать ещё', onclick: () => extra.scrollBy({ left: extra.clientWidth * 0.7, behavior: 'smooth' }) }, '›');
      const wrap = el('div.web-extra-wrap', null, prev, extra.cloneNode(false), next);
      extra.replaceWith(wrap); wrap.replaceChild(extra, wrap.children[1]);
      const paint = () => {
        const over = extra.scrollWidth > extra.clientWidth + 4;
        prev.classList.toggle('hidden', !over || extra.scrollLeft < 4);
        next.classList.toggle('hidden', !over || extra.scrollLeft + extra.clientWidth >= extra.scrollWidth - 4);
      };
      extra.addEventListener('scroll', paint);
      extra.addEventListener('wheel', e => { if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) { extra.scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });
      new ResizeObserver(paint).observe(extra);
      setTimeout(paint, 100);
    }
    const api = {
      root, view,
      load(url) { if (useWebview && view.loadURL && view.getWebContentsId) { try { view.loadURL(url); return; } catch (_) { /* ещё не готов */ } } view.src = url; },
      setHome(url) { home = url; }
    };
    if (!useWebview) {
      view.title = 'Предпросмотр: в ВячеславOS сайт откроется прямо в этом окне.';
    }
    return api;
  };
})();
