/*
 * icons.js — собственный набор графики ВячеславOS (всё нарисовано
 * в коде как SVG, без картинок из интернета и без эмодзи):
 *   • логотип «Рассвет над морем»;
 *   • иконки 21 приложения в едином стиле (цветная плитка + белый символ);
 *   • интерфейсные значки (кнопки, трей, меню) — VOS.glyph('plus');
 *   • значки погоды;
 *   • обои — мягкие волны в четырёх цветовых вариантах.
 */
(function () {
  'use strict';
  const VOS = window.VOS = window.VOS || {};
  let uid = 0;

  /* ================= логотип ================= */
  VOS.logoSVG = (size = 120, animated = false) => {
    const id = 'lg' + (uid++);
    return `<svg class="vos-logo${animated ? ' anim' : ''}" width="${size}" height="${size}" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg">
<defs><linearGradient id="${id}a" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3fb4ff"/><stop offset=".55" stop-color="#3b7cf5"/><stop offset="1" stop-color="#6a4cf0"/></linearGradient>
<linearGradient id="${id}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".35"/><stop offset=".5" stop-color="#fff" stop-opacity="0"/></linearGradient>
<linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff6c8"/><stop offset="1" stop-color="#ffd25a"/></linearGradient></defs>
<rect x="4" y="4" width="112" height="112" rx="30" fill="url(#${id}a)"/>
<rect x="4" y="4" width="112" height="112" rx="30" fill="url(#${id}b)"/>
<g class="rays" stroke="#fff" stroke-width="6" stroke-linecap="round"><path d="M60 24v9"/><path d="M33.5 37l6 6"/><path d="M86.5 37l-6 6"/><path d="M22 60h8"/><path d="M98 60h-8"/></g>
<path class="sun" d="M38 66a22 22 0 0 1 44 0z" fill="url(#${id}s)"/>
<path class="wave w1" d="M22 78q9.5-8 19 0t19 0t19 0t19 0" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round"/>
<path class="wave w2" d="M30 92q7.5-6.5 15 0t15 0t15 0t15 0" fill="none" stroke="#fff" stroke-opacity=".6" stroke-width="6" stroke-linecap="round"/>
</svg>`;
  };

  /* ================= иконки приложений ================= */
  function gear(cx, cy, r1, r2, n) {
    let d = '';
    for (let i = 0; i < n * 2; i++) {
      const a0 = (Math.PI * i) / n - Math.PI / (n * 2.6), a1 = (Math.PI * i) / n + Math.PI / (n * 2.6);
      const r = i % 2 ? r1 : r2;
      d += (i ? 'L' : 'M') + (cx + r * Math.cos(a0)).toFixed(1) + ' ' + (cy + r * Math.sin(a0)).toFixed(1) +
        'L' + (cx + r * Math.cos(a1)).toFixed(1) + ' ' + (cy + r * Math.sin(a1)).toFixed(1);
    }
    return d + 'Z';
  }
  // {c} — тёмный цвет плитки (для деталей на белом символе)
  const APP = {
    news: ['#ff8a5c', '#e5484d', `<rect x="11" y="12" width="26" height="25" rx="3" fill="#fff"/><rect x="15" y="16" width="18" height="5" rx="1.5" fill="{c}"/><path d="M15 25h8M15 29h8M15 33h8" stroke="{c}" stroke-width="2" stroke-linecap="round"/><rect x="26" y="24" width="7" height="10" rx="1.5" fill="{c}" opacity=".45"/>`],
    tv: ['#5b9dff', '#3550d6', `<rect x="9" y="14" width="30" height="20" rx="4" fill="#fff"/><rect x="13" y="18" width="22" height="12" rx="2" fill="{c}" opacity=".85"/><path d="M19 8l5 5 5-5M17 38h14" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`],
    video: ['#ff5c7a', '#c51a4a', `<rect x="9" y="13" width="30" height="22" rx="6" fill="#fff"/><path d="M21 18.5l9.5 5.5-9.5 5.5z" fill="{c}"/>`],
    search: ['#3ec5ff', '#2563eb', `<circle cx="21.5" cy="21.5" r="9" fill="none" stroke="#fff" stroke-width="4"/><circle cx="21.5" cy="21.5" r="5" fill="#fff" opacity=".3"/><path d="M28.5 28.5l8 8" stroke="#fff" stroke-width="5" stroke-linecap="round"/>`],
    radio: ['#ffb02e', '#ea6a0a', `<path d="M14 18L34 9" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><rect x="8" y="18" width="32" height="20" rx="5" fill="#fff"/><circle cx="18" cy="28" r="5.5" fill="{c}"/><circle cx="18" cy="28" r="2" fill="#fff"/><path d="M28 24h7M28 28h7M28 32h7" stroke="{c}" stroke-width="2.2" stroke-linecap="round"/>`],
    notes: ['#ffd84d', '#f29a0e', `<rect x="12" y="9" width="24" height="30" rx="4" fill="#fff"/><path d="M17 17h14M17 22h14M17 27h14M17 32h9" stroke="{c}" stroke-width="2.2" stroke-linecap="round"/>`],
    calc: ['#7c8ba1', '#3b4658', `<rect x="12" y="8" width="24" height="32" rx="5" fill="#fff"/><rect x="15.5" y="11.5" width="17" height="7" rx="2" fill="{c}"/><g fill="{c}"><circle cx="18.5" cy="24" r="2"/><circle cx="24" cy="24" r="2"/><circle cx="29.5" cy="24" r="2"/><circle cx="18.5" cy="29.5" r="2"/><circle cx="24" cy="29.5" r="2"/><circle cx="18.5" cy="35" r="2"/><circle cx="24" cy="35" r="2"/></g><rect x="27.5" y="27.5" width="4" height="9.5" rx="2" fill="#ff8a3d"/>`],
    meds: ['#3ddc97', '#0b8a5f', `<g transform="rotate(-40 24 24)"><rect x="9" y="17" width="30" height="14" rx="7" fill="#fff"/><path d="M24 17h8a7 7 0 0 1 0 14h-8z" fill="#ff6b6b"/><path d="M13 21.5h7" stroke="#fff" stroke-width="2" opacity=".0"/></g><circle cx="35" cy="34" r="6" fill="#fff"/><path d="M35 31v6M32 34h6" stroke="{c}" stroke-width="2.2" stroke-linecap="round"/>`],
    calendar: ['#ff7b7b', '#d42a2a', `<rect x="10" y="12" width="28" height="26" rx="5" fill="#fff"/><path d="M10 17a5 5 0 0 1 5-5h18a5 5 0 0 1 5 5v3H10z" fill="{c}"/><path d="M17 9v6M31 9v6" stroke="#fff" stroke-width="3" stroke-linecap="round"/><g fill="{c}"><rect x="15" y="24" width="4" height="4" rx="1"/><rect x="22" y="24" width="4" height="4" rx="1"/><rect x="29" y="24" width="4" height="4" rx="1" opacity=".4"/><rect x="15" y="30" width="4" height="4" rx="1" opacity=".4"/><rect x="22" y="30" width="4" height="4" rx="1" opacity=".4"/></g>`],
    alarm: ['#b48cff', '#6d3fd6', `<path d="M11 15l5-5M37 15l-5-5" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/><circle cx="24" cy="26" r="12" fill="#fff"/><path d="M24 19v7.5l5 3" stroke="{c}" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round" fill="none"/><path d="M16 38l-2 3M32 38l2 3" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/>`],
    todo: ['#4fe08a', '#159446', `<rect x="10" y="10" width="28" height="28" rx="6" fill="#fff"/><path d="M15 18.5l2.5 2.5 4-4.5M15 28.5l2.5 2.5 4-4.5" stroke="{c}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/><path d="M25 19h8M25 29h8" stroke="{c}" stroke-width="2.4" stroke-linecap="round" opacity=".55"/>`],
    solitaire: ['#2fcf6c', '#0e7a3c', `<g transform="rotate(-12 18 25)"><rect x="9" y="12" width="17" height="24" rx="3" fill="#fff" opacity=".85"/></g><g transform="rotate(10 30 24)"><rect x="21" y="11" width="18" height="26" rx="3.5" fill="#fff"/><path d="M30 30c-5-3.5-6.5-7.5-3.5-9.5 1.6-1 3 .2 3.5 1.2.5-1 1.9-2.2 3.5-1.2 3 2 1.5 6-3.5 9.5z" fill="#e5484d"/></g>`],
    sudoku: ['#8a93ff', '#4338ca', `<rect x="10" y="10" width="28" height="28" rx="5" fill="#fff"/><path d="M19.3 10v28M28.7 10v28M10 19.3h28M10 28.7h28" stroke="{c}" stroke-width="1.8" opacity=".7"/><rect x="20.3" y="20.3" width="7.4" height="7.4" rx="1.5" fill="{c}"/><circle cx="14.7" cy="14.7" r="2" fill="{c}"/><circle cx="33.3" cy="33.3" r="2" fill="{c}"/>`],
    pressure: ['#ff7a92', '#d1194a', `<path d="M24 38C12 30 8 22 12 16.5c3-4 8.6-3.6 12 .8 3.4-4.4 9-4.8 12-.8 4 5.5 0 13.5-12 21.5z" fill="#fff"/><path d="M11 25h7l2.5-5 4 9.5 3-6h9.5" stroke="{c}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`],
    voicenotes: ['#ff7ac6', '#c4258a', `<rect x="18.5" y="8" width="11" height="20" rx="5.5" fill="#fff"/><path d="M13 22a11 11 0 0 0 22 0" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M24 33v5M18 39h12" stroke="#fff" stroke-width="3" stroke-linecap="round"/><path d="M21.5 14h5M21.5 18h5" stroke="{c}" stroke-width="1.8" stroke-linecap="round"/>`],
    weather: ['#5fb2ff', '#1f7fd6', `<circle cx="19" cy="18" r="7.5" fill="#ffd34d"/><path d="M19 6.5v2.5M8.5 18h-2.5M11.5 10.5l-1.8-1.8M26.5 10.5l1.8-1.8" stroke="#ffd34d" stroke-width="2.4" stroke-linecap="round"/><path d="M17 37h17a7 7 0 0 0 .5-14 9 9 0 0 0-17 2.5A5.8 5.8 0 0 0 17 37z" fill="#fff"/>`],
    stopwatch: ['#30d5c2', '#0b8478', `<rect x="20.5" y="7" width="7" height="4" rx="1.5" fill="#fff"/><path d="M34 14.5l2.5-2.5" stroke="#fff" stroke-width="3" stroke-linecap="round"/><circle cx="24" cy="26" r="12.5" fill="#fff"/><path d="M24 26l5-6" stroke="{c}" stroke-width="3" stroke-linecap="round"/><circle cx="24" cy="26" r="2.2" fill="{c}"/>`],
    converter: ['#ffc53d', '#d4770a', `<path d="M11 18h24m-6-6l6 6-6 6M37 30H13m6-6l-6 6 6 6" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`],
    photos: ['#c58cff', '#8b32d6', `<rect x="9" y="12" width="30" height="24" rx="5" fill="#fff"/><circle cx="31" cy="19" r="3.2" fill="#ffc53d"/><path d="M9 31l9-9 7 7 4-4 10 9v.5a5 5 0 0 1-5 5H14a5 5 0 0 1-5-5z" fill="{c}"/>`],
    settings: ['#9aa7ba', '#4a5568', `<path d="${gear(24, 24, 11, 14.5, 8)}" fill="#fff"/><circle cx="24" cy="24" r="5" fill="{c}"/>`],
    contacts: ['#ff9f6b', '#e0551f', `<circle cx="18" cy="17" r="6" fill="#fff"/><path d="M7 37a11 11 0 0 1 22 0z" fill="#fff"/><circle cx="32.5" cy="20" r="4.6" fill="#fff" opacity=".75"/><path d="M28.5 37a9 9 0 0 1 14-7.5V37z" fill="#fff" opacity=".75"/>`],
    call: ['#3ddc84', '#0f9d58', `<rect x="8" y="14" width="22" height="20" rx="5" fill="#fff"/><path d="M30 21l9-5.5v17L30 27z" fill="#fff"/><circle cx="19" cy="24" r="4" fill="{c}"/>`],
    help: ['#4fc3f7', '#1976d2', `<rect x="8" y="10" width="32" height="21" rx="3.5" fill="#fff"/><path d="M19 38h10M24 31v7" stroke="#fff" stroke-width="3" stroke-linecap="round"/><path d="M17 24.5c2.5-2.5 4-2.5 6 0s3.5 2.5 6.5-.5" stroke="{c}" stroke-width="2.6" fill="none" stroke-linecap="round"/><path d="M27 15.5l2.5 2.5 4.5-4.5" stroke="{c}" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`],
    briefing: ['#ffb84d', '#f0731f', `<path d="M13 31a11 11 0 0 1 22 0z" fill="#fff"/><path d="M24 10v4M13.5 15.5l2.8 2.8M34.5 15.5l-2.8 2.8M8 25.5h4M36 25.5h4" stroke="#fff" stroke-width="3" stroke-linecap="round"/><path d="M9 37h30" stroke="#fff" stroke-width="3" stroke-linecap="round"/>`],
    meters: ['#7ed6a7', '#16855a', `<circle cx="24" cy="25" r="14" fill="#fff"/><path d="M14.5 27a9.5 9.5 0 0 1 19 0" stroke="{c}" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".45"/><path d="M24 27l6-6" stroke="{c}" stroke-width="3" stroke-linecap="round"/><circle cx="24" cy="27" r="2.4" fill="{c}"/><rect x="18" y="31" width="12" height="4" rx="1.3" fill="{c}" opacity=".7"/>`],
    learn: ['#ffcf5a', '#e08a00', `<path d="M24 12L6 20l18 8 18-8z" fill="#fff"/><path d="M13 24v7c0 2.5 5 5 11 5s11-2.5 11-5v-7l-11 5z" fill="#fff" opacity=".85"/><path d="M40 20v9" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/><circle cx="40" cy="31" r="2.4" fill="#fff"/>`],
    practice: ['#9aa7ba', '#4a5568', `<rect x="9" y="11" width="30" height="26" rx="4" fill="#fff"/><rect x="9" y="11" width="30" height="7" rx="3" fill="{c}" opacity=".5"/>`],
    install: ['#5ea8ff', '#1e4fd1', `<path d="M24 8v15m-6.5-6.5L24 23l6.5-6.5" stroke="#fff" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round" fill="none"/><rect x="9" y="27" width="30" height="12" rx="4" fill="#fff"/><circle cx="32.5" cy="33" r="2" fill="{c}"/><path d="M14 33h9" stroke="{c}" stroke-width="2.2" stroke-linecap="round"/>`],
    files: ['#ffc94d', '#e08a00', `<path d="M8 15a4 4 0 0 1 4-4h7l3.5 3.5H36a4 4 0 0 1 4 4V34a4 4 0 0 1-4 4H12a4 4 0 0 1-4-4z" fill="#fff" opacity=".8"/><path d="M8 20.5a3 3 0 0 1 3-3h26a3 3 0 0 1 3 3V34a4 4 0 0 1-4 4H12a4 4 0 0 1-4-4z" fill="#fff"/><path d="M15 27h18" stroke="{c}" stroke-width="2.6" stroke-linecap="round" opacity=".55"/>`],
    doc: ['#4f8dff', '#1f4fc4', `<path d="M13 8h15l8 8v22a3 3 0 0 1-3 3H13a3 3 0 0 1-3-3V11a3 3 0 0 1 3-3z" fill="#fff"/><path d="M28 8v6a2 2 0 0 0 2 2h6" fill="{c}" opacity=".35"/><path d="M15.5 22h17M15.5 27h17M15.5 32h11" stroke="{c}" stroke-width="2.4" stroke-linecap="round"/>`],
    sheet: ['#34c77b', '#0f7a43', `<rect x="9" y="9" width="30" height="30" rx="4" fill="#fff"/><path d="M9 17.5h30M9 25.5h30M9 33h30M19 9v30M29 9v30" stroke="{c}" stroke-width="1.8" opacity=".55"/><rect x="9" y="9" width="30" height="8.5" rx="4" fill="{c}" opacity=".85"/><rect x="20" y="26.5" width="8" height="5.5" rx="1" fill="{c}"/>`],
    slides: ['#ff8a4c', '#d24a12', `<rect x="7" y="10" width="34" height="23" rx="3.5" fill="#fff"/><path d="M24 33v6M17 40h14" stroke="#fff" stroke-width="3" stroke-linecap="round"/><path d="M13 27l6-7 5 4 6-8 5 11z" fill="{c}" opacity=".8"/><circle cx="16" cy="16.5" r="2.5" fill="{c}"/>`],
    mail: ['#5fa8ff', '#2b5fd9', `<rect x="7" y="12" width="34" height="24" rx="4" fill="#fff"/><path d="M8.5 14.5L24 26l15.5-11.5" stroke="{c}" stroke-width="2.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`]
  };
  VOS.appIcon = (id, size) => {
    const a = APP[id] || APP.settings, gid = 'ai' + (uid++);
    const s = size ? ` width="${size}" height="${size}"` : '';
    return `<svg class="app-icon"${s} viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><defs>` +
      `<linearGradient id="${gid}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a[0]}"/><stop offset="1" stop-color="${a[1]}"/></linearGradient>` +
      `<linearGradient id="${gid}h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".32"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>` +
      `<rect x="1.5" y="1.5" width="45" height="45" rx="12" fill="url(#${gid})"/><rect x="1.5" y="1.5" width="45" height="45" rx="12" fill="url(#${gid}h)"/>` +
      `<rect x="2" y="2" width="44" height="44" rx="11.5" fill="none" stroke="#fff" stroke-opacity=".18"/>` +
      a[2].replace(/\{c\}/g, a[1]) + '</svg>';
  };
  VOS.appColor = id => (APP[id] || APP.settings)[1];

  /* ================= интерфейсные значки (24×24, цвет текста) ================= */
  const G = {
    plus: '<path d="M12 5v14M5 12h14"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    minimize: '<path d="M5 12h14"/>',
    maximize: '<rect x="5" y="5" width="14" height="14" rx="2"/>',
    restore: '<rect x="4" y="8" width="12" height="12" rx="2"/><path d="M8 8V6a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2"/>',
    trash: '<path d="M4 7h16M9 7V4.5h6V7M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z M13.5 6.5l4 4"/>',
    play: '<path d="M7.5 4.8v14.4L19 12z" fill="currentColor"/>',
    pause: '<rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor"/><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/>',
    record: '<circle cx="12" cy="12" r="7" fill="currentColor"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.4-5.7M20 4v5h-5"/>',
    undo: '<path d="M9 14L4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3"/>',
    home: '<path d="M4 11l8-7 8 7M6 9.5V20h12V9.5M10 20v-5h4v5"/>',
    back: '<path d="M15 5l-7 7 7 7"/>',
    forward: '<path d="M9 5l7 7-7 7"/>',
    up: '<path d="M5 15l7-7 7 7"/>',
    volume: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
    'volume-low': '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9a4.5 4.5 0 0 1 0 6"/>',
    mute: '<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
    bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z M10 20.5a2 2 0 0 0 4 0"/>',
    'bell-off': '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z M10 20.5a2 2 0 0 0 4 0 M4 4l16 16"/>',
    save: '<path d="M5 4h11l3 3v13H5z M8 4v5h7V4 M8 20v-6h8v6"/>',
    text: '<path d="M5 6h14M5 10h14M5 14h10M5 18h7"/>',
    bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2v.1h5v-.1c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"/>',
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z M18.5 16l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17.3v.2"/>',
    power: '<path d="M12 3v8M7 6.3a8 8 0 1 0 10 0"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    alarm: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9v4l2.5 2M4 5.5l3-2.5M20 5.5l-3-2.5"/>',
    moon: '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4"/>',
    download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
    folder: '<path d="M3.5 7a2 2 0 0 1 2-2h4l2 2.5h7a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>',
    file: '<path d="M7 3h7l5 5v12a1.5 1.5 0 0 1-1.5 1.5h-10A1.5 1.5 0 0 1 6 20V4.5A1.5 1.5 0 0 1 7 3z M14 3v5h5"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5.5A1.5 1.5 0 0 0 14.5 4h-9A1.5 1.5 0 0 0 4 5.5v9A1.5 1.5 0 0 0 5.5 16H8"/>',
    upload: '<path d="M12 16V5M7 10l5-5 5 5M5 20h14"/>',
    eject: '<path d="M12 5l7 8H5z M5 18h14"/>',
    mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="M4.5 7l7.5 6 7.5-6"/>',
    battery: '<rect x="2.5" y="7.5" width="17" height="9" rx="2"/><path d="M21.5 10.5v3"/>',
    plug: '<path d="M9 3v5M15 3v5M7 8h10v3a5 5 0 0 1-10 0z M12 16v5"/>',
    usb: '<rect x="8" y="9" width="8" height="12" rx="1.8"/><path d="M9.5 9V3.5h5V9M11 6h.01M13 6h.01"/>',
    image: '<rect x="4" y="5" width="16" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M4 17l5-5 4 4 2-2 5 5"/>',
    star: '<path d="M12 3.5l2.6 5.5 5.9.6-4.5 4 1.3 5.9-5.3-3-5.3 3 1.3-5.9-4.5-4 5.9-.6z"/>',
    disk: '<rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 16.5h.01M12 3v7M9 7l3 3 3-3"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    timer: '<circle cx="12" cy="14" r="7"/><path d="M12 14v-4M10 3h4M18 6.5l1.5-1.5"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/>',
    palette: '<path d="M12 3a9 9 0 0 0 0 18c1 0 1.5-.8 1.5-1.6 0-1-.8-1.4-.8-2.4 0-1 .8-1.5 1.8-1.5H17a4 4 0 0 0 4-4C21 6.8 17 3 12 3z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7" r="1"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/>',
    bot: '<rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 4v4M2.5 13v2.5M21.5 13v2.5"/><circle cx="9.5" cy="13.5" r="1" fill="currentColor"/><circle cx="14.5" cy="13.5" r="1" fill="currentColor"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.2"/>',
    warning: '<path d="M12 3.5L2.5 20h19z M12 10v4.5M12 17.2v.2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
    grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
    wifi: '<path class="w3" d="M2.5 8.5a14 14 0 0 1 19 0"/><path class="w2" d="M5.5 12a9.5 9.5 0 0 1 13 0"/><path class="w1" d="M8.8 15.3a4.6 4.6 0 0 1 6.4 0"/><circle cx="12" cy="19" r="1.4" fill="currentColor" stroke="none"/>',
    'wifi-off': '<path d="M2.5 8.5a14 14 0 0 1 19 0M5.5 12a9.5 9.5 0 0 1 13 0M8.8 15.3a4.6 4.6 0 0 1 6.4 0" opacity=".35"/><circle cx="12" cy="19" r="1.4" fill="currentColor" stroke="none" opacity=".35"/><path d="M4 4l16 16"/>',
    ethernet: '<rect x="5" y="9" width="14" height="11" rx="1.5"/><path d="M9 9V5h6v4M9.5 13.5v2.5M12 13.5v2.5M14.5 13.5v2.5"/>',
    tv: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M8 21h8M9 2.5l3 3 3-3"/>',
    radio: '<rect x="3" y="9" width="18" height="11" rx="2.5"/><circle cx="8.5" cy="14.5" r="2.5"/><path d="M14 13h4M14 16h4M6.5 9l11-5"/>',
    text_size: '<path d="M4 18L9 6l5 12M5.8 14h6.4M15 18l3-7 3 7M16 16h4"/>',
    flag2: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    eraser: '<path d="M8 20h12M5 15l8-8 6 6-5 5H8z"/>',
    shuffle: '<path d="M4 7h3c5 0 5 10 10 10h3M17 14l3 3-3 3M4 17h3c1.7 0 2.8-1.2 3.6-2.6M13.4 9.6C14.2 8.2 15.3 7 17 7h3M17 4l3 3-3 3"/>',
    pill: '<rect x="3" y="8.5" width="18" height="7" rx="3.5" transform="rotate(-40 12 12)"/><path d="M9.4 9.1l5.2 5.8"/>',
    backspace: '<path d="M9 5h11a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H9l-6-7z"/><path d="M12 9.5l5 5M17 9.5l-5 5"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    video: '<rect x="3" y="6.5" width="12.5" height="11" rx="2.5"/><path d="M15.5 10.5l5-3v9l-5-3z"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1.5 1.5 0 0 1-1.6 1.5A16.5 16.5 0 0 1 3.5 5.6 1.5 1.5 0 0 1 5 4z"/>',
    heart: '<path d="M12 20s-7.5-4.6-7.5-10.2A4.3 4.3 0 0 1 12 7.3a4.3 4.3 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20z"/>',
    handshake: '<path d="M3 12l4-4 4 2 3-3 3 1 4 4M7 16l3 3M10 13l3 3M13 11l3 3M3 12l4 4"/>',
    gauge: '<path d="M4 17a8 8 0 1 1 16 0"/><path d="M12 17l4-5"/><circle cx="12" cy="17" r="1.2" fill="currentColor"/>',
    news: '<rect x="4" y="5" width="16" height="14" rx="2"/><path d="M8 9h8M8 12.5h8M8 16h5"/>',
    send: '<path d="M4 12l16-7-6 16-3-6.5z M11 14.5l9-9.5"/>',
    keyboard: '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10h.01M11 10h.01M15 10h.01M7 14h10"/>'
  };
  VOS.glyph = (name, cls = '') => `<svg class="g ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${G[name] || G.info}</svg>`;
  VOS.hasGlyph = n => !!G[n];

  // эмодзи в начале подписи кнопки → наш значок (используется в VOS.el)
  VOS.EMOJI_GLYPH = {
    '➕': 'plus', '🗑': 'trash', '✏️': 'edit', '✏': 'edit', '▶': 'play', '⏸': 'pause', '⏹': 'stop', '⏺': 'record', '🎤': 'mic',
    '🔍': 'search', '🔄': 'refresh', '⟳': 'refresh', '🏠': 'home', '◀': 'back', '🔊': 'volume', '🔇': 'mute', '🔔': 'bell', '🔕': 'bell-off',
    '💾': 'save', '📝': 'text', '💡': 'bulb', '🆕': 'sparkle', '↩': 'undo', '✨': 'sparkle', '❓': 'help', '⏻': 'power', '🔒': 'lock',
    '✅': 'check', '⏰': 'alarm', '😴': 'moon', '📥': 'download', '🔌': 'usb', '🖼': 'image', '⭐': 'star', '💽': 'disk', '✕': 'close',
    '⏱': 'timer', '⏲': 'timer', '🏁': 'flag', '↺': 'undo', '🅰': 'text_size', '👀': 'eye', '☀️': 'sun', '🌙': 'moon', '📺': 'tv', '⏭': 'forward', '📞': 'phone', '📤': 'send', '❤': 'heart'
  };
  // большие значки диалогов: эмодзи → [значок, цвет]
  VOS.DIALOG_ICON = {
    'ℹ️': ['info', '#1d6fd8'], '⚠️': ['warning', '#d97706'], '❓': ['help', '#1d6fd8'], '⏻': ['power', '#c0352b'], '🔄': ['refresh', '#1d6fd8'],
    '📶': ['wifi', '#1d6fd8'], '💊': ['pill', '#0b8a5f'], '⏰': ['alarm', '#6d3fd6'], '📅': ['calendar', '#d42a2a'], '🏆': ['star', '#d4930a'],
    '🔒': ['lock', '#1d6fd8'], '🎤': ['mic', '#c4258a'], '🃏': ['help', '#0e7a3c'], '🔌': ['usb', '#1d6fd8'], '🎙️': ['mic', '#c4258a'], '💡': ['bulb', '#d4930a'], '🎉': ['star', '#d4930a']
  };

  /* ================= погода ================= */
  const W = {
    sun: '<circle cx="32" cy="32" r="12" fill="#ffc83d"/><g stroke="#ffc83d" stroke-width="4" stroke-linecap="round"><path d="M32 6v7M32 51v7M6 32h7M51 32h7M13.6 13.6l5 5M45.4 45.4l5 5M13.6 50.4l5-5M45.4 18.6l5-5"/></g>',
    cloud: (y = 0, c = '#fff', o = 1) => `<path transform="translate(0 ${y})" d="M20 50h26a10 10 0 0 0 1-20 13 13 0 0 0-25 3.5A8.3 8.3 0 0 0 20 50z" fill="${c}" opacity="${o}" stroke="#c9d6e6" stroke-width="1.5"/>`,
    drops: (n, c = '#3b8df0') => [...Array(n)].map((_, i) => `<path d="M${22 + i * 9} ${54 + (i % 2) * 3}l-3 6" stroke="${c}" stroke-width="3.5" stroke-linecap="round"/>`).join(''),
    flakes: n => [...Array(n)].map((_, i) => `<circle cx="${22 + i * 9}" cy="${57 + (i % 2) * 3}" r="2.6" fill="#9cc7f5"/>`).join('')
  };
  VOS.weatherIcon = (code, size = 64) => {
    const sunSmall = '<g transform="translate(-9 -10) scale(.8)">' + W.sun + '</g>';
    let body;
    if (code === 0) body = W.sun;
    else if (code <= 2) body = sunSmall + W.cloud(4);
    else if (code === 3) body = W.cloud(-6, '#e3eaf3') + W.cloud(2);
    else if (code === 45 || code === 48) body = W.cloud(-6) + '<path d="M14 52h36M18 58h28" stroke="#b9c7d8" stroke-width="3.5" stroke-linecap="round"/>';
    else if (code >= 51 && code <= 57) body = W.cloud(-6) + W.drops(3, '#6aaaf2');
    else if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) body = W.cloud(-6) + W.drops(4);
    else if ((code >= 71 && code <= 77) || code === 85 || code === 86) body = W.cloud(-6) + W.flakes(4);
    else if (code >= 95) body = W.cloud(-6, '#d5dde8') + '<path d="M33 44l-6 10h7l-4 9" stroke="#ffb21e" stroke-width="3.5" fill="none" stroke-linejoin="round" stroke-linecap="round"/>';
    else body = W.cloud(0);
    return `<svg class="wx" width="${size}" height="${size}" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">${body}</svg>`;
  };

  /* ================= обои ================= */
  const PAL = {
    sea:    ['#0a2342', '#14508a', '#2a8fc0', '#7fd3f0', '#3fb4ff'],
    forest: ['#0b2318', '#1a5a3a', '#3c9a5f', '#a7e3a1', '#6bd18a'],
    sunset: ['#26123a', '#6b2c66', '#d06a5a', '#ffc58a', '#ff8f6b'],
    calm:   ['#1d2531', '#38475c', '#6b819e', '#c9d6e6', '#9db4d2']
  };
  VOS.wallpaperURL = name => {
    const p = PAL[name] || PAL.sea;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice">
<defs><linearGradient id="b" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${p[0]}"/><stop offset=".6" stop-color="${p[1]}"/><stop offset="1" stop-color="${p[2]}"/></linearGradient>
<radialGradient id="g" cx=".22" cy=".18" r=".5"><stop offset="0" stop-color="${p[4]}" stop-opacity=".55"/><stop offset="1" stop-color="${p[4]}" stop-opacity="0"/></radialGradient>
<radialGradient id="g2" cx=".85" cy=".35" r=".45"><stop offset="0" stop-color="${p[3]}" stop-opacity=".25"/><stop offset="1" stop-color="${p[3]}" stop-opacity="0"/></radialGradient>
<linearGradient id="w1" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${p[3]}" stop-opacity=".10"/><stop offset=".5" stop-color="${p[3]}" stop-opacity=".28"/><stop offset="1" stop-color="${p[3]}" stop-opacity=".08"/></linearGradient>
<linearGradient id="w2" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${p[4]}" stop-opacity=".25"/><stop offset="1" stop-color="${p[2]}" stop-opacity=".35"/></linearGradient></defs>
<rect width="1600" height="900" fill="url(#b)"/><rect width="1600" height="900" fill="url(#g)"/><rect width="1600" height="900" fill="url(#g2)"/>
<path d="M0 560C260 470 470 650 760 590S1250 430 1600 520V900H0z" fill="url(#w1)"/>
<path d="M0 660C300 590 520 740 820 690S1300 560 1600 640V900H0z" fill="url(#w2)"/>
<path d="M0 760C320 700 600 820 900 780S1350 700 1600 740V900H0z" fill="${p[0]}" fill-opacity=".35"/>
<path d="M0 600C260 510 470 690 760 630S1250 470 1600 560" fill="none" stroke="${p[3]}" stroke-opacity=".35" stroke-width="2"/>
</svg>`;
    return 'url("data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg) + '")';
  };
  VOS.WALLPAPER_NAMES = { sea: 'Море', forest: 'Лес', sunset: 'Закат', calm: 'Туман' };
})();
