/*
 * «Родные» — карточки близких с фото и видеозвонок одним нажатием или голосом
 * («Василиса, позвони внуку»).
 *
 * Как устроен звонок:
 *  • у каждого родственника своя ссылка на видеовстречу: Яндекс Телемост,
 *    VK Звонки или Jitsi. Родственник создаёт постоянную встречу у себя и
 *    вписывает ссылку в карточку;
 *  • если ссылки нет — используется комната Jitsi на сервере из Настроек
 *    (по умолчанию без регистрации);
 *  • доверенным людям (ВКонтакте, запасной — Telegram) сразу приходит сообщение
 *    «Вячеслав звонит вам по видео» со ссылкой — как звонок на телефон.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const RELATIONS = ['внук', 'внучка', 'сын', 'дочь', 'жена', 'муж', 'брат', 'сестра', 'племянник', 'племянница', 'зять', 'невестка', 'друг', 'подруга', 'сосед', 'врач'];
  const fileUrl = p => 'file://' + String(p).split('/').map(encodeURIComponent).join('/');
  const norm = t => String(t || '').toLowerCase().replace(/ё/g, 'е');
  const stem = w => { w = norm(w); return w.length > 3 ? w.slice(0, Math.max(3, w.length - (/[аяыиоьй]$/.test(w) ? 1 : 0))) : w; };

  const all = () => VOS.store.get('contacts', []);
  const save = list => VOS.store.set('contacts', list);

  /* ---------- Telegram ---------- */
  // Сообщения уходят ТОЛЬКО доверенным людям из «Настройки → Родные и связь»
  // (по имени пользователя Telegram). Бот публичный: кто угодно может его
  // найти и нажать «Старт», но такие люди ничего не получат — ни ссылок на
  // звонки, ни номера для удалённой помощи. Бот сам никому не отвечает.
  const uname = u => String(u || '').trim().replace(/^@/, '').toLowerCase();
  VOS.tg = {
    trusted: () => String(VOS.settings.tgTrusted || '').split(/[\s,;]+/).map(uname).filter(Boolean),
    // узнать номера чатов доверенных людей (после того как они нажали «Старт»)
    async refresh() {
      const tok = VOS.settings.tgToken; if (!tok) return {};
      const want = VOS.tg.trusted();
      const known = { ...(VOS.settings.tgTrustedChats || {}) };
      for (const k of Object.keys(known)) if (!want.includes(k)) delete known[k];
      if (want.every(u => known[u])) { if (Object.keys(known).length !== Object.keys(VOS.settings.tgTrustedChats || {}).length) await VOS.saveSettings({ tgTrustedChats: known }); return known; }
      const chats = await B.call('tgChats', tok).catch(() => []);
      let changed = false;
      for (const ch of chats || []) {
        const u = uname(ch.username);
        if (u && want.includes(u) && known[u] !== ch.id) { known[u] = ch.id; changed = true; }
      }
      if (changed || Object.keys(known).length !== Object.keys(VOS.settings.tgTrustedChats || {}).length) await VOS.saveSettings({ tgTrustedChats: known });
      return known;
    },
    // отправить всем доверенным; вернуть, скольким ушло
    async sendAll(text) {
      const tok = VOS.settings.tgToken; if (!tok) return 0;
      const known = await VOS.tg.refresh();
      let n = 0;
      for (const id of new Set(Object.values(known))) { try { await B.call('tgSend', tok, id, text); n++; } catch (_) { /* нет связи */ } }
      return n;
    }
  };
  /* ---------- ВКонтакте — основной способ (работает в России без VPN) ----------
   * Сообщения пишет сообщество ВК (ключ доступа с правом «Сообщения
   * сообщества») и только доверенным людям из списка в Настройках. Каждый из
   * них должен один раз написать сообществу или нажать «Разрешить сообщения». */
  VOS.vk = {
    trusted: () => String(VOS.settings.vkTrusted || '').split(/[\s,;]+/).filter(Boolean),
    // ссылки/имена доверенных → id (ВК), запоминаются
    async refresh(force = false) {
      const tok = VOS.settings.vkToken; if (!tok) return {};
      const want = VOS.vk.trusted();
      const key = n => String(n).trim().replace(/^https?:\/\/(m\.)?vk\.(com|ru)\//i, '').replace(/^@/, '').replace(/[/?#].*$/, '').toLowerCase();
      const known = { ...(VOS.settings.vkTrustedIds || {}) };
      for (const k of Object.keys(known)) if (!want.map(key).includes(k)) delete known[k];
      const missing = want.filter(n => !known[key(n)]);
      if (missing.length || force) {
        const users = await B.call('vkResolve', tok, force ? want : missing).catch(() => []);
        const list = force ? want : missing;
        for (const n of list) {
          const k = key(n), u = users.find(x => String(x.screen).toLowerCase() === k || 'id' + x.id === k);
          if (k && u) known[k] = { id: u.id, name: u.name };
        }
      }
      await VOS.saveSettings({ vkTrustedIds: known });
      return known;
    },
    async sendAll(text) {
      const tok = VOS.settings.vkToken; if (!tok) return 0;
      const known = await VOS.vk.refresh().catch(() => VOS.settings.vkTrustedIds || {});
      let n = 0;
      for (const u of Object.values(known)) { try { await B.call('vkSend', tok, u.id, text); n++; } catch (_) { /* не разрешил сообщения или нет связи */ } }
      return n;
    }
  };
  // Всем доверенным: сначала ВКонтакте, затем Telegram (если вдруг работает)
  VOS.notifyFamily = async text => {
    const a = await VOS.vk.sendAll(text).catch(() => 0);
    const b = await VOS.tg.sendAll(text).catch(() => 0);
    return a + b;
  };
  // старое имя: сообщение «родственнику» теперь тоже уходит только доверенным
  VOS.notify = async (_contact, text) => (await VOS.notifyFamily(text)) > 0;
  // время от времени узнаём номера чатов тех, кто только что нажал «Старт»
  setInterval(() => { if (VOS.settings && VOS.settings.tgToken) VOS.tg.refresh().catch(() => {}); }, 10 * 60000);
  setTimeout(() => { if (VOS.settings && VOS.settings.tgToken) VOS.tg.refresh().catch(() => {}); }, 20000);

  /* ---------- ссылка на звонок ---------- */
  async function roomSeed() {
    let seed = VOS.settings.callRoomSeed;
    if (!seed) { seed = Math.random().toString(36).slice(2, 10); await VOS.saveSettings({ callRoomSeed: seed }); }
    return seed;
  }
  async function callUrl(c) {
    if (c.callUrl && /^https:\/\//.test(c.callUrl)) return c.callUrl;
    const server = (VOS.settings.jitsiServer || 'meet.ffmuc.net').replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    const room = 'Vyacheslav-' + (await roomSeed()) + '-' + c.id;
    return 'https://' + server + '/' + room + '#config.prejoinConfig.enabled=false&config.startWithVideoMuted=false&config.startWithAudioMuted=false&userInfo.displayName=%22' + encodeURIComponent(VOS.settings.name) + '%22';
  }
  VOS.callUrlFor = callUrl;

  /* ---------- поиск по фразе: «внуку», «Саше», «дочке Маше» ---------- */
  function match(list, phrase) {
    const words = norm(phrase).replace(/[^а-яa-z0-9 ]/g, ' ').split(/\s+/).filter(w => w.length >= 2);
    const scored = list.map(c => {
      let score = 0;
      const keys = [c.name, ...(c.nick ? String(c.nick).split(/[,\s]+/) : []), c.relation].filter(Boolean);
      for (const k of keys) {
        const st = stem(k);
        if (!st) continue;
        for (const w of words) if (w.startsWith(st) || (st.length >= 4 && st.startsWith(w.slice(0, st.length)))) score += k === c.relation ? 1 : 2;
      }
      return { c, score };
    }).filter(x => x.score > 0).sort((a, b) => b.score - a.score);
    if (!scored.length) return [];
    return scored.filter(x => x.score === scored[0].score).map(x => x.c);
  }

  async function startCall(c) {
    VOS.wm.open('call', { id: c.id });
  }

  VOS.contacts = {
    all, match,
    async callByPhrase(phrase) {
      const list = await all();
      if (!list.length) { VOS.wm.open('contacts'); return { say: 'Список родных пока пуст. Попросите внуков добавить себя в программу «Родные».' }; }
      const found = match(list, phrase);
      if (found.length === 1) { startCall(found[0]); return { say: 'Звоню: ' + found[0].name + '.' }; }
      const names = (found.length ? found : list).slice(0, 4).map(c => c.name);
      const say = (found.length ? 'Кому позвонить: ' : 'Не поняла, кому позвонить. ') + names.slice(0, -1).join(', ') + (names.length > 1 ? ' или ' : '') + names[names.length - 1] + '?';
      return {
        say: say.replace('поняла', VOS.gx('поняла', 'понял')),
        pending: async answer => {
          const again = match(found.length ? found : list, answer);
          if (again.length >= 1) { startCall(again[0]); return { say: 'Звоню: ' + again[0].name + '.' }; }
          return /^(никому|отмена|не надо|нет)/.test(norm(answer)) ? { say: 'Хорошо, не звоню.' } : null;
        }
      };
    },
    async birthdays(daysAhead = 30) {
      const list = await all(), now = new Date(), out = [];
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      for (const c of list) {
        if (!c.birthday) continue;
        const [mm, dd] = c.birthday.slice(-5).split('-').map(Number);
        let d = new Date(now.getFullYear(), mm - 1, dd);
        if (d < today) d = new Date(now.getFullYear() + 1, mm - 1, dd);
        const days = Math.round((d - today) / 864e5);
        if (days <= daysAhead) out.push({ c, days, date: d, age: /^\d{4}/.test(c.birthday) ? d.getFullYear() - +c.birthday.slice(0, 4) : null });
      }
      return out.sort((a, b) => a.days - b.days);
    },
    async birthdaysReply() {
      const b = await VOS.contacts.birthdays(60);
      if (!b.length) return { say: 'В ближайшие два месяца дней рождения у родных нет.' };
      const say = b.slice(0, 3).map(x => (x.days === 0 ? 'Сегодня' : x.days === 1 ? 'Завтра' : x.date.getDate() + ' ' + VOS.MONTHS[x.date.getMonth()]) + ' день рождения празднует ' + x.c.name + (x.age ? ', исполнится ' + x.age : '') + '.').join(' ');
      return { say };
    }
  };

  /* ---------- выбор фото из папки «Фото» ---------- */
  async function pickPhoto() {
    const photos = await B.call('photosList', null).catch(() => []);
    if (!photos.length) { VOS.ui.alert('Фотографий нет', 'Сначала скопируйте фотографии в папку «Фото» (программа «Фото» → «Флешка»).', 'ℹ️'); return null; }
    const grid = el('div.ph-grid.pick');
    let chosen = null;
    const p = VOS.ui.dialog({ title: 'Выберите фото', body: grid, buttons: [{ label: 'Отмена', value: null }] });
    photos.slice(0, 120).forEach(ph => grid.append(el('button.ph-item', { onclick: () => { chosen = ph.path; grid.closest('.dialog').querySelector('.btn').click(); } }, el('img', { src: fileUrl(ph.path), loading: 'lazy' }))));
    await p;
    return chosen;
  }

  function avatar(c, size = '') {
    const a = el('div.c-avatar' + size);
    if (c.photo) a.style.backgroundImage = 'url("' + fileUrl(c.photo) + '")';
    else { a.textContent = (c.name || '?')[0].toUpperCase(); a.style.setProperty('--h', [...String(c.name)].reduce((s, ch, i) => (s * 31 + ch.charCodeAt(0) * (i + 7)) % 3600, 17) % 360); }
    return a;
  }
  VOS.contactAvatar = avatar;

  /* ---------- карточка: изменить ---------- */
  async function edit(c) {
    const isNew = !c;
    c = c ? { ...c } : { id: VOS.uid(), name: '', relation: 'внук', birthday: '', phone: '', callUrl: '', tgChat: '', helper: true, photo: '' };
    const name = el('input.big-input', { value: c.name, placeholder: 'Имя, например: Саша' });
    const rel = el('select.big-select'); RELATIONS.forEach(r => rel.append(el('option', { value: r, text: r, selected: r === c.relation })));
    const bday = el('input.big-input', { type: 'date', value: /^\d{4}-\d{2}-\d{2}$/.test(c.birthday) ? c.birthday : '' });
    const phone = el('input.big-input', { value: c.phone, placeholder: '+7 …' });
    const url = el('input.big-input', { value: c.callUrl, placeholder: 'https://telemost.yandex.ru/j/…  (необязательно)' });
    const tg = el('input.big-input', { value: c.tgChat, placeholder: 'номер чата в Telegram (необязательно)' });
    const helper = el('input', { type: 'checkbox', checked: c.helper !== false });
    const photoPrev = avatar(c, '.small');
    const linkInfo = el('div.muted.small');
    const showLink = async () => { linkInfo.textContent = url.value.trim() ? '' : 'Без своей ссылки звонок пойдёт сюда (родственнику удобно сохранить в закладки): ' + (await callUrl({ ...c, callUrl: '' })).split('#')[0]; };
    url.addEventListener('input', showLink); showLink();
    const body = el('div.form.contact-form', null,
      el('div.row', null, photoPrev, el('button.btn', { text: '🖼 Выбрать фото', onclick: async () => { const p = await pickPhoto(); if (p) { c.photo = p; photoPrev.replaceWith(avatar(c, '.small')); } } }),
        c.photo ? el('button.btn.small', { text: 'Убрать фото', onclick: e => { c.photo = ''; e.target.remove(); } }) : null),
      el('label', { text: 'Имя' }), name,
      el('label', { text: 'Кем приходится' }), rel,
      el('label', { text: 'День рождения' }), bday,
      el('label', { text: 'Телефон (для справки)' }), phone,
      el('label', { text: 'Ссылка на видеовстречу' }), url, linkInfo,
      el('div.muted.small', { text: 'Сообщения о звонках и просьбах о помощи получают только доверенные люди (Настройки → Родные и связь).' }),
      el('label.check', null, helper, ' Помогает с компьютером (получит сообщение, если дедушка попросит помощи)'));
    const res = await VOS.ui.dialog({ title: isNew ? 'Новый родственник' : 'Изменить: ' + c.name, body, cls: 'wide-dialog',
      buttons: [isNew ? null : { label: 'Удалить', value: 'del', danger: true }, { label: 'Отмена', value: null }, { label: 'Сохранить', value: 'ok', primary: true }].filter(Boolean) });
    const list = await all();
    if (res === 'del') {
      if (await VOS.ui.confirm({ title: 'Удалить ' + c.name + '?', yes: 'Удалить', danger: true })) await save(list.filter(x => x.id !== c.id));
      return;
    }
    if (res !== 'ok') return;
    if (!name.value.trim()) return VOS.ui.toast('Напишите имя');
    Object.assign(c, { name: name.value.trim(), relation: rel.value, birthday: bday.value, phone: phone.value.trim(), callUrl: url.value.trim(), tgChat: tg.value.trim(), helper: helper.checked });
    const i = list.findIndex(x => x.id === c.id);
    if (i >= 0) list[i] = c; else list.push(c);
    await save(list);
  }

  VOS.registerApp({
    id: 'contacts', title: 'Родные', width: 1080, height: 700,
    words: ['родные', 'родных', 'контакты', 'семья', 'позвонить', 'видеозвонок', 'звонок'],
    open(w) {
      const grid = el('div.c-grid');
      async function render() {
        const list = await all();
        grid.textContent = '';
        list.forEach((c, i) => {
          const card = el('div.c-card', { style: { animationDelay: i * 40 + 'ms' } },
            avatar(c, '.big'),
            el('div.c-name', { text: c.name }),
            el('div.c-rel.muted', { text: c.relation || '' }),
            el('button.btn.primary.big.c-call', { text: '@video', onclick: () => startCall(c) }),
            el('button.c-edit', { text: '@edit', title: 'Изменить', onclick: async () => { await edit(c); render(); } }));
          card.querySelector('.c-call').append('Позвонить');
          grid.append(card);
        });
        grid.append(el('button.c-card.c-add', { onclick: async () => { await edit(null); render(); } }, el('div.c-plus', { html: VOS.glyph('plus') }), el('div', { text: 'Добавить' })));
      }
      const b = makeBdays();
      w.body.append(el('div.app-pad', null,
        el('div.toolbar', null, el('h2', { text: 'Кому позвонить?' }), el('span.spacer'), el('span.muted', { text: 'Можно сказать: «' + VOS.assistantName() + ', позвони внуку»' })),
        b, grid));
      render();
      async function fillB() {
        const list = await VOS.contacts.birthdays(14);
        b.textContent = '';
        list.forEach(x => b.append(el('div.bday', null, VOS.gl('star'), el('span', { text: (x.days === 0 ? 'Сегодня' : x.days === 1 ? 'Завтра' : 'Через ' + x.days + ' ' + VOS.plural(x.days, 'день', 'дня', 'дней')) + ' день рождения: ' + x.c.name + (x.age ? ' (' + x.age + ')' : '') }),
          x.days <= 1 ? el('button.btn.small.primary', { text: 'Поздравить', onclick: () => startCall(x.c) }) : null)));
      }
      function makeBdays() { const d = el('div.bdays'); setTimeout(fillB, 0); return d; }
    }
  });

  /* ---------- окно видеозвонка ---------- */
  VOS.registerApp({
    id: 'call', title: 'Видеозвонок', hidden: true, desktop: false, width: 1100, height: 700, maximized: true, single: true,
    async open(w, args) {
      const list = await all();
      const c = list.find(x => x.id === args.id);
      if (!c) { w.body.append(el('div.empty', { text: 'Контакт не найден' })); return; }
      w.setTitle(c.name);
      const url = await callUrl(c);
      const release = VOS.voice ? VOS.voice.hold() : () => {};     // микрофон отдаём звонку
      const notified = (await VOS.notifyFamily('📞 ' + VOS.settings.name + ' звонит по видео' + (c.name ? ' (' + c.relation + ' ' + c.name + ')' : '') + '!\nНажмите, чтобы ответить: ' + url.split('#')[0])) > 0;
      const head = el('div.call-head', null, avatar(c, '.small'), el('div', null, el('b', { text: c.name }), el('div.muted', { text: notified ? 'Сообщение о звонке отправлено родным' : 'Ждём, когда ' + c.name + ' подключится' })),
        el('span.spacer'), el('button.btn.danger.big', { text: '@close', onclick: () => VOS.wm.close(w) }));
      head.querySelector('.btn.danger').append('Завершить');
      const view = VOS.isNative ? el('webview', { src: url, partition: 'persist:call', class: 'web-view', allowpopups: true }) : el('iframe', { src: 'about:blank', class: 'web-view' });
      w.body.append(el('div.browser', null, head, el('div.web-wrap', null, view)));
      if (!VOS.isNative) w.body.querySelector('.web-wrap').append(el('div.empty.call-mock', { text: 'Здесь откроется видеозвонок: ' + url.split('#')[0] }));
      VOS.sound.chime();
      return () => { release(); try { view.src = 'about:blank'; } catch (_) { /* */ } };
    }
  });
})();
