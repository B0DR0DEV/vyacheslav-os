/*
 * «Помощь с компьютером» — удалённая помощь родных через RustDesk.
 *
 * На ноутбуке дедушки RustDesk работает постоянно. У ноутбука есть номер
 * (ID) и постоянный пароль, который один раз задают родные. Тогда внук
 * со своего компьютера или телефона (приложение RustDesk) вводит номер и
 * пароль — и видит экран дедушки, может нажимать и печатать за него.
 *
 * Дедушке достаточно сказать: «Василиса, помоги с компьютером» —
 * доверенным людям придёт сообщение (ВКонтакте или Telegram)
 * с номером для подключения.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const fmtId = id => String(id || '').replace(/(\d{3})(?=\d)/g, '$1 ');
  const sayId = id => String(id || '').split('').join(' ');

  async function getId() {
    const r = await B.call('rustdesk', 'id').catch(() => null);
    return r && r.available ? r.id : null;
  }

  VOS.help = {
    async request() {
      VOS.wm.open('help');
      const id = await getId();
      const sent = await VOS.notifyFamily('🆘 ' + VOS.settings.name + ' просит помочь с компьютером.\n' + (id ? 'Номер для RustDesk: ' + fmtId(id) + '\nОткройте RustDesk и подключитесь по этому номеру с постоянным паролем.' : 'Позвоните, пожалуйста.'));
      if (sent) return { say: 'Я ' + VOS.gx('отправила', 'отправил') + ' сообщение родным. Скоро вам помогут. Ничего не выключайте.' };
      if (id) return { say: 'Позвоните родным и продиктуйте номер вашего компьютера: ' + sayId(id) + '. Он показан на экране крупно.' };
      return { say: 'Позвоните родным по телефону — они подскажут.' };
    }
  };

  VOS.registerApp({
    id: 'help', title: 'Помощь с компьютером', width: 900, height: 640,
    words: ['помощь', 'помощь с компьютером', 'удалённая помощь', 'удаленная помощь', 'rustdesk', 'раст деск'],
    open(w) {
      const idBox = el('div.h-id', { text: '…' });
      const status = el('div.muted');
      const sendBtn = el('button.btn.primary.huge', { text: '📤 Позвать родных на помощь', onclick: async () => { sendBtn.disabled = true; const r = await VOS.help.request(); VOS.assistant.announce(r.say); sendBtn.disabled = false; } });
      async function load() {
        const r = await B.call('rustdesk', 'id').catch(() => null);
        if (!r || !r.available) { idBox.textContent = '—'; status.textContent = 'Программа удалённой помощи (RustDesk) не установлена.'; return; }
        if (!r.id) { idBox.textContent = '…'; status.textContent = 'Служба запускается, номер появится через минуту.'; setTimeout(load, 10000); return; }
        idBox.textContent = fmtId(r.id);
        status.textContent = 'Скажите этот номер родным, если они попросят.';
      }
      const family = el('details.h-family', null,
        el('summary', { text: 'Для родных: как настроить' }),
        el('ol', null,
          el('li', { text: 'Установите RustDesk себе на компьютер или телефон (rustdesk.com, бесплатно).' }),
          el('li', { text: 'Задайте постоянный пароль кнопкой ниже и сохраните его у себя.' }),
          el('li', { text: 'В RustDesk введите номер компьютера дедушки и этот пароль — и вы увидите его экран.' }),
          el('li', { text: 'Чтобы получать просьбы о помощи: Настройки → Родные и связь → ВКонтакте (сообщество и доверенные люди).' })),
        el('button.btn', { text: '🔒 Задать постоянный пароль', onclick: async () => {
          const p1 = await VOS.ui.prompt({ title: 'Постоянный пароль RustDesk', text: 'От 6 символов, латинские буквы и цифры. Сохраните его у себя.', type: 'password' });
          if (!p1) return;
          const r = await B.call('rustdesk', 'password', p1).catch(e => ({ error: e.message }));
          VOS.ui.alert(r && r.ok ? 'Пароль задан' : 'Не получилось', r && r.ok ? 'Теперь родные могут подключаться по номеру и паролю.' : String((r && r.error) || 'ошибка'), r && r.ok ? '🔒' : '⚠️');
        } }));
      w.body.append(el('div.app-pad.help', null,
        el('div.h-hero', null,
          el('div.h-ic', { html: VOS.appIcon('help', 96) }),
          el('div', null, el('h2', { text: 'Родные могут помочь на расстоянии' }), el('p.muted', { text: 'Они увидят ваш экран и сами всё настроят. Вам ничего нажимать не нужно.' }))),
        el('div.h-card', null, el('div.muted', { text: 'Номер этого компьютера' }), idBox, status),
        el('div.row.center', null, sendBtn, el('button.btn.huge', { text: '@video', onclick: () => VOS.wm.open('contacts') }, 'Позвонить родным')),
        family));
      load();
    }
  });
})();
