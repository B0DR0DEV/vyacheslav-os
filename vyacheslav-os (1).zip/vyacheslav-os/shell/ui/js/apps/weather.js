/*
 * Погода на неделю. Источники (бесплатно, без ключей) пробуются по очереди:
 * Open-Meteo → MET Norway → wttr.in. Последний прогноз сохраняется на сутки.
 * Город берётся из Настроек; его можно поменять прямо здесь.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  const WMO = {
    0: ['☀️', 'Ясно'], 1: ['🌤', 'Почти ясно'], 2: ['⛅', 'Переменная облачность'], 3: ['☁️', 'Пасмурно'],
    45: ['🌫', 'Туман'], 48: ['🌫', 'Изморозь'], 51: ['🌦', 'Слабая морось'], 53: ['🌦', 'Морось'], 55: ['🌧', 'Сильная морось'],
    56: ['🌧', 'Ледяная морось'], 57: ['🌧', 'Ледяная морось'], 61: ['🌦', 'Небольшой дождь'], 63: ['🌧', 'Дождь'], 65: ['🌧', 'Сильный дождь'],
    66: ['🌧', 'Ледяной дождь'], 67: ['🌧', 'Ледяной дождь'], 71: ['🌨', 'Небольшой снег'], 73: ['🌨', 'Снег'], 75: ['❄️', 'Сильный снег'],
    77: ['🌨', 'Снежная крупа'], 80: ['🌦', 'Ливень'], 81: ['🌧', 'Ливень'], 82: ['⛈', 'Сильный ливень'],
    85: ['🌨', 'Снегопад'], 86: ['❄️', 'Сильный снегопад'], 95: ['⛈', 'Гроза'], 96: ['⛈', 'Гроза с градом'], 99: ['⛈', 'Гроза с градом']
  };
  const wmo = c => WMO[c] || ['🌡', 'Погода'];
  const sayT = t => { const n = Math.round(t); return n < 0 ? 'минус ' + Math.abs(n) : String(n); };
  const deg0 = t => Math.round(t) === 0 ? 0 : t;
  const deg = t => (Math.round(t) > 0 ? '+' : Math.round(t) < 0 ? '−' : '') + Math.abs(Math.round(t)) + '°';

  /* ---------- где город ----------
   * Сначала встроенный список (интернет не нужен), потом сервисы поиска
   * по очереди. Найденное запоминается навсегда. */
  const CITIES = {
    'москва': [55.76, 37.62], 'санкт-петербург': [59.94, 30.31], 'петербург': [59.94, 30.31], 'спб': [59.94, 30.31], 'новосибирск': [55.03, 82.92],
    'екатеринбург': [56.84, 60.61], 'казань': [55.79, 49.12], 'нижний новгород': [56.33, 44.0], 'челябинск': [55.16, 61.4], 'самара': [53.2, 50.15],
    'омск': [54.99, 73.37], 'ростов-на-дону': [47.23, 39.72], 'уфа': [54.74, 55.97], 'красноярск': [56.01, 92.89], 'воронеж': [51.67, 39.18],
    'пермь': [58.01, 56.25], 'волгоград': [48.71, 44.51], 'краснодар': [45.04, 38.98], 'саратов': [51.53, 46.03], 'тюмень': [57.15, 65.53],
    'тольятти': [53.51, 49.42], 'ижевск': [56.85, 53.2], 'барнаул': [53.35, 83.78], 'ульяновск': [54.31, 48.4], 'иркутск': [52.29, 104.28],
    'хабаровск': [48.48, 135.08], 'ярославль': [57.63, 39.87], 'владивосток': [43.12, 131.89], 'махачкала': [42.98, 47.5], 'томск': [56.48, 84.95],
    'оренбург': [51.77, 55.1], 'кемерово': [55.35, 86.09], 'новокузнецк': [53.76, 87.12], 'рязань': [54.63, 39.74], 'астрахань': [46.35, 48.04],
    'набережные челны': [55.74, 52.4], 'пенза': [53.2, 45.0], 'липецк': [52.61, 39.59], 'киров': [58.6, 49.66], 'чебоксары': [56.15, 47.25],
    'тула': [54.19, 37.62], 'калининград': [54.71, 20.51], 'курск': [51.73, 36.19], 'улан-удэ': [51.83, 107.58], 'ставрополь': [45.04, 41.97],
    'сочи': [43.6, 39.73], 'тверь': [56.86, 35.9], 'иваново': [57.0, 40.97], 'брянск': [53.24, 34.36], 'белгород': [50.6, 36.59],
    'сургут': [61.25, 73.4], 'владимир': [56.13, 40.41], 'архангельск': [64.54, 40.54], 'смоленск': [54.78, 32.05], 'калуга': [54.51, 36.26],
    'мурманск': [68.97, 33.08], 'вологда': [59.22, 39.89], 'псков': [57.82, 28.33], 'великий новгород': [58.52, 31.27], 'петрозаводск': [61.79, 34.36],
    'кострома': [57.77, 40.93], 'орел': [52.97, 36.06], 'тамбов': [52.72, 41.45], 'симферополь': [44.95, 34.1], 'севастополь': [44.62, 33.53],
    'якутск': [62.03, 129.73], 'чита': [52.03, 113.5], 'подольск': [55.43, 37.54], 'химки': [55.89, 37.44], 'балашиха': [55.8, 37.94],
    'королев': [55.92, 37.82], 'мытищи': [55.91, 37.73], 'люберцы': [55.68, 37.89], 'коломна': [55.08, 38.78], 'сергиев посад': [56.31, 38.13],
    'обнинск': [55.1, 36.61], 'дмитров': [56.34, 37.52], 'новороссийск': [44.72, 37.77], 'анапа': [44.89, 37.32], 'пятигорск': [44.05, 43.06],
    'череповец': [59.13, 37.9], 'магнитогорск': [53.41, 58.98], 'нижний тагил': [57.92, 59.97], 'стерлитамак': [53.63, 55.95], 'грозный': [43.32, 45.69],
    'йошкар-ола': [56.63, 47.89], 'саранск': [54.19, 45.18], 'сыктывкар': [61.67, 50.84], 'нальчик': [43.49, 43.62], 'владикавказ': [43.02, 44.68]
  };
  const ckey = c => String(c || '').trim().toLowerCase().replace(/ё/g, 'е').replace(/^г\.?\s*/, '');
  const cap = c => String(c).trim().replace(/(^|[\s-])([а-яёa-z])/g, (m, a, b) => a + b.toUpperCase());
  async function geocode(city) {
    const k = ckey(city);
    if (CITIES[k]) return { lat: CITIES[k][0], lon: CITIES[k][1], name: cap(city), region: '' };
    const tries = [
      async () => { const r = await B.call('httpGetJson', 'https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&format=json&name=' + encodeURIComponent(city));
        const x = r.results && r.results[0]; return x && { lat: x.latitude, lon: x.longitude, name: x.name, region: x.admin1 || '' }; },
      async () => { const r = await B.call('httpGetJson', 'https://photon.komoot.io/api/?limit=1&q=' + encodeURIComponent(city));
        const x = r.features && r.features[0]; return x && { lat: x.geometry.coordinates[1], lon: x.geometry.coordinates[0], name: x.properties.name || cap(city), region: x.properties.state || '' }; },
      async () => { const r = await B.call('httpGetJson', 'https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=ru&q=' + encodeURIComponent(city));
        const x = r && r[0]; return x && { lat: +x.lat, lon: +x.lon, name: cap(city), region: '' }; }
    ];
    let netErr = null, answered = false;
    for (const t of tries) {
      try { const g = await t(); answered = true; if (g) return g; } catch (e) { netErr = e; }
    }
    if (answered) throw new Error('Город «' + city + '» не найден');
    throw netErr || new Error('нет связи');
  }

  /* ---------- прогноз: три источника по очереди ----------
   * Все ответы приводятся к одному виду (как у Open-Meteo):
   * current{temperature_2m, apparent_temperature, weather_code, wind_speed_10m, relative_humidity_2m, surface_pressure}
   * daily{time[], weather_code[], temperature_2m_max[], temperature_2m_min[], precipitation_probability_max[], wind_speed_10m_max[]} */
  const dkey = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  async function fromOpenMeteo(g) {
    return B.call('httpGetJson', 'https://api.open-meteo.com/v1/forecast?latitude=' + g.lat + '&longitude=' + g.lon +
      '&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m,surface_pressure' +
      '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max' +
      '&timezone=auto&forecast_days=16&wind_speed_unit=ms');
  }
  // MET Norway: символы погоды → коды WMO
  function metCode(sym) {
    const s = String(sym || '').replace(/_(day|night|polartwilight)$/, '');
    if (/thunder/.test(s)) return 95;
    if (/^heavysleet|^heavysleetshowers/.test(s)) return 67;
    if (/sleet/.test(s)) return 66;
    if (/^heavysnow/.test(s)) return 75;
    if (/^lightsnow/.test(s)) return 71;
    if (/snow/.test(s)) return 73;
    if (/^heavyrain/.test(s)) return /showers/.test(s) ? 82 : 65;
    if (/^lightrain/.test(s)) return /showers/.test(s) ? 80 : 61;
    if (/rain/.test(s)) return /showers/.test(s) ? 81 : 63;
    return { clearsky: 0, fair: 1, partlycloudy: 2, cloudy: 3, fog: 45 }[s] ?? 3;
  }
  async function fromMetNo(g) {
    const r = await B.call('httpGetJson', 'https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=' + (+g.lat).toFixed(3) + '&lon=' + (+g.lon).toFixed(3));
    const ts = (r.properties && r.properties.timeseries) || [];
    if (!ts.length) throw new Error('пустой ответ');
    const n = ts[0].data, det = n.instant.details;
    const sym = x => (x.next_1_hours || x.next_6_hours || x.next_12_hours || {}).summary;
    const current = { temperature_2m: det.air_temperature, apparent_temperature: det.air_temperature, weather_code: metCode((sym(n) || {}).symbol_code),
      wind_speed_10m: det.wind_speed || 0, relative_humidity_2m: Math.round(det.relative_humidity || 0), surface_pressure: det.air_pressure_at_sea_level || 1013 };
    const days = new Map();
    for (const t of ts) {
      const d = new Date(t.time), k = dkey(d), x = t.data, v = x.instant.details;
      if (!days.has(k)) days.set(k, { max: -99, min: 99, wind: 0, rain: 0, code: null, codeHour: 99 });
      const day = days.get(k);
      day.max = Math.max(day.max, v.air_temperature); day.min = Math.min(day.min, v.air_temperature); day.wind = Math.max(day.wind, v.wind_speed || 0);
      const p = (x.next_1_hours || x.next_6_hours || {}).details; if (p && p.precipitation_amount) day.rain += p.precipitation_amount;
      const sc = sym(x); const off = Math.abs(d.getHours() - 13);
      if (sc && off < day.codeHour) { day.code = metCode(sc.symbol_code); day.codeHour = off; }
    }
    const keys = [...days.keys()].slice(0, 7);
    return { current, daily: { time: keys, weather_code: keys.map(k => days.get(k).code ?? 3), temperature_2m_max: keys.map(k => days.get(k).max), temperature_2m_min: keys.map(k => days.get(k).min),
      precipitation_probability_max: keys.map(k => { const mm = days.get(k).rain; return mm >= 3 ? 80 : mm >= 0.5 ? 55 : mm > 0 ? 25 : 5; }), wind_speed_10m_max: keys.map(k => days.get(k).wind) } };
  }
  // wttr.in: коды WorldWeatherOnline → WMO
  const WWO = { 113: 0, 116: 2, 119: 3, 122: 3, 143: 45, 248: 45, 260: 45, 176: 80, 263: 51, 266: 53, 281: 56, 284: 57, 293: 61, 296: 61, 299: 63, 302: 63, 305: 65, 308: 65,
    311: 66, 314: 67, 317: 66, 320: 67, 350: 77, 353: 80, 356: 81, 359: 82, 362: 66, 365: 67, 368: 85, 371: 86, 374: 77, 377: 77, 179: 71, 182: 66, 185: 56,
    227: 75, 230: 75, 323: 71, 326: 71, 329: 73, 332: 73, 335: 75, 338: 75, 200: 95, 386: 95, 389: 95, 392: 96, 395: 96 };
  async function fromWttr(g) {
    const r = await B.call('httpGetJson', 'https://wttr.in/' + (+g.lat).toFixed(3) + ',' + (+g.lon).toFixed(3) + '?format=j1');
    const c = r.current_condition[0];
    const ms = kmh => Math.round((+kmh || 0) / 3.6 * 10) / 10;
    const current = { temperature_2m: +c.temp_C, apparent_temperature: +c.FeelsLikeC, weather_code: WWO[+c.weatherCode] ?? 3, wind_speed_10m: ms(c.windspeedKmph), relative_humidity_2m: +c.humidity, surface_pressure: +c.pressure };
    const w = r.weather || [];
    const noon = d => (d.hourly && (d.hourly[4] || d.hourly[0])) || {};
    return { current, daily: { time: w.map(d => d.date), weather_code: w.map(d => WWO[+noon(d).weatherCode] ?? 3), temperature_2m_max: w.map(d => +d.maxtempC), temperature_2m_min: w.map(d => +d.mintempC),
      precipitation_probability_max: w.map(d => Math.max(0, ...(d.hourly || []).map(h => Math.max(+h.chanceofrain || 0, +h.chanceofsnow || 0)))),
      wind_speed_10m_max: w.map(d => Math.max(0, ...(d.hourly || []).map(h => ms(h.windspeedKmph)))) } };
  }
  const SOURCES = [['Open-Meteo', fromOpenMeteo], ['MET Norway', fromMetNo], ['wttr.in', fromWttr]];

  /* Дальше 16 дней настоящего прогноза не бывает ни у кого. Для «месяца»
   * дни после прогноза показываем «как обычно бывает»: среднее за эти же
   * числа трёх прошлых лет (архив Open-Meteo), помечено «примерно». */
  async function climate(g, fromKey, count) {
    const cacheKey = (+g.lat).toFixed(2) + ',' + (+g.lon).toFixed(2) + ',' + fromKey + ',' + count;
    const cache = await VOS.store.get('wxClimate', {});
    if (cache[cacheKey] && Date.now() - cache[cacheKey].at < 3 * 864e5) return cache[cacheKey].days;
    const start = new Date(fromKey + 'T12:00'), end = new Date(start.getTime() + (count - 1) * 864e5);
    const years = [1, 2, 3].map(n => {
      const a = new Date(start), b = new Date(end);
      a.setFullYear(a.getFullYear() - n); b.setFullYear(b.getFullYear() - n);
      return [dkey(a), dkey(b)];
    });
    const sums = Array.from({ length: count }, () => ({ max: 0, min: 0, rain: 0, n: 0 }));
    for (const [a, b] of years) {
      try {
        const r = await B.call('httpGetJson', 'https://archive-api.open-meteo.com/v1/archive?latitude=' + g.lat + '&longitude=' + g.lon +
          '&start_date=' + a + '&end_date=' + b + '&daily=temperature_2m_max,temperature_2m_min,precipitation_sum&timezone=auto');
        const d = r.daily || {};
        (d.time || []).forEach((_, i) => {
          if (i >= count || d.temperature_2m_max[i] == null) return;
          sums[i].max += d.temperature_2m_max[i]; sums[i].min += d.temperature_2m_min[i]; sums[i].rain += (d.precipitation_sum[i] || 0) > 1 ? 1 : 0; sums[i].n++;
        });
      } catch (_) { /* один год не пришёл — посчитаем по остальным */ }
    }
    if (!sums.some(x => x.n)) throw new Error('нет данных');
    const days = sums.map((x, i) => x.n ? { date: dkey(new Date(start.getTime() + i * 864e5)), max: x.max / x.n, min: x.min / x.n, rainChance: Math.round(x.rain / x.n * 100) } : null).filter(Boolean);
    cache[cacheKey] = { at: Date.now(), days };
    for (const k of Object.keys(cache)) if (Date.now() - cache[k].at > 3 * 864e5) delete cache[k];
    VOS.store.set('wxClimate', cache);
    return days;
  }

  VOS.weather = {
    async get(city) {
      const cache = await VOS.store.get('geo', {});
      let g = cache[city];
      if (!g) { g = await geocode(city); cache[city] = g; await VOS.store.set('geo', cache); }
      // какой источник сработал в прошлый раз — с того и начинаем
      const pref = await VOS.store.get('wxSource', '');
      const order = SOURCES.slice().sort((a, b) => (b[0] === pref) - (a[0] === pref));
      let lastErr;
      for (const [name, fn] of order) {
        try {
          const f = await fn(g);
          if (!f || !f.current || !f.daily || !f.daily.time.length) throw new Error('пустой ответ');
          if (name !== pref) VOS.store.set('wxSource', name);
          const res = { place: g, f, source: name, at: Date.now() };
          const saved = await VOS.store.get('wxLast', {}); saved[city] = res; VOS.store.set('wxLast', saved);
          return res;
        } catch (e) { lastErr = e; }
      }
      // все источники недоступны — показываем последний прогноз (до суток)
      const saved = (await VOS.store.get('wxLast', {}))[city];
      if (saved && Date.now() - saved.at < 24 * 3600e3) return { ...saved, stale: true };
      throw lastErr || new Error('нет связи');
    },
    climate,
    // «Василиса, погода на завтра»
    tomorrow({ place, f }) {
      const d = f.daily;
      if (!d.time[1]) return 'Прогноза на завтра пока нет.';
      return 'Завтра в городе ' + place.name + ' днём до ' + sayT(d.temperature_2m_max[1]) + ', ночью до ' + sayT(d.temperature_2m_min[1]) + ', ' + wmo(d.weather_code[1])[1].toLowerCase() + '.' +
        ((d.precipitation_probability_max[1] ?? 0) >= 50 ? ' Возможны осадки, возьмите зонт.' : '');
    },
    summary({ place, f }) {
      const c = f.current, d = f.daily;
      return 'Сейчас в городе ' + place.name + ' ' + deg(c.temperature_2m).replace('+', 'плюс ').replace('−', 'минус ').replace('°', ' ' + VOS.plural(Math.abs(Math.round(c.temperature_2m)), 'градус', 'градуса', 'градусов')) + ', ' + wmo(c.weather_code)[1].toLowerCase() +
        '. Днём до ' + sayT(d.temperature_2m_max[0]) + ', ночью до ' + sayT(d.temperature_2m_min[0]) + '.' +
        (d.precipitation_probability_max[0] >= 50 ? ' Возможны осадки, возьмите зонт.' : '');
    }
  };

  VOS.registerApp({
    id: 'weather', title: 'Погода', width: 1100, height: 700, maximized: true,
    words: ['погода', 'погоду', 'прогноз', 'температура'],
    open(w, args) {
      w.args = args || {};
      const box = el('div.weather');
      const cityIn = el('input.big-input', { value: VOS.settings.city });
      let last = null;
      // срок прогноза: 3 дня, неделя, 2 недели, месяц
      const PERIODS = [[3, '3 дня'], [7, 'Неделя'], [14, '2 недели'], [30, 'Месяц']];
      let period = 7;
      const periodBar = el('div.chip-bar.w-periods');
      const paintPeriods = () => periodBar.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', +c.dataset.d === period));
      PERIODS.forEach(([d, label]) => periodBar.append(el('button.chip', { 'data-d': d, text: label, onclick: () => { period = d; VOS.store.set('wxPeriod', d); paintPeriods(); if (last) paint(); } })));
      VOS.store.get('wxPeriod', 7).then(v => { if (PERIODS.some(p => p[0] === +v)) { period = +v; paintPeriods(); if (last) paint(); } });
      paintPeriods();

      const dayTile = (dt, i, o) => el('div.w-day' + (i === 0 ? '.today' : '') + (o.approx ? '.approx' : ''), null,
        el('b', { text: i === 0 ? 'Сегодня' : i === 1 ? 'Завтра' : VOS.WEEKDAYS[dt.getDay()].replace(/^./, c => c.toUpperCase()) }),
        el('div.muted.small', { text: dt.getDate() + ' ' + VOS.MONTHS[dt.getMonth()] }),
        el('div.w-icon' + (o.approx ? '.w-approx-ic' : ''), { html: VOS.weatherIcon(o.approx ? (o.rainChance >= 67 ? 61 : o.rainChance >= 34 ? 2 : 1) : o.code, 56) }),
        el('div.w-max', { text: deg(o.max) }), el('div.w-min', { text: deg(o.min) }),
        el('div.small', { text: o.approx ? 'обычно так' : wmo(o.code)[1] }),
        el('div.small.muted', { text: o.approx ? (o.rainChance >= 67 ? 'обычно осадки' : o.rainChance >= 34 ? 'бывают осадки' : 'обычно сухо') : 'осадки ' + (o.rain ?? 0) + '% · ветер ' + Math.round(o.wind) + ' м/с' }));

      let paintId = 0;
      async function paint() {
        const my = ++paintId;
        const { place, f } = last, d = f.daily;
        const old = box.querySelector('.w-days-wrap'); if (old) old.remove();
        box.classList.toggle('long', period > 7);
        const wrap = el('div.w-days-wrap');
        const days = el('div.w-days' + (period > 7 ? '.compact' : ''));
        const n = Math.min(period, d.time.length);
        for (let i = 0; i < n; i++) {
          days.append(dayTile(new Date(d.time[i] + 'T12:00'), i, { code: d.weather_code[i], max: d.temperature_2m_max[i], min: d.temperature_2m_min[i], rain: d.precipitation_probability_max[i], wind: d.wind_speed_10m_max[i] }));
        }
        wrap.append(days);
        const notes = [];
        if (period > d.time.length && period <= 16) notes.push('Этот источник погоды даёт прогноз только на ' + d.time.length + ' ' + VOS.plural(d.time.length, 'день', 'дня', 'дней') + '.');
        if (period > 16) {
          const lastDay = new Date(d.time[d.time.length - 1] + 'T12:00');
          const fromKey = dkey(new Date(lastDay.getTime() + 864e5));
          const need = period - d.time.length;
          const hint = el('div.muted.small.w-note', { text: 'Дальше — примерно, как обычно бывает в эти дни (по прошлым годам). Загружаю…' });
          wrap.append(hint);
          climate(place, fromKey, need).then(cd => {
            if (my !== paintId) return;
            cd.forEach((x, j) => days.append(dayTile(new Date(x.date + 'T12:00'), d.time.length + j, { approx: true, max: x.max, min: x.min, rainChance: x.rainChance })));
            hint.textContent = 'Первые ' + d.time.length + ' ' + VOS.plural(d.time.length, 'день', 'дня', 'дней') + ' — прогноз. Дальше (серые) — не прогноз, а как обычно бывает в эти дни по прошлым трём годам. Точный прогноз на месяц вперёд не может дать никто.';
          }).catch(() => { if (my === paintId) hint.textContent = 'Дальше ' + d.time.length + ' дней прогноза нет, а данные за прошлые годы сейчас недоступны.'; });
        }
        if (notes.length) wrap.append(el('div.muted.small.w-note', { text: notes.join(' ') }));
        wrap.append(el('div.muted.small.w-src', { text: 'Источник: ' + last.source }));
        box.append(wrap);
      }
      async function load() {
        box.textContent = ''; box.append(el('div.empty', { text: 'Загружаю прогноз…' }));
        try { last = await VOS.weather.get(cityIn.value.trim() || VOS.settings.city); }
        catch (e) { box.textContent = ''; box.append(el('div.empty', { text: /не найден/.test(e.message) ? e.message : 'Сервисы погоды сейчас недоступны. Проверьте интернет или нажмите «Показать» ещё раз. (' + String(e.message || e).replace(/^Error invoking remote method 'vos': (Error: )?/, '') + ')' })); return; }
        const { place, f } = last, c = f.current;
        w.setTitle(place.name);
        box.textContent = '';
        if (last.stale) box.append(el('div.w-stale', { text: 'Нет связи с сервисами погоды. Показан прогноз от ' + new Date(last.at).toLocaleString('ru-RU', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' }) + '.' }));
        box.append(el('div.w-now', null,
          el('div.w-big', { html: VOS.weatherIcon(c.weather_code, 110) }),
          el('div', null, el('div.w-temp', { text: deg(c.temperature_2m) }), el('div.w-desc', { text: wmo(c.weather_code)[1] }),
            el('div.muted', { text: 'Ощущается как ' + deg(c.apparent_temperature) + ' · ветер ' + Math.round(c.wind_speed_10m) + ' м/с · влажность ' + c.relative_humidity_2m + '% · давление ' + Math.round(c.surface_pressure * 0.750062) + ' мм рт. ст.' })),
          el('div.w-place', null, el('b', { text: place.name }), el('div.muted', { text: place.region }))));
        paint();
      }
      w.onArgs = a => { if (a && a.days && PERIODS.some(p => p[0] === a.days)) { period = a.days; paintPeriods(); if (last) paint(); } };
      if (w.args && w.args.days) w.onArgs(w.args);
      cityIn.addEventListener('keydown', e => { if (e.key === 'Enter') load(); });
      w.body.append(el('div.app-pad', null,
        el('div.toolbar.w-toolbar', null, el('label', { text: 'Город:' }), cityIn, el('button.btn', { text: 'Показать', onclick: load }),
          el('button.btn', { title: 'Сделать основным', onclick: async () => { await VOS.saveSettings({ city: cityIn.value.trim() }); VOS.ui.toast('Город сохранён'); } }, '@star'),
          periodBar,
          el('span.spacer'), el('button.btn.primary', { text: '🔊 Озвучить', onclick: () => last && VOS.speak(VOS.weather.summary(last), { force: true }) })),
        box));
      load();
    }
  });
})();
