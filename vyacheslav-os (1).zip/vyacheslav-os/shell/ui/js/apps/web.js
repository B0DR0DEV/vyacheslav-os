/*
 * Новости, Видео (RUTUBE / VK Видео), Телевизор, Поиск в интернете.
 * Все четыре — окна со встроенным браузером и своей верхней панелью.
 */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, L = window.VOS_LINKS;
  const fill = (tpl, q) => tpl.replace('{q}', encodeURIComponent(q));

  function sourceBar(items, onPick, activeIdx = 0) {
    const bar = el('div.chip-bar');
    items.forEach((it, i) => {
      const b = el('button.chip' + (i === activeIdx ? '.on' : ''), { text: it.name, onclick: () => {
        bar.querySelectorAll('.chip').forEach(c => c.classList.remove('on')); b.classList.add('on'); onPick(it);
      } });
      bar.append(b);
    });
    return bar;
  }

  VOS.registerApp({
    id: 'news', title: 'Новости', width: 1100, height: 680, maximized: true,
    words: ['новости', 'новость', 'газету', 'газета'],
    open(w) {
      let br;
      const bar = sourceBar(L.news, it => { br.setHome(it.url); br.load(it.url); w.setTitle(it.name); });
      br = VOS.makeBrowser({ home: L.news[0].url, topBar: bar });
      w.setTitle(L.news[0].name);
      w.body.append(br.root);
    }
  });

  VOS.registerApp({
    id: 'tv', title: 'Телевизор', width: 1100, height: 680, maximized: true,
    words: ['телевизор', 'телик', 'тв', 'телевидение', 'канал', 'первый канал', 'россия'],
    open(w, args) {
      let br = null;
      const grid = el('div.tile-grid');
      const pick = ch => {
        w.setTitle(ch.name);
        if (!br) {
          br = VOS.makeBrowser({ home: ch.url, topBar: el('div.chip-bar', null, el('button.btn', { text: '◀ Все каналы', onclick: () => { br.root.remove(); br = null; w.body.append(grid); w.setTitle(''); } }), el('span.big-label', { text: ch.name })) });
          grid.remove(); w.body.append(br.root);
        } else br.load(ch.url);
      };
      L.tv.forEach((ch, i) => grid.append(el('button.tile', { onclick: () => pick(ch) }, el('span.tile-badge', { text: String(i + 1), style: { '--h': (i * 37) % 360 } }), el('span', { text: ch.name }))));
      w.body.append(el('div.app-pad', null, el('h2', { text: 'Выберите канал' }), el('p.muted', { text: 'Прямой эфир откроется в этом окне. Чтобы смотреть на весь экран — нажмите значок ⛶ в плеере.' }), grid));
      const findCh = q => L.tv.find(c => c.name.toLowerCase().includes(String(q).toLowerCase()));
      w.onArgs = a => { if (a.query) { const c = findCh(a.query); if (c) pick(c); } };
      if (args.query) w.onArgs(args);
    }
  });

  VOS.registerApp({
    id: 'video', title: 'Видео', width: 1100, height: 680, maximized: true,
    words: ['видео', 'кино', 'фильм', 'фильмы', 'рутуб', 'rutube', 'вк видео', 'ролик', 'ролики'],
    open(w, args) {
      let site = 'rutube', br;
      const input = el('input.big-input.grow', { placeholder: 'Что найти? Например: рыбалка на Волге', value: args.query || '' });
      const go = () => {
        const q = input.value.trim();
        const url = q ? fill(site === 'rutube' ? L.video.rutube : L.video.vk, q) : (site === 'rutube' ? L.video.rutubeHome : L.video.vkHome);
        br.load(url); w.setTitle(q || (site === 'rutube' ? 'RUTUBE' : 'VK Видео'));
      };
      input.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
      const top = el('div.search-bar', null,
        sourceBar([{ name: 'RUTUBE', id: 'rutube' }, { name: 'VK Видео', id: 'vk' }], it => { site = it.id; go(); }),
        input, el('button.btn.primary', { text: '🔍 Найти', onclick: go }),
        el('button.btn', { text: '🎤', title: 'Сказать голосом', onclick: () => VOS.assistant.dictate(t => { input.value = t; go(); }) }));
      br = VOS.makeBrowser({ home: args.query ? fill(L.video.rutube, args.query) : L.video.rutubeHome, topBar: top });
      w.body.append(br.root);
      w.onArgs = a => { if (a.query) { input.value = a.query; go(); } };
    }
  });

  VOS.registerApp({
    id: 'mail', title: 'Почта', width: 1100, height: 680, maximized: true,
    words: ['почта', 'почту', 'письма', 'письмо', 'электронная почта', 'мейл'],
    async open(w) {
      let br;
      const saved = await VOS.store.get('mailSite', 0);
      const idx = Math.min(L.mail.length - 1, Math.max(0, +saved || 0));
      const bar = sourceBar(L.mail, it => { br.setHome(it.url); br.load(it.url); w.setTitle(it.name); VOS.store.set('mailSite', L.mail.indexOf(it)); }, idx);
      bar.title = 'Вложения из писем сохраняются в «Загрузки». Прикрепить файл к письму — кнопка со скрепкой на сайте почты.';
      br = VOS.makeBrowser({ home: L.mail[idx].url, topBar: bar, zoom: 1.2 });
      w.setTitle(L.mail[idx].name);
      w.body.append(br.root);
    }
  });

  VOS.registerApp({
    id: 'search', title: 'Поиск в интернете', width: 1100, height: 680, maximized: true,
    words: ['поиск', 'интернет', 'браузер', 'найди', 'яндекс', 'гугл', 'сайт'],
    open(w, args) {
      let eng = L.search.engines[0], br;
      const input = el('input.big-input.grow', { placeholder: 'Напишите, что найти', value: args.query || '' });
      const go = () => {
        const q = input.value.trim();
        if (!q) { br.load(eng.home); return; }
        // если написали адрес сайта — открываем его напрямую
        const url = /^(https?:\/\/)?[a-zа-я0-9-]+(\.[a-zа-я0-9-]+)+(\/\S*)?$/i.test(q) && !/\s/.test(q) ? (/^https?:/.test(q) ? q : 'https://' + q) : fill(eng.url, q);
        br.load(url); w.setTitle(q);
      };
      input.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
      const top = el('div.search-bar', null, input,
        el('button.btn.primary', { text: '🔍 Найти', onclick: go }),
        el('button.btn', { text: '🎤', title: 'Сказать голосом', onclick: () => VOS.assistant.dictate(t => { input.value = t; go(); }) }),
        sourceBar(L.search.engines, it => { eng = it; go(); }));
      br = VOS.makeBrowser({ home: args.query ? fill(eng.url, args.query) : eng.home, topBar: top });
      w.body.append(br.root);
      w.onArgs = a => { if (a.query) { input.value = a.query; go(); } };
      setTimeout(() => input.focus(), 100);
    }
  });
})();
