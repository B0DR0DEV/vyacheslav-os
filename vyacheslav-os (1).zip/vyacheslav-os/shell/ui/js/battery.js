/* Батарея: значок с зарядом в трее, окошко с подробностями и
 * предупреждения голосом, когда заряд садится (20%, 10%, 5%). */
(function () {
  'use strict';
  const VOS = window.VOS, el = VOS.el, B = VOS.backend;
  let last = null, warned = 100;

  // значок: корпус батареи, заливка по заряду, молния при зарядке
  function icon(b) {
    const w = Math.round(13 * Math.max(0.06, (b.percent || 0) / 100));
    const color = b.charging || b.ac ? 'var(--ok)' : b.percent <= 10 ? 'var(--danger)' : b.percent <= 20 ? 'var(--warn)' : 'currentColor';
    return '<svg class="g" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      '<rect x="2.5" y="7.5" width="17" height="9" rx="2"/><path d="M21.5 10.5v3"/>' +
      '<rect x="4.5" y="9.5" width="' + w + '" height="5" rx="1" fill="' + color + '" stroke="none"/>' +
      (b.charging ? '<path d="M11.5 8.5l-2.5 4h3l-2 3.5" stroke="#fff" stroke-width="1.6"/>' : '') + '</svg>';
  }
  const mins = m => m + ' ' + VOS.plural(m, 'минута', 'минуты', 'минут');
  const timeText = m => m == null ? '' : m < 60 ? mins(m) : Math.floor(m / 60) + ' ' + VOS.plural(Math.floor(m / 60), 'час', 'часа', 'часов') + (m % 60 ? ' ' + mins(m % 60) : '');
  function describe(b) {
    if (!b || !b.present) return 'Батареи нет — компьютер работает от сети.';
    if (b.full) return 'Батарея заряжена полностью.';
    if (b.charging) return 'Заряжается' + (b.minutes ? ', до полной — около ' + timeText(b.minutes) : '') + '.';
    if (b.ac) return 'Подключено к сети.';
    return 'Работает от батареи' + (b.minutes ? ', хватит примерно на ' + timeText(b.minutes) : '') + '.';
  }
  VOS.batteryReply = async () => {
    const b = await B.call('battery').catch(() => null);
    if (!b || !b.present) return { say: 'Батареи нет: компьютер работает от сети.' };
    return { say: 'Заряд батареи ' + b.percent + ' ' + VOS.plural(b.percent, 'процент', 'процента', 'процентов') + '. ' + describe(b) + (b.percent <= 20 && !b.charging && !b.ac ? ' Подключите, пожалуйста, зарядку.' : '') };
  };

  async function update() {
    const btn = VOS.$('#tray-bat'); if (!btn) return;
    const b = await B.call('battery').catch(() => null);
    last = b;
    if (!b || !b.present) { btn.classList.add('hidden'); return; }
    btn.classList.remove('hidden');
    btn.innerHTML = icon(b) + '<span class="bat-pc">' + b.percent + '%</span>';
    btn.title = 'Заряд ' + b.percent + '%. ' + describe(b);
    btn.classList.toggle('low', !b.charging && !b.ac && b.percent <= 20);
    // предупреждения — по одному на каждый порог, пока не поставят на зарядку
    if (b.charging || b.ac) { warned = 100; return; }
    for (const lvl of [5, 10, 20]) {
      if (b.percent <= lvl && warned > lvl) {
        warned = lvl;
        const urgent = lvl <= 5;
        const text = (urgent ? 'Батарея почти села — ' : 'Батарея садится — ') + b.percent + ' процентов. Подключите, пожалуйста, зарядку.' + (urgent ? ' Иначе компьютер скоро выключится.' : '');
        if (VOS.screens && VOS.screens.isLocked && VOS.screens.isLocked()) VOS.speak(text, { force: true });
        else if (VOS.assistant) VOS.assistant.announce(text, { title: 'Батарея' });
        break;
      }
    }
  }
  function panel() {
    const b = last || {};
    return el('div.bat-panel', null,
      el('div.bat-big', null, el('span', { html: icon(b) }), el('b', { text: (b.percent ?? '—') + '%' })),
      el('p', { text: describe(b) }),
      !b.charging && !b.ac && b.percent <= 20 ? el('p.bat-warn', { text: 'Подключите зарядку.' }) : null);
  }
  document.addEventListener('DOMContentLoaded', () => {
    const start = () => {
      const btn = VOS.$('#tray-bat'); if (!btn) return;
      btn.onclick = e => { const p = VOS.wm.popup(e.currentTarget, 'Батарея', panel()); if (p) update().then(() => { const n = p.querySelector('.bat-panel'); if (n) n.replaceWith(panel()); }); };
      update(); setInterval(update, 30000);
    };
    // трей появляется вместе с рабочим столом
    const t = setInterval(() => { if (VOS.$('#tray-bat') && VOS.wm && VOS.wm.popup) { clearInterval(t); start(); } }, 500);
  });
})();
