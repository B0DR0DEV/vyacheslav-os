/*
 * links.js — сайты, каналы и радиостанции. Этот файл можно спокойно
 * править: добавить свой любимый сайт или канал. Адреса сайтов иногда
 * меняются — если какой-то канал перестал открываться, поправьте ссылку здесь.
 * В установленной системе файл лежит в /opt/vos/shell/ui/data/links.js
 */
window.VOS_LINKS = {
  news: [
    { name: 'РИА Новости', url: 'https://ria.ru/' },
    { name: 'ТАСС', url: 'https://tass.ru/' },
    { name: 'Российская газета', url: 'https://rg.ru/' },
    { name: 'Лента.ру', url: 'https://lenta.ru/' },
    { name: 'РБК', url: 'https://www.rbc.ru/' },
    { name: 'Аргументы и факты', url: 'https://aif.ru/' },
    { name: 'Известия', url: 'https://iz.ru/' }
  ],
  tv: [
    { name: 'Первый канал', url: 'https://www.1tv.ru/live' },
    { name: 'Россия 1', url: 'https://smotrim.ru/channel/1' },
    { name: 'Россия 24', url: 'https://smotrim.ru/channel/3' },
    { name: 'Россия К (Культура)', url: 'https://smotrim.ru/channel/4' },
    { name: 'НТВ', url: 'https://www.ntv.ru/air/' },
    { name: 'Звезда', url: 'https://tvzvezda.ru/video/' },
    { name: 'ТВ Центр', url: 'https://www.tvc.ru/air' },
    { name: 'Пятый канал', url: 'https://www.5-tv.ru/live/' },
    { name: 'Мир', url: 'https://mirtv.ru/live/' },
    { name: 'ОТР', url: 'https://otr-online.ru/online/' }
  ],
  // заголовки для утренней сводки («Василиса, расскажи новости»)
  newsRss: [
    { name: 'РИА Новости', url: 'https://ria.ru/export/rss2/archive/index.xml' },
    { name: 'Лента.ру', url: 'https://lenta.ru/rss/news' },
    { name: 'ТАСС', url: 'https://tass.ru/rss/v2.xml' }
  ],
  video: {
    rutube: 'https://rutube.ru/search/?query={q}',
    rutubeHome: 'https://rutube.ru/',
    vk: 'https://vkvideo.ru/?q={q}',
    vkHome: 'https://vkvideo.ru/'
  },
  search: {
    engines: [
      { name: 'Яндекс', url: 'https://ya.ru/search/?text={q}', home: 'https://ya.ru/' },
      { name: 'Mail.ru', url: 'https://go.mail.ru/search?q={q}', home: 'https://go.mail.ru/' },
      { name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q={q}', home: 'https://duckduckgo.com/' }
    ]
  },
  // Радио: сначала играют прямые адреса потоков (streams) — это серверы самих
  // радиостанций в России. Если адрес сменился — станция ищется по названию
  // в открытом каталоге radio-browser.info. Свой адрес можно вписать в streams.
  radio: [
    { name: 'Радио России', query: 'Радио России', icon: '🇷🇺', streams: ['https://icecast-vgtrk.cdnvideo.ru/rrzonam_mp3_192kbps'] },
    { name: 'Маяк', query: 'Маяк', icon: '⚓', streams: ['https://icecast-vgtrk.cdnvideo.ru/mayakfm_mp3_192kbps'] },
    { name: 'Ретро FM', query: 'Ретро FM', icon: '🎙', streams: ['https://retro.hostingradio.ru:8043/retro256.mp3', 'https://retro.hostingradio.ru:8043/retro128.mp3'] },
    { name: 'Русское Радио', query: 'Русское Радио', icon: '🎵', streams: ['https://rusradio.hostingradio.ru/rusradio96.aacp', 'https://rusradio.hostingradio.ru/rusradio128.mp3'] },
    { name: 'Радио Шансон', query: 'Шансон', icon: '🎸', streams: ['https://chanson.hostingradio.ru:8041/chanson256.mp3', 'https://chanson.hostingradio.ru:8041/chanson128.mp3'] },
    { name: 'Авторадио', query: 'Авторадио', icon: '🚗', streams: ['https://pub0302.101.ru:8443/stream/air/aac/64/100'] },
    { name: 'Дорожное радио', query: 'Дорожное радио', icon: '🛣', streams: ['https://dorognoe.hostingradio.ru:8000/dorognoe'] },
    { name: 'Радио Дача', query: 'Радио Дача', icon: '🏡' },
    { name: 'Вести FM', query: 'Вести ФМ', icon: '📰', streams: ['https://icecast-vgtrk.cdnvideo.ru/vestifm_mp3_192kbps'] },
    { name: 'Орфей (классика)', query: 'Орфей', icon: '🎻' },
    { name: 'Европа Плюс', query: 'Европа Плюс', icon: '🌍', streams: ['https://ep256.hostingradio.ru:8052/europaplus256.mp3', 'https://ep128.hostingradio.ru:8030/ep128'] },
    { name: 'Юмор FM', query: 'Юмор FM', icon: '😄', streams: ['https://pub0302.101.ru:8443/stream/air/aac/64/102'] },
    { name: 'Радио Звезда', query: 'Радио Звезда', icon: '⭐' }
  ],
  radioApi: ['https://de1.api.radio-browser.info', 'https://nl1.api.radio-browser.info', 'https://fi1.api.radio-browser.info', 'https://at1.api.radio-browser.info']
};
