#!/usr/bin/env python3
"""Пустые документы для «Создать → Текст / Таблица / Презентация».

Делает минимальные файлы ODF (odt, ods, odp) и Office (docx, xlsx).
Презентацию .pptx делает сам LibreOffice из new.odp (у формата PowerPoint
слишком много обязательных частей):
  soffice --headless --convert-to pptx --outdir shell/templates shell/templates/new.odp
"""
import sys, zipfile, os

out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', 'shell', 'templates')
os.makedirs(out, exist_ok=True)

def odf(name, mime, body):
    manifest = ('<?xml version="1.0" encoding="UTF-8"?>\n<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" manifest:version="1.2">'
                f'<manifest:file-entry manifest:full-path="/" manifest:media-type="{mime}"/>'
                '<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/></manifest:manifest>')
    content = ('<?xml version="1.0" encoding="UTF-8"?>\n<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
               'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
               'xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" xmlns:presentation="urn:oasis:names:tc:opendocument:xmlns:presentation:1.0" '
               f'office:version="1.2"><office:body>{body}</office:body></office:document-content>')
    with zipfile.ZipFile(os.path.join(out, name), 'w') as z:
        z.writestr(zipfile.ZipInfo('mimetype'), mime, compress_type=zipfile.ZIP_STORED)   # первым и без сжатия — так требует ODF
        z.writestr('META-INF/manifest.xml', manifest, compress_type=zipfile.ZIP_DEFLATED)
        z.writestr('content.xml', content, compress_type=zipfile.ZIP_DEFLATED)

odf('new.odt', 'application/vnd.oasis.opendocument.text', '<office:text><text:p/></office:text>')
odf('new.ods', 'application/vnd.oasis.opendocument.spreadsheet',
    '<office:spreadsheet><table:table table:name="Лист1"><table:table-column/><table:table-row><table:table-cell/></table:table-row></table:table></office:spreadsheet>')
odf('new.odp', 'application/vnd.oasis.opendocument.presentation',
    '<office:presentation><draw:page draw:name="Слайд1" draw:master-page-name="Default"/></office:presentation>')

CT = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>{}</Types>'
RELS = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{}</Relationships>'
OFFDOC = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument'

with zipfile.ZipFile(os.path.join(out, 'new.docx'), 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('[Content_Types].xml', CT.format('<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'))
    z.writestr('_rels/.rels', RELS.format(f'<Relationship Id="rId1" Type="{OFFDOC}" Target="word/document.xml"/>'))
    z.writestr('word/document.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p/><w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="850" w:bottom="1134" w:left="1701" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>')

with zipfile.ZipFile(os.path.join(out, 'new.xlsx'), 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('[Content_Types].xml', CT.format('<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'))
    z.writestr('_rels/.rels', RELS.format(f'<Relationship Id="rId1" Type="{OFFDOC}" Target="xl/workbook.xml"/>'))
    z.writestr('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Лист1" sheetId="1" r:id="rId1"/></sheets></workbook>')
    z.writestr('xl/_rels/workbook.xml.rels', RELS.format('<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'))
    z.writestr('xl/worksheets/sheet1.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData/></worksheet>')
print('шаблоны:', sorted(os.listdir(out)))
